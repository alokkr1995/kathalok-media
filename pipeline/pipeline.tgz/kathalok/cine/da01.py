from props import *
import math

ID = 'DA-01'
TAG = "दशावतार - मत्स्य  |  भाग 1"
HOOK = "एक मछली ने दुनिया बचाई?"
L = lambda pos, col=(1, .85, .6), power=.9, radius=900, amb=(.5, .48, .5), **k: dict(pos=pos, col=col, power=power, radius=radius, amb=amb, **k)


def king(x, y, s, t, arms='down', o=None, pose='stand'):
    f = dict(crown=True, mustache=True, open=blink(t, 3.2), smile=.2); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, upper="url(#white)", dhoti="url(#saff)", angavastram="#e2b13c", face=f))[0]


def palms(x, y, s, t, fish_glow=1.):
    g = P("M-190,-10 Q-200,120 -60,150 Q0,158 60,150 Q200,120 190,-10 Q120,40 0,44 Q-120,40 -190,-10 Z", "url(#skinD)", INK, 6)
    for k in range(4): g += P(f"M{-185 + k * 14},{-8 + k * 18} q-30,-30 -10,-60", "none", INK, 5) + P(f"M{185 - k * 14},{-8 + k * 18} q30,-30 10,-60", "none", INK, 5)
    g += E(0, 8, 170, 40, "#4a86b0", INK, 4, .85) + E(0, 2, 150, 26, "#cfe4ff", "none", 0, .5)
    for k in range(5):
        ph = (t * .8 + k / 5) % 1
        g += C(-150 + k * 70, 150 + ph * 200, 7, "#cfe4ff", op=1 - ph)
    return G(g, x, y, s)


def river_waist(y, t):
    return EP.waves(y, t, "#3a6a9a", "#cfe4f7", 14)


def serpent_rope(t, u):
    pts = []
    for k in range(40):
        x = 820 - k * 14; y = 560 + k * 12 + 30 * math.sin(k * .45 + t * 3)
        pts.append(f"{x:.0f},{y:.0f}")
    d = "M" + " L".join(pts)
    sc = "".join(C(820 - k * 14, 560 + k * 12 + 30 * math.sin(k * .45 + t * 3), 6, "#bfffd0", op=.5) for k in range(0, 40, 3))
    return P(d, "none", "#1a5a3a", 30) + P(d, "none", "#7fe0a0", 16) + sc + G(E(0, 0, 40, 26, "#1a5a3a", INK, 4) + C(-14, -6, 6, "#ffe06a") + C(14, -6, 6, "#ffe06a"), 270, 1040 + 20 * math.sin(t * 2), seg(u, .5, .9))


SH = []
# L0 0-7.0
SH.append(dict(t0=0, t1=3.5, trans='cut',
    bg=lambda t, u: sky("#2a3a5a", "#5a6a8a", "#2a3040") + dust(t, 40, "#cfe4ff", .5),
    fg=lambda t, u: palms(540, 920, 1.5, t) + EP.fish(540, 900, .55, t, 1.0),
    cam=(1.0, 1.25, 540, 900, 540, 890), dof=6, light=L((540, 880), (1, .9, .6), 1.2, 500, (.4, .42, .5)), grade='dawn', sfx=[(0, 'splash', .4), (.3, 'shimmer', .6)]))
SH.append(dict(t0=3.5, t1=7.0, trans='flash', tdur=.2,
    bg=lambda t, u: sky("#0a1020", "#1a2440", "#0a0e18") + EP.clouds(t, "#20263a", 260, .95) + EP.lightning(t, 300) + EP.rain(t, 80, .5),
    fg=lambda t, u: G(EP.waves(0, t, "#14284a", "#8ab0d8", 60, 8, 2), 0, 700 + 300 * (1 - u)) + EP.boat(540, 1180, .5, t, 10),
    cam=(1.0, 1.12, 540, 1000, 540, 960), light=L((300, 200), (.8, .9, 1.0), .8, 900, (.35, .38, .48)), grade='storm', shake=4, sfx=[(0, 'thunder', .9), (0, 'waves', .8), (0, 'rain', .5)], mood=.9))
# L1 7.0-13.9
SH.append(dict(t0=7.0, t1=10.6, trans='ink',
    bg=lambda t, u: sky("#ffd8a0", "#f3a96a", "#cfa070") + C(540, 700, 140, "url(#sunG)", INK, 5) + hills(980, t, "#b07a5a", 90, 2, .9),
    fg=lambda t, u: king(540, 720, 1.0, t, 'offer', dict(gaze=(0, 1), open=.5)) + P(f"M560,{860} Q565,{980} 560,{1150}", "none", "#cfe4ff", 8, .8) + river_waist(1080, t),
    cam=(1.0, 1.15, 540, 900, 540, 860), light=L((540, 700), (1, .82, .55), 1.0, 900, (.5, .45, .45), rays=.25, nrays=16), grade='dawn', sfx=[(0, 'waves', .4), (0, 'birds', .5), (.5, 'splash', .3)]))
SH.append(dict(t0=10.6, t1=13.9, trans='ink',
    bg=lambda t, u: sky("#f3c48a", "#d98a5a"),
    fg=lambda t, u: rim(540, 700, 420, "#fff3c4", .3) + face_cu(dict(crown=True, mustache=True, male=True, open=1, smile=.1 + .4 * seg(u, .5, 1), gaze=(0, 1), t=t, skin="url(#skinD)"), 540, 700, 2.8) + EP.fish(540, 1120, .3, t, 1.0),
    cam=(1.0, 1.08, 540, 820, 540, 840), light=L((540, 1150), (1, .9, .65), 1.0, 600, (.45, .42, .42)), grade='warm', sfx=[(.2, 'chime', .5)]))
# L2 13.9-19.9
SH.append(dict(t0=13.9, t1=16.9, trans='black', tdur=.4,
    bg=lambda t, u: sky("#0e1428", "#1a2440") + "".join(C(x, y, r, "#fff3c4", op=.2 + .5 * abs(math.sin(t + p))) for x, y, p, r in K.STARS[:70]),
    fg=lambda t, u: EP.kamandal(540, 1060, 3.0) + EP.fish(540, 780 - 30 * math.sin(t * 2), .4 + .15 * u, t, .8) + EP.fire(860, 1180, .5, t),
    cam=(1.0, 1.1, 540, 960, 540, 900), light=L((540, 800), (1, .9, .6), 1.0, 500, (.3, .32, .42)), grade='night', sfx=[(0, 'shimmer', .4)]))
SH.append(dict(t0=16.9, t1=19.9, trans='ink',
    bg=lambda t, u: sky("#f6e2bd", "#e9c48a") + ground(1150, "#c9a46e"),
    fg=lambda t, u: EP.kamandal(380, 1060, 2.4) + EP.fish(380, 820 - 120 * seg(u, 0, .4), .9, t, .6) + king(830 + 40 * seg(u, .2, .5), 640, .95, t, 'shield' if False else 'raise', dict(open=1, mouthOpen=.5, gaze=(-1, .2), smile=0), ),
    cam=(1.0, 1.06, 560, 900, 560, 900), light=L((600, 500), (1, .9, .7), .7, 900, (.55, .52, .5)), grade='warm', sfx=[(0, 'splash', .7), (.2, 'boom_soft', .5)]))
# L3 19.9-26.2
def growth(t, u):
    st = min(2, int(u * 3)); g = u * 3 - st
    bgs = [("#d8e8c0", "#9fc0a0"), ("#c8e0e8", "#6aa0c0"), ("#b0d0e8", "#3a6a9a")]
    s = sky(*bgs[st])
    if st == 0: s += ground(1100, "#8a9a52") + EP.kamandal(540, 1000, 3.2).replace("#8a5a2c", "#a8603a")
    elif st == 1: s += ground(1000, "#8a9a52") + E(540, 1150, 480, 200, "url(#riverD)", INK, 6)
    else: s += EP.waves(900, t, "#2b5c8f", "#cfe4f7", 20)
    return s


SH.append(dict(t0=19.9, t1=23.1, trans='ink',
    bg=growth,
    fg=lambda t, u: EP.fish(540, [880, 1080, 1000][min(2, int(u * 3))], [.8, 1.4, 2.0][min(2, int(u * 3))] * (.85 + .2 * (u * 3 % 1)), t, .4),
    cam=(1.0, 1.0, 540, 960, 540, 960), light=L((540, 600), (1, .9, .7), .6, 1000, (.6, .58, .56)), grade='neutral', sfx=[(0, 'splash', .6), (1.05, 'splash', .7), (2.1, 'splash', .8)]))
SH.append(dict(t0=23.1, t1=26.2, trans='ink',
    bg=lambda t, u: sky("#9fc4ea", "#4a86b0") + EP.waves(820, t, "#1c3560", "#9fc4ea", 26),
    fg=lambda t, u: EP.fish(540, 760 - 260 * math.sin(math.pi * seg(u, .1, .8)), 3.2, t, .3, False, -20 + 40 * u) + G(king(0, 0, .3, t, 'raise', dict(open=1)), 950, 1180, 1) + ground(1230, "#d6bd86"),
    cam=(1.15, 1.0, 540, 900, 540, 960), light=L((540, 500), (1, .95, .8), .7, 1000, (.55, .55, .6)), grade='neutral', shake=3, sfx=[(.4, 'splash', 1.0), (.4, 'boom', .6)], mood=.7))
# L4 26.2-32.3
SH.append(dict(t0=26.2, t1=29.2, trans='ink',
    bg=lambda t, u: sky("#1a2a50", "#3a4a80") + C(540, 600, 500, "url(#glow)", op=.4 * seg(u, 0, .6)) + EP.waves(880, t, "#1c3560", "#9fc4ea"),
    fg=lambda t, u: ground(1180, "#c9a46e") + king(540, 1180 - 400 * 1.0, 1.0, t, 'pray', dict(open=.6, smile=.3, gaze=(0, -.8)), 'sit'),
    cam=(1.0, 1.1, 540, 1000, 540, 960), light=L((540, 600), (1, .92, .7), 1.1, 800, (.35, .38, .5), rays=.35, nrays=20), grade='divine', bloom=.25, sfx=[(0, 'shimmer', .6), (.3, 'flute_rise', .5)]))
SH.append(dict(t0=29.2, t1=32.3, trans='flash', tdur=.2,
    bg=lambda t, u: sky("#0e1a3a", "#1c3560") + "".join(G(P("M300,-6 L1000,0 L300,6 Z", "#ffe08a", op=.3), 540, 760, 1, i * 12 + t * 6) for i in range(30)),
    fg=lambda t, u: EP.chakra(830, 400, 90, t) + G(EP.conch(0, 0, 1), 140, 420, 1.4) + EP.fish(520, 820, 2.4, t, 1.0, True),
    cam=(1.12, 1.0, 540, 800, 540, 820), light=L((540, 760), (1, .9, .6), 1.1, 800, (.4, .4, .5)), grade='divine', bloom=.3, sfx=[(0, 'gong', .8), (0, 'conch', .5)], mood=.6))
# L5 32.3-41.2
SH.append(dict(t0=32.3, t1=36.2, trans='ink',
    bg=lambda t, u: sky("#0e1a3a", "#1c3560") + C(540, 700, 600, "url(#glow)", op=.3),
    fg=lambda t, u: EP.fish(560, 800, 3.6 + .2 * u, t, .8, True) + "".join(C(300 - k * 30, 760 - ((t * 60 + k * 50) % 300), 8 + k, "none", "#cfe4ff", 3, .6) for k in range(5)),
    cam=(1.0, 1.1, 480, 820, 440, 800), light=L((400, 760), (1, .9, .6), .9, 700, (.4, .42, .52)), grade='divine', sfx=[(0, 'drone_in', .4), (.5, 'heartbeat', .4)], mood=.4))
SH.append(dict(t0=36.2, t1=41.2, trans='ink',
    bg=lambda t, u: sky("#f39a5a", "#8a4a5a", "#2a2a40") + EP.waves(1080, t, "#2b4a6a", "#cfe4f7", 14),
    fg=lambda t, u: EP.boat(560, 1040, 1.5, t, 1) + "".join(G(EP.sage(0, .38, t, 'pray', dict(), 'sit', y=0)[0], 380 + k * 120, 900 - 350 * .38, 1) for k in range(4)) + G(EP.cow(0, 0, .45) if hasattr(EP, 'cow') else "", 820, 960, 1) + "".join(E(250 + k * 60, 990, 30, 22, "#c9a46e", INK, 3) for k in range(3)) + king(940, 760, .6, t, 'point', dict(gaze=(-1, 0))),
    cam=(1.0, 1.1, 560, 960, 600, 900), light=L((900, 500), (1, .7, .45), .9, 1000, (.45, .4, .45)), grade='dawn', sfx=[(0, 'waves', .5), (1.0, 'cloth', .5), (2.5, 'footsteps', .4)]))
# L6 41.2-46.2
SH.append(dict(t0=41.2, t1=43.7, trans='cut',
    bg=lambda t, u: sky("#0a0e18", "#1a2030") + EP.clouds(t, "#232838", 300) + EP.lightning(t * 2, 540) + EP.rain(t, 120, .6),
    fg=lambda t, u: hills(1300, t, "#1a2a1a", 140, 2) + EP.tree(300, 1300, 1.3, t) + EP.tree(800, 1300, 1.1, t),
    cam=(1.0, 1.05, 540, 960, 540, 960), light=L((540, 200), (.8, .9, 1), .9, 900, (.3, .32, .4)), grade='storm', flash=lambda t, u: .7 * max(0, 1 - u * 6), shake=5, sfx=[(0, 'thunder', 1.0), (0, 'rain', .8)], mood=1.0))
SH.append(dict(t0=43.7, t1=46.2, trans='ink',
    bg=lambda t, u: sky("#0a0e18", "#1a2030") + EP.clouds(t, "#232838", 300) + EP.rain(t, 120, .6) + hills(1300, t, "#1a2a1a", 140, 2) + EP.tree(300, 1300, 1.3, t) + EP.tree(800, 1300, 1.1, t),
    fg=lambda t, u: G(EP.waves(0, t, "#14284a", "#8ab0d8", 40, 8, 2), 0, 1500 - 900 * seg(u, 0, 1)),
    cam=(1.0, 1.0, 540, 960, 540, 960), light=L((540, 200), (.8, .9, 1), .7, 900, (.3, .32, .4)), grade='storm', sfx=[(0, 'waves', 1.0)], mood=1.0))
# L7 46.2-51.7
SH.append(dict(t0=46.2, t1=49.0, trans='ink',
    bg=lambda t, u: sky("#0a0e18", "#141c2c") + EP.clouds(t, "#1c2232", 260) + EP.rain(t, 100, .5) + EP.lightning(t + 1, 800),
    fg=lambda t, u: G(EP.waves(0, t, "#14284a", "#8ab0d8", 70, 8, 2.5), 0, 1150) + EP.boat(540, 1120 + 40 * math.sin(t * 2), 1.4, t, 14),
    cam=(1.0, 1.1, 540, 1000, 540, 1000), roll=6, light=L((800, 300), (.8, .9, 1), .8, 900, (.3, .32, .4)), grade='storm', shake=4, sfx=[(0, 'waves', .9), (.6, 'thunder', .6)], mood=1.0))
SH.append(dict(t0=49.0, t1=51.7, trans='black', tdur=.3,
    bg=lambda t, u: sky("#050a10", "#0a1420"),
    fg=lambda t, u: serpent_rope(t, u) + EP.boat(250, 1120, .9, t, 4) + G(EP.fish(0, 0, 1.2, t, .3, True), 900, 480, 1),
    cam=(1.0, 1.12, 540, 860, 540, 860), light=L((540, 800), (.6, 1, .75), 1.0, 600, (.2, .22, .26)), grade='night', sfx=[(0, 'silence', 1), (1.2, 'chime_dark', .8)], mood=0))
SH.append(dict(t0=51.7, t1=55.5, trans='black', tdur=.4,
    bg=lambda t, u: sky("#0a1420", "#122030") + C(540, 600, 500, "url(#glow)", op=.15),
    fg=lambda t, u: '<g opacity=".3">' + EP.fish(540, 560, 1.6, t, .5, True) + '</g>',
    cam=(1, 1.05, 540, 960, 540, 960), light=L((540, 600), (.8, .9, 1), .6, 900, (.5, .5, .55)), grade='night', sfx=[(0, 'drum_hit', .6)], mood=.2))
