"""Kathalok cinematic engine v4: shot-based 2D Kalighat films with camera, lighting, DOF, grade, transitions."""
import math, io, json, sys
import numpy as np
import cairosvg
from PIL import Image, ImageDraw, ImageFilter
sys.path.insert(0, '/home/claude/kathalok/long_kr')
import kgbase as K

W, H, FPS = 1080, 1920, 30
cl, ease, seg = K.cl, K.ease, K.seg


def smooth(u): u = cl(u); return u * u * u * (u * (u * 6 - 15) + 10)


# ------------------------------------------------------------------ svg -> image
def svg2img(inner, transparent=False):
    bg = '' if transparent else ''
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">{K.DEFS}{inner}</svg>'
    im = Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode())))
    return im.convert('RGBA')


def camwrap(inner, s, cx, cy, rot=0.):
    return f'<g transform="translate({W / 2:.1f},{H / 2:.1f}) rotate({rot:.2f}) scale({s:.4f}) translate({-cx:.1f},{-cy:.1f})">{inner}</g>'


# ------------------------------------------------------------------ grades (shadow tint, highlight tint, sat, contrast)
GRADES = {
    'warm':   ((0.10, 0.04, 0.02), (1.06, 0.98, 0.86), 1.08, 1.06),
    'dawn':   ((0.08, 0.04, 0.06), (1.08, 0.96, 0.84), 1.05, 1.04),
    'night':  ((0.00, 0.03, 0.10), (0.80, 0.90, 1.08), 0.85, 1.10),
    'blood':  ((0.12, 0.00, 0.02), (1.12, 0.82, 0.74), 1.10, 1.16),
    'divine': ((0.06, 0.04, 0.00), (1.10, 1.04, 0.88), 1.05, 1.02),
    'storm':  ((0.02, 0.04, 0.08), (0.88, 0.94, 1.04), 0.80, 1.18),
    'fire':   ((0.10, 0.02, 0.00), (1.14, 0.92, 0.74), 1.12, 1.12),
    'neutral': ((0.04, 0.03, 0.02), (1.02, 1.0, 0.96), 1.0, 1.03),
}

_Y, _X = np.mgrid[0:H, 0:W].astype(np.float32)
_TEX = None


def paper():
    global _TEX
    if _TEX is None: _TEX = K.make_paper()
    return _TEX


def grade(a, name):
    sh, hi, sat, con = GRADES.get(name, GRADES['neutral'])
    lum = (a[..., 0] * .3 + a[..., 1] * .59 + a[..., 2] * .11)[..., None]
    a = lum + (a - lum) * sat
    a = (a - .5) * con + .5
    sh = np.array(sh, np.float32); hi = np.array(hi, np.float32)
    a = a * hi + sh * (1 - lum)
    return a


def light(a, L, scr):
    """L = dict(pos world, col, power, radius, amb). scr = function world->screen."""
    if not L: return a
    amb = np.array(L.get('amb', (0.55, 0.55, 0.6)), np.float32)
    col = np.array(L.get('col', (1.0, 0.85, 0.6)), np.float32)
    lx, ly = scr(*L['pos']); R = L.get('radius', 900)
    d2 = ((_X - lx) ** 2 + (_Y - ly) ** 2) / (R * R)
    f = np.exp(-d2)[..., None] * L.get('power', 0.8)
    out = a * (amb + col * f)
    if L.get('rays'):
        ang = np.arctan2(_Y - ly, _X - lx)
        st = (np.sin(ang * L.get('nrays', 14) + L.get('rayph', 0)) * .5 + .5) ** 6
        rays = (st * np.exp(-np.sqrt(d2) * 0.9))[..., None]
        out = out + rays * col * L['rays']
    return out


def bloom(img, amt=.35, thr=.72):
    small = img.resize((W // 4, H // 4), Image.BILINEAR)
    a = np.asarray(small).astype(np.float32) / 255.
    lum = a.mean(-1, keepdims=True)
    b = np.clip((lum - thr) / (1 - thr), 0, 1) * a
    bi = Image.fromarray((b * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(10)).resize((W, H), Image.BILINEAR)
    return np.asarray(bi).astype(np.float32) / 255. * amt


def finish(a):
    tex, vig = paper()
    a = a * (0.92 + 0.16 * tex[..., None])
    a = a * vig[..., None]
    return a


# ------------------------------------------------------------------ ink-wash transition mask
_rng = np.random.default_rng(7)
_n = _rng.random((H // 32, W // 32)).astype(np.float32)
INKMASK = np.asarray(Image.fromarray((_n * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(30))).astype(np.float32) / 255.
INKMASK = (INKMASK - INKMASK.min()) / (INKMASK.max() - INKMASK.min())
INKMASK = INKMASK * .6 + (_Y / H) * .4  # top-to-bottom bias


# ------------------------------------------------------------------ shot rendering
def cam_at(sh, u):
    c = sh.get('cam', (1, 1, 540, 960, 540, 960))
    s0, s1, x0, y0, x1, y1 = c
    e = smooth(u) if sh.get('camease', 'smooth') == 'smooth' else u
    return s0 + (s1 - s0) * e, x0 + (x1 - x0) * e, y0 + (y1 - y0) * e


def render_shot(sh, t):
    u = cl((t - sh['t0']) / (sh['t1'] - sh['t0']))
    s, cx, cy = cam_at(sh, u)
    rot = sh.get('roll', 0) * math.sin(u * math.pi)
    shake = sh.get('shake', 0)
    if shake:
        k = shake(t, u) if callable(shake) else shake
        cx += k * math.sin(t * 53); cy += k * math.cos(t * 41)
    scr = lambda x, y: ((x - cx) * s + W / 2, (y - cy) * s + H / 2)
    # background (parallax + depth of field)
    pb = sh.get('par', .55)
    sb = 1 + (s - 1) * pb
    bgsvg = sh['bg'](t, u)
    bg = svg2img(camwrap(bgsvg, sb, cx * pb + 540 * (1 - pb), cy * pb + 960 * (1 - pb), rot * .5))
    dof = sh.get('dof', 0)
    if callable(dof): dof = dof(u)
    if dof > .3: bg = bg.filter(ImageFilter.GaussianBlur(dof))
    if 'fg' in sh:
        fg = svg2img(camwrap(sh['fg'](t, u), s, cx, cy, rot), True)
        bg.alpha_composite(fg)
    if 'ov' in sh:  # screen-space overlay (no camera) e.g. rain, particles
        bg.alpha_composite(svg2img(sh['ov'](t, u), True))
    img = bg.convert('RGB')
    a = np.asarray(img).astype(np.float32) / 255.
    L = sh.get('light')
    if callable(L): L = L(t, u)
    a = light(a, L, scr)
    a = a + bloom(Image.fromarray(np.clip(a * 255, 0, 255).astype(np.uint8)), sh.get('bloom', .35))
    a = grade(a, sh.get('grade', 'neutral'))
    fl = sh.get('flash')
    if fl:
        v = fl(t, u) if callable(fl) else 0
        if v > 0: a = a + v * np.array(sh.get('flashcol', (1, 1, 1)), np.float32)
    return a


def render(shots, t):
    i = max(k for k in range(len(shots)) if shots[k]['t0'] <= t + 1e-6)
    sh = shots[i]
    a = render_shot(sh, t)
    # transition into next shot
    if i + 1 < len(shots):
        nx = shots[i + 1]; tr = nx.get('trans', 'ink'); dur = nx.get('tdur', .45)
        if tr != 'cut' and nx['t0'] - t < dur:
            p = smooth(1 - (nx['t0'] - t) / dur)
            b = render_shot(nx, t)
            if tr == 'ink':
                m = np.clip((p * 1.3 - INKMASK) / .12, 0, 1)[..., None]
                a = a * (1 - m) + b * m
            elif tr == 'flash':
                a = (a * (1 - p) + b * p) + (1 - abs(p - .5) * 2) * .9
            elif tr == 'black':
                a = a * max(0, 1 - 2 * p) + b * max(0, 2 * p - 1)
            else:
                a = a * (1 - p) + b * p
    a = finish(a)
    return Image.fromarray(np.clip(a * 255, 0, 255).astype(np.uint8))
