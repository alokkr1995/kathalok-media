#!/bin/bash
cd /home/claude/kathalok/cine
enc() { ID=$1; ffmpeg -y -loglevel error -framerate 30 -i $ID/frames/f%05d.jpg -i $ID/mix.wav -filter_complex "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11[a];[0:v]noise=alls=6:allf=t[v]" -map "[v]" -map "[a]" -c:v libx264 -preset veryfast -crf 21 -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart /mnt/user-data/outputs/${ID}_cinema.mp4; echo "$ID encoded"; }
# wait RV
while pgrep -f "run.py rv01 [0-9]" >/dev/null; do sleep 10; done
enc RV-01
for m in ku01:KU-01 da01:DA-01 hn01:HN-01; do mod=${m%%:*}; ID=${m##*:}
  N=$(python3 -c "import json,sys;sys.path.insert(0,'.');import $mod as M;print(int(M.SH[-1]['t1']*30))")
  python3 run.py $mod audio
  python3 run.py $mod 0 $((N/2)) > $ID/l0.txt 2>&1 & python3 run.py $mod $((N/2)) $N > $ID/l1.txt 2>&1; wait
  enc $ID
done
echo ALLDONE
