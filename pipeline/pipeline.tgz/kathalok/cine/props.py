import math, random, sys
sys.path.insert(0, '/home/claude/kathalok/long_kr'); sys.path.insert(0, '/home/claude/kathalok/b2')
import kgbase as K
import eps as EP
from kgbase import P, E, C, G, INK, face, woman, man, baby, river, lotus, tree, hills, grass, sunface, horse, motes, bgwash, cl, ease, seg, blink, wob

W, H = 1080, 1920


def sky(c1, c2, c3=None):
    c3 = c3 or c2
    return (f'<defs><linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{c1}"/><stop offset=".6" stop-color="{c2}"/><stop offset="1" stop-color="{c3}"/></linearGradient></defs>'
            f'<rect x="-2000" y="-2000" width="{W + 4000}" height="{H + 4000}" fill="url(#sk)"/>')


def ground(y, col, col2=None):
    return f'<rect x="-2000" y="{y}" width="{W + 4000}" height="3000" fill="{col}"/>' + (P(f"M-2000,{y} L{W + 2000},{y}", "none", col2 or INK, 5) if col2 is not False else "")


def haze(y, col, op=.35, h=260):
    return (f'<defs><linearGradient id="hz{int(y)}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{col}" stop-opacity="0"/><stop offset=".5" stop-color="{col}" stop-opacity="{op}"/><stop offset="1" stop-color="{col}" stop-opacity="0"/></linearGradient></defs>'
            f'<rect x="-2000" y="{y - h / 2}" width="{W + 4000}" height="{h}" fill="url(#hz{int(y)})"/>')


def shadow(x, y, w, op=.35):
    return E(x, y, w, w * .16, "#000", "none", 0, op)


def rim(x, y, r, col="#ffcf7a", op=.6):
    return (f'<defs><radialGradient id="rm{int(x)}{int(y)}" cx="50%" cy="50%" r="50%"><stop offset=".55" stop-color="{col}" stop-opacity="{op}"/><stop offset="1" stop-color="{col}" stop-opacity="0"/></radialGradient></defs>'
            f'<circle cx="{x}" cy="{y}" r="{r}" fill="url(#rm{int(x)}{int(y)})"/>')


def embers(t, n=40, col="#ffb050", op=.8, seed=2, rise=1.):
    r = random.Random(seed); s = []
    for k in range(n):
        x0 = r.uniform(-100, W + 100); sp = r.uniform(.05, .16) * rise; ph = r.random()
        p = (t * sp + ph) % 1
        x = x0 + 40 * math.sin(t * 1.3 + k); y = H + 50 - p * (H + 200)
        s.append(C(x, y, r.uniform(2, 5), col, op=op * math.sin(p * math.pi)))
    return "".join(s)


def dust(t, n=50, col="#fff3d0", op=.5, seed=4):
    r = random.Random(seed); s = []
    for k in range(n):
        x = (r.uniform(0, W) + t * r.uniform(5, 20)) % W; y = (r.uniform(0, H) + 30 * math.sin(t * .4 + k)) % H
        s.append(C(x, y, r.uniform(1.5, 4), col, op=op * (.4 + .6 * abs(math.sin(t * .8 + k)))))
    return "".join(s)


def face_cu(o, x, y, s):
    o = dict(o); o.setdefault('t', 0)
    return G(face(o), x, y, s)


def ravana_heads(x, y, s, t, reveal=1., angry=1.):
    g = []
    order = [4, -4, 3, -3, 2, -2, 1, -1]
    for k in order:
        a = k * 17
        px = math.sin(math.radians(a)) * 330; py = -math.cos(math.radians(a)) * 330 + 330
        op = cl(reveal * 1.6 - abs(k) * .12)
        g.append(f'<g opacity="{op:.2f}">' + G(face(dict(crown=True, mustache=True, male=True, angry=angry, open=blink(t, 3.1, k * .7), t=t + k, skin="url(#skinD)", gaze=(-math.sin(math.radians(a)) * .6, .2))), px, py + 20, .82, a * .6) + '</g>')
    g.append(G(face(dict(crown=True, mustache=True, male=True, angry=angry, smile=.25, open=blink(t, 3.4), t=t, skin="url(#skinD)")), 0, 0, 1.05))
    return G("".join(g), x, y, s)


def brahma(x, y, s, t):
    g = [rim(0, 0, 260, "#fff3c4", .7)]
    for sg in (-1, 1):
        g.append(G(face(dict(old=True, beard="#f4efe2", hair="#f4efe2", crown=True, male=True, t=t, open=.25, smile=.4, skin="url(#skin)")), sg * 70, 6, .8, sg * 18))
    g.append(G(face(dict(old=True, beard="#f4efe2", hair="#f4efe2", crown=True, male=True, t=t, open=.3 + .7 * blink(t, 4), smile=.45, skin="url(#skin)")), 0, 0, 1))
    return G("".join(g), x, y, s)


def sundial_sun(x, y, r, col="#b0201a"):
    return C(x, y, r, col, INK, 6) + C(x, y, r * 2.4, "url(#glow)", op=.4)


def palace_dark(t):
    s = []
    for x, h in [(80, 900), (300, 1150), (540, 1300), (780, 1100), (1000, 950)]:
        s.append(f'<rect x="{x - 90}" y="{1300 - h}" width="180" height="{h}" fill="#2a1420" stroke="{INK}" stroke-width="6"/>')
        s.append(P(f"M{x - 110},{1300 - h} L{x},{1300 - h - 200} L{x + 110},{1300 - h} Z", "#4a1a2a", INK, 6))
        for k in range(4):
            s.append(f'<rect x="{x - 26}" y="{1300 - h + 80 + k * 200}" width="52" height="90" rx="26" fill="#ff8a3a" opacity="{.35 + .3 * abs(math.sin(t * 3 + x + k)):.2f}"/>')
    return "".join(s)


def torch(x, y, s, t):
    g = P("M0,0 L0,160", "none", "#5a3a22", 16)
    for k in range(3):
        h = 90 + 20 * math.sin(t * 11 + k * 2)
        g += P(f"M{-26 + k * 26},0 Q{-36 + k * 26},{-h * .5} {-20 + k * 26 + 6 * math.sin(t * 9 + k)},{-h} Q{-6 + k * 26},{-h * .5} {-4 + k * 26},0 Z", "#ffb23a" if k == 1 else "#e2462a", INK, 3)
    g += C(0, -40, 180, "url(#glow)", op=.55)
    return G(g, x, y, s)


def forest_path(t, dusk=True):
    s = []
    for k, x in enumerate([-60, 160, 900, 1120]):
        s.append(G(P("M-40,0 L-30,-900 L30,-900 L40,0 Z", "#2a1a12", INK, 5), x, 1500, 1))
        s.append(E(x, 600 + 40 * (k % 2), 260, 200, "#1f3a22" if dusk else "#4f6e34", INK, 5, .95))
    s.append(P("M300,1920 Q480,1500 520,1180 L560,1180 Q640,1500 820,1920 Z", "#8a5a36", INK, 4))
    return "".join(s)


def hermitage(x, y, s):
    g = P("M-200,0 L-170,-260 L170,-260 L200,0 Z", "#8a5a2c", INK, 6) + P("M-250,-250 L0,-460 L250,-250 Z", "#c9a46e", INK, 6)
    for k in range(9): g += P(f"M{-230 + k * 58},{-262 + abs(k - 4) * 22 * 0} L{-200 + k * 50},{-250}", "none", "#8a6a3a", 3)
    g += f'<rect x="-50" y="-170" width="100" height="170" fill="#2a1a10" stroke="{INK}" stroke-width="5"/>'
    return G(g, x, y, s)


def thread_glow(x, y, s, t):
    return G(P("M-200,-40 Q0,120 200,-40", "none", "#fff3c4", 14) + P("M-200,-40 Q0,120 200,-40", "none", "#e2b13c", 4) + C(0, 40, 180, "url(#glow)", op=.6), x, y, s)


def sword(x, y, s, ang=0.):
    return G(P("M0,-320 L22,-280 L22,160 L-22,160 L-22,-280 Z", "#d6dbe2", INK, 5) + P("M0,-300 L0,150", "none", "#ffffff", 4) + P("M-90,160 L90,160", "none", "url(#gold)", 26) + P("M-90,160 L90,160", "none", INK, 3) + P("M0,170 L0,280", "none", "#6b4226", 26) + C(0, 296, 20, "url(#gold)", INK, 3), x, y, s, ang)
