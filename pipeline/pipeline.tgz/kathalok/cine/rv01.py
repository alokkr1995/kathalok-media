from props import *
import math

ID = 'RV-01'
TAG = "रावण - लंकापति  |  भाग 1"
HOOK = "ऋषि का बेटा राक्षस कैसे बना?"
NEXT = "रावण की तपस्या"


def vishrava(x, y, s, t, o=None, arms='pray'):
    f = dict(open=.12, smile=.25); f.update(o or {})
    return EP.sage(x, s, t, arms, f, col="url(#white)", y=y)[0]


def kaikesi(x, y, s, t, arms='down', o=None, pose='stand'):
    f = dict(open=blink(t, 2.8), sad=.2); f.update(o or {})
    return woman(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, saree="url(#green)", border="url(#bordG)", face=f))[0]


def sumali(x, y, s, t, arms='point', o=None, lift=0):
    f = dict(crown=True, mustache=True, angry=.7, open=blink(t, 3.0), beard=INK, skin="url(#skinD)"); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#redN)", dhoti="#2a1414", angavastram="#120808", armskin="url(#skinD)", face=f, lift=lift))[0]


L = lambda pos, col=(1, .85, .6), power=.9, radius=900, amb=(.5, .48, .5), **k: dict(pos=pos, col=col, power=power, radius=radius, amb=amb, **k)

SH = []
# ---------- line 0 (0 - 6.7): hook
SH.append(dict(t0=0, t1=2.3, trans='cut',
    bg=lambda t, u: sky("#3a2410", "#7a4a1a", "#2a1608") + motes(t, "#ffd36b", 30, .5),
    fg=lambda t, u: rim(540, 760, 420, "#ffcf7a", .35) + face_cu(dict(old=True, beard="#e4ddd2", hair="#d8d2c8", jata=True, tilak=True, wrinkles=True, male=True, open=.08, smile=.3, t=t), 540, 840, 3.3),
    cam=(1.0, 1.12, 540, 800, 540, 780), light=L((760, 520), (1.0, .8, .5), 1.0, 700, (.35, .3, .3)), grade='warm', sfx=[(0, 'drone_in', .6), (.1, 'chime', .5)]))
SH.append(dict(t0=2.3, t1=4.5, trans='ink',
    bg=lambda t, u: sky("#fff3c4", "#f2c46a", "#c98a3a") + dust(t, 40, "#fff8e0", .6),
    fg=lambda t, u: lotus(540, 1080, 4.2, t) + brahma(540, 640, 1.9, t),
    cam=(1.25, 1.0, 540, 800, 540, 820), light=L((540, 520), (1.0, .9, .7), .55, 800, (.42, .38, .36), rays=.22, nrays=18, rayph=0), grade='divine', dof=0, bloom=.15, sfx=[(0, 'shimmer', .6)]))
SH.append(dict(t0=4.5, t1=6.7, trans='flash', tdur=.25,
    bg=lambda t, u: sky("#050205", "#1a0508", "#0a0204") + embers(t, 40, "#ff5a2a", .7),
    fg=lambda t, u: rim(540, 780, 640, "#ff3a1a", .5 * seg(u, 0, .5)) + ravana_heads(540, 700, 1.25, t, reveal=seg(u, 0, .7)),
    cam=(1.35, 1.0, 540, 760, 540, 820), camease='lin', light=L((540, 1400), (1.0, .35, .2), 1.3, 900, (.25, .15, .18)), grade='blood',
    shake=lambda t, u: 6 * (1 - u), sfx=[(0, 'boom', 1.0), (0, 'thunder', .7)]))
# ---------- line 1 (6.7 - 14.0): lineage
SH.append(dict(t0=6.7, t1=10.3, trans='ink',
    bg=lambda t, u: sky("#fff7dc", "#f6d58a", "#e6a85a") + "".join(C(540 + 600 * math.cos(k), 600 + 600 * math.sin(k), 3, "#fff", op=.5) for k in range(40)),
    fg=lambda t, u: lotus(540, 900, 3.2, t) + brahma(540, 560, 1.3, t) + f'<g opacity="{seg(u, .25, .6):.2f}">' + rim(820, 1080, 260, "#fff3c4", .8) + vishrava(820, 1080, .62, t, dict(open=.1), 'pray') + '</g>' + P(f"M600,700 Q760,{820} 820,{1000}", "none", "#fff3c4", 6, .7 * seg(u, .1, .4)),
    cam=(1.0, 1.15, 600, 800, 700, 880), light=L((540, 560), (1.0, .9, .72), .5, 800, (.42, .38, .36), rays=.18, nrays=20, rayph=1), grade='divine', bloom=.15, sfx=[(.6, 'whoosh_soft', .5), (1.2, 'chime', .4)]))
SH.append(dict(t0=10.3, t1=14.0, trans='ink',
    bg=lambda t, u: sky("#f6dcae", "#f3b47a", "#c9a46e") + C(880, 520, 110, "url(#sunG)", INK, 5) + hills(980, t, "#b7a06a", 120, 2, .9) + EP.tree(120, 1200, 1.2, t) + hermitage(900, 1200, 1.0),
    fg=lambda t, u: ground(1180, "#c9a46e") + shadow(520, 1180, 220) + vishrava(520, 840, 1.0, t, dict(open=.1 + .8 * seg(u, .6, .8), smile=.35, gaze=(0, .2)), 'pray') + "".join(EP.bird(200 + 160 * k + 300 * u, 360 + 40 * k, .3, t + k, False) for k in range(3)),
    cam=(1.0, 1.3, 540, 900, 520, 820), light=L((880, 520), (1.0, .82, .55), .9, 1100, (.55, .5, .5)), grade='dawn', sfx=[(0, 'birds', .5)]))
# ---------- line 2 (14.0 - 18.3): Kaikesi, daughter of Sumali
SH.append(dict(t0=14.0, t1=16.2, trans='black', tdur=.4,
    bg=lambda t, u: sky("#120610", "#2a0c18", "#1a0810") + palace_dark(t) + embers(t, 25, "#ff6a2a", .5),
    fg=lambda t, u: torch(160, 1000, 1.1, t) + torch(920, 1000, 1.1, t) + sumali(540, 560, 1.25, t, 'raise', dict(angry=.8, smile=.3, gaze=(0, .3)), 1),
    cam=(1.15, 1.0, 540, 760, 540, 860), light=L((540, 1500), (1.0, .45, .2), 1.2, 900, (.3, .2, .25)), grade='fire', sfx=[(0, 'drum_low', .9), (0, 'fire_bed', .5)]))
SH.append(dict(t0=16.2, t1=18.3, trans='ink',
    bg=lambda t, u: sky("#1a0a14", "#3a1424", "#200a12") + palace_dark(t),
    fg=lambda t, u: rim(540, 760, 380, "#ff8a3a", .35) + face_cu(dict(open=.5 * blink(t, 2.8), sad=.5, gaze=(.4, .6), pallu="url(#green)", border="url(#bordG)", t=t), 540, 760, 3.2),
    cam=(1.0, 1.1, 540, 760, 560, 760), dof=6, light=L((900, 700), (1.0, .6, .35), 1.0, 600, (.32, .28, .32)), grade='fire', sfx=[(.2, 'chime_dark', .4)]))
# ---------- line 3 (18.3 - 29.4): Vishnu defeated rakshasas; Sumali wants an heir
SH.append(dict(t0=18.3, t1=21.6, trans='flash', tdur=.2,
    bg=lambda t, u: sky("#1a2a5a", "#3a2a5a", "#120a1a") + EP.clouds(t, "#2a2a4a", 1300, .9),
    fg=lambda t, u: EP.chakra(540, 520, 190, t * 2.5) + "".join(G(sumali(0, 0, .55, t, 'raise', dict(sad=.5, angry=.5)), 120 + k * 210 + 120 * u, 980 + 160 * u + (k % 2) * 60, 1, 10) for k in range(5)),
    cam=(1.0, 1.08, 540, 900, 540, 960), light=L((540, 520), (.75, .85, 1.0), 1.4, 800, (.35, .35, .45), rays=.5, nrays=12, rayph=0), grade='storm',
    shake=3, sfx=[(0, 'chakra', .9), (1.0, 'whoosh', .7)]))
SH.append(dict(t0=21.6, t1=24.8, trans='black', tdur=.4,
    bg=lambda t, u: sky("#0a0608", "#1a0e10", "#050304") + P("M-200,0 L1280,0 L1280,700 Q540,520 -200,700 Z", "#2a1a1a", INK, 6) + P("M-200,1920 L1280,1920 L1280,1300 Q540,1460 -200,1300 Z", "#2a1a1a", INK, 6),
    fg=lambda t, u: torch(540, 1150, 1.0, t) + "".join(G(sumali(0, 0, .5 + .06 * (k % 3), t + k, 'down', dict(sad=.6, angry=.4, open=.6)), 140 + k * 200, 900 + (k % 2) * 80, 1) for k in range(5)),
    cam=(1.25, 1.05, 540, 1000, 540, 960), light=L((540, 1100), (1.0, .55, .25), 1.3, 700, (.15, .12, .14)), grade='fire', sfx=[(0, 'cave_drip', .5), (0, 'fire_bed', .4)]))
SH.append(dict(t0=24.8, t1=29.4, trans='ink',
    bg=lambda t, u: sky("#0e0608", "#2a0c10", "#120608") + embers(t, 35, "#ff6a2a", .6),
    fg=lambda t, u: rim(540, 700, 520, "#ff5a2a", .3 + .3 * seg(u, .5, 1)) + sumali(540, 640, 1.9, t, 'raise', dict(angry=1, mouthOpen=.25 * abs(math.sin(t * 6)) * (u < .7), gaze=(0, -.4 * seg(u, .5, .9))), seg(u, .3, .8)),
    cam=(1.0, 1.35, 540, 900, 540, 760), light=L((300, 1300), (1.0, .5, .22), 1.3, 800, (.22, .16, .18)), grade='fire', sfx=[(0, 'heartbeat', .7), (3.4, 'drum_hit', .9)]))
# ---------- line 4 (29.4 - 33.5): sends daughter
SH.append(dict(t0=29.4, t1=31.6, trans='ink',
    bg=lambda t, u: sky("#1a0a14", "#3a1424", "#200a12") + palace_dark(t),
    fg=lambda t, u: torch(1000, 1000, 1, t) + sumali(720, 640, 1.05, t, 'point', dict(angry=.4, gaze=(-1, 0))) + kaikesi(300, 660, 1.0, t, 'pray', dict(sad=.6, gaze=(1, .3))),
    cam=(1.05, 1.0, 520, 940, 520, 960), light=L((1000, 900), (1.0, .55, .3), 1.1, 800, (.3, .24, .28)), grade='fire', sfx=[(.2, 'cloth', .5)]))
SH.append(dict(t0=31.6, t1=33.5, trans='ink',
    bg=lambda t, u: sky("#f39a5a", "#a8423a", "#3a1a1a") + C(540, 760, 120, "#ffb06a", INK, 5) + forest_path(t),
    fg=lambda t, u: shadow(540, 1180 + 40 * (1 - u), 60) + kaikesi(540, 1180 - 596 * (.28 + .1 * u) + 6 * abs(math.sin(t * 6)), .28 + .1 * u, t, 'down', dict(gaze=(0, 0))),
    cam=(1.0, 1.2, 540, 1000, 540, 1060), light=L((540, 760), (1.0, .6, .4), 1.0, 700, (.4, .3, .34)), grade='dawn', sfx=[(0, 'wind', .5), (0, 'footsteps', .4)]))
# ---------- line 5 (33.5 - 38.2): knowledge + strength
SH.append(dict(t0=33.5, t1=35.9, trans='ink',
    bg=lambda t, u: sky("#120a0a", "#2a1410", "#120a0a") + P("M540,0 L540,1920", "none", "#ffd36b", 4, .6),
    fg=lambda t, u: thread_glow(290 + 120 * seg(u, .5, 1), 760, 1.0, t) + sword(790 - 120 * seg(u, .5, 1), 820, 1.0, -10 + 10 * seg(u, .5, 1)) + C(290, 760, 260, "url(#glow)", op=.4) + rim(790, 820, 300, "#ff3a1a", .45),
    cam=(1.0, 1.05, 540, 860, 540, 860), light=L((540, 820), (1.0, .8, .6), .6, 900, (.6, .5, .5)), grade='warm', sfx=[(0, 'shimmer', .5), (.8, 'sword_ring', .7)]))
SH.append(dict(t0=35.9, t1=38.2, trans='flash', tdur=.2,
    bg=lambda t, u: sky("#1a0a0a", "#3a1a10", "#120a0a") + "".join(G(P("M300,-6 L900,0 L300,6 Z", "#ffcf6a", op=.35), 540, 820, 1, i * 15 + t * 6) for i in range(24)),
    fg=lambda t, u: f'<g opacity="{.35 * seg(u, .3, .9):.2f}">' + ravana_heads(540, 560, .9, t, 1, .6) + '</g>' + baby(540, 860, 1.8, t, eyes=1),
    cam=(1.2, 1.0, 540, 840, 540, 860), light=L((540, 820), (1.0, .7, .45), 1.1, 700, (.35, .3, .3)), grade='fire', sfx=[(0, 'boom_soft', .7), (.2, 'baby', .5)]))
# ---------- line 6 (38.2 - 43.7): inauspicious hour
SH.append(dict(t0=38.2, t1=40.8, trans='ink',
    bg=lambda t, u: sky("#f0703a", "#a8222a", "#3a0a14") + sundial_sun(540, 700 + 360 * u, 170, "#c0201a") + hills(1180, t, "#3a0a0a", 90, 2) + ground(1260, "#1a0606", False),
    fg=lambda t, u: "".join(EP.bird(180 + 180 * k + 200 * u, 420 + 60 * (k % 2), .38, t + k, False) for k in range(4)) + G(hermitage(0, 0, 1) , 820, 1262, .7) + G(kaikesi(0, 0, .3, t, 'down'), 300 + 260 * u, 1262 - 596 * .3, 1),
    cam=(1.0, 1.06, 540, 960, 540, 980), light=L((540, 900), (1.0, .4, .3), 1.1, 900, (.35, .2, .22)), grade='blood', sfx=[(0, 'crow', .6), (0, 'wind', .5)]))
SH.append(dict(t0=40.8, t1=43.7, trans='ink',
    bg=lambda t, u: sky("#a8322a", "#4a0a14", "#1a0508") + C(860, 760, 90, "#c0201a", INK, 4) + hermitage(760, 1220, 1.15),
    fg=lambda t, u: ground(1200, "#2a0a0a") + kaikesi(300, 1200 - 596 * .9, .9, t, 'pray', dict(sad=.4, gaze=(1, -.2))) + rim(740, 820, 300, "#ffcf7a", .25 * seg(u, .4, .8)) + vishrava(740, 820, .95, t, dict(open=.15 + .85 * seg(u, .45, .6), angry=.3 * seg(u, .5, .7), sad=.4, gaze=(-1, 0)), 'bless'),
    cam=(1.0, 1.18, 540, 940, 600, 860), light=L((860, 760), (1.0, .45, .32), 1.0, 900, (.3, .2, .24)), grade='blood', sfx=[(0, 'silence', 1), (1.4, 'gong', 1.0)]))
# ---------- line 7 (43.7 - 48.1): Lanka's future
SH.append(dict(t0=43.7, t1=48.1, trans='flash', tdur=.25,
    bg=lambda t, u: sky("#0a0614", "#1a1430", "#0a0a14") + EP.clouds(t, "#1a1828", 300, .95) + EP.lightning(t + .4, 760),
    fg=lambda t, u: G(EP.towers(t, "#1a0e1a"), 0, 420 * (1 - seg(u, 0, .6)) + 0) + EP.waves(1250, t, "#101a30", "#6a7aa0", 22) + f'<g opacity="{.55 * seg(u, .45, .9):.2f}">' + ravana_heads(540, 300, .75, t, 1, .9) + '</g>',
    cam=(1.0, 1.12, 540, 1000, 540, 880), light=L((540, 300), (.9, .4, .35), .9, 900, (.35, .35, .45)), grade='storm', sfx=[(0, 'waves', .6), (0, 'thunder', .8), (2.4, 'boom', .7)]))
# ---------- end card (48.1 - 51.9)
SH.append(dict(t0=48.1, t1=51.9, trans='black', tdur=.4,
    bg=lambda t, u: sky("#120810", "#2a1020", "#120810") + embers(t, 30, "#ff8a3a", .5),
    fg=lambda t, u: f'<g opacity=".35">' + ravana_heads(540, 520, .8, t, 1, .8) + '</g>',
    cam=(1.0, 1.05, 540, 960, 540, 960), light=L((540, 600), (1, .6, .4), .6, 900, (.5, .4, .45)), grade='fire', sfx=[(0, 'drum_hit', .6)], end=True))
