from props import *
import math, random

ID = 'KU-01'
TAG = "कुरुक्षेत्र  |  भाग 1"
HOOK = "40 लाख योद्धा आमने-सामने!"
L = lambda pos, col=(1, .85, .6), power=.9, radius=900, amb=(.5, .48, .5), **k: dict(pos=pos, col=col, power=power, radius=radius, amb=amb, **k)


def krishna(x, y, s, t, arms='down', o=None):
    f = dict(crown=True, feather=True, smile=.45, open=blink(t, 3.6, 2), mustache=False, skin="url(#skinB)"); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#yel)", dhoti="url(#yel)", angavastram="#2e8b57", armskin="url(#skinB)", face=f))[0]


def arjuna(x, y, s, t, arms='down', o=None):
    f = dict(crown=True, mustache=True, open=blink(t, 2.9, 1), smile=.1); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#white)", dhoti="url(#yel)", angavastram="#1f5fa8", face=f))[0]


def duryo(x, y, s, t, arms='down', o=None):
    f = dict(crown=True, mustache=True, angry=.3, smile=.4, open=blink(t, 3.1, 1.5)); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#purp)", dhoti="url(#gold)", angavastram="#3e1f5a", face=f))[0]


def bhishma(x, y, s, t, arms='raise', o=None, lift=0):
    f = dict(crown=True, old=True, beard="#f4efe2", hair="#f4efe2", wrinkles=True, mustache=True, open=blink(t, 3.5), smile=.1); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#white)", dhoti="url(#white)", angavastram="#e2b13c", face=f, lift=lift))[0]


def dhrishta(x, y, s, t, arms='raise', o=None):
    f = dict(crown=True, mustache=False, angry=.5, open=blink(t, 2.6)); f.update(o or {})
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#red)", dhoti="url(#saff)", angavastram="#7a1a10", face=f, lift=1))[0]


def soldiers(y, t, n, col, s=1., seed=1, spear=True, x0=-60, x1=1140):
    r = random.Random(seed); out = []
    for k in range(n):
        x = x0 + (x1 - x0) * k / max(1, n - 1) + r.uniform(-12, 12); bob = 4 * math.sin(t * 3 + k)
        out.append(C(x, y - 70 * s + bob, 20 * s, col) + P(f"M{x - 30 * s},{y + 40 * s} Q{x},{y - 70 * s + bob} {x + 30 * s},{y + 40 * s} Z", col)
                   + (P(f"M{x + 18 * s},{y - 20 * s} L{x + 26 * s},{y - 190 * s}", "none", col, 5 * s) + P(f"M{x + 26 * s},{y - 190 * s} l-8,22 l16,0 Z", "#c9ced6") if spear else ""))
    return "".join(out)


def banner(x, y, s, t, col):
    return G(P("M0,0 L0,-300", "none", INK, 8) + P(f"M0,-300 Q{80},{-290 + 10 * math.sin(t * 4)} {150},{-270 + 14 * math.sin(t * 4 + 1)} L0,-210 Z", col, INK, 4), x, y, s)


def field(t, dawn=True):
    return sky("#f7c98a", "#e8874a", "#b8653a") + C(540, 760, 120, "url(#sunG)", INK, 5) + hills(900, t, "#a8604a", 90, 2, .9) + ground(960, "#c9915a", False)


SH = []
# ---------- L0 0-5.6
SH.append(dict(t0=0, t1=2.9, trans='cut',
    bg=lambda t, u: field(t) + dust(t, 40, "#ffe0b0", .5),
    fg=lambda t, u: G("".join(soldiers(1000 + r * 70, t + r, 26 + r * 2, "#5a1a2a" if True else "", .35 + r * .12, r, True, -60, 500) for r in range(5)) + "".join(soldiers(1000 + r * 70, t + r, 16 + r, "#1a3a6a", .35 + r * .12, 9 + r, True, 620, 1140) for r in range(5)) + banner(260, 1000, .9, t, "#c0392b") + banner(840, 1000, .9, t, "#1f5fa8"), 0, -180),
    cam=(1.25, 1.0, 540, 1100, 540, 1080), light=L((540, 760), (1.0, .8, .55), .8, 1100, (.5, .45, .45), rays=.2, nrays=16), grade='dawn', sfx=[(0, 'wind', .6), (.2, 'drum_low', .8)]))
SH.append(dict(t0=2.9, t1=5.6, trans='ink',
    bg=lambda t, u: sky("#e8874a", "#8a2a2a", "#3a1414") + "".join(soldiers(900 + r * 60, t + r, 30, "#3a0a14", .3 + .1 * r, 20 + r, True) for r in range(4)),
    fg=lambda t, u: rim(540, 700, 420, "#ff6a3a", .35) + duryo(540, 620, 1.6, t, 'raise', dict(smile=.6, angry=.4, gaze=(0, .4))),
    cam=(1.0, 1.15, 540, 900, 540, 820), dof=5, light=L((540, 1500), (1.0, .55, .3), 1.1, 900, (.35, .28, .3)), grade='fire', sfx=[(0, 'drum_hit', .8)]))
# ---------- L1 5.6-17.4 akshauhini
SH.append(dict(t0=5.6, t1=8.6, trans='ink',
    bg=lambda t, u: sky("#f3d9a6", "#e2a86a") + ground(1000, "#c9a46e", False) + dust(t, 30, "#fff0d0", .4),
    fg=lambda t, u: G("".join(EP.chariot(150 + k * 330, 1050, .75, t, False, "#c0392b") for k in range(6)), -500 * u, 0) + G("".join(EP.chariot(0 + k * 330, 1300, .95, t, False, "#c0392b") for k in range(6)), -800 * u, 0),
    cam=(1.0, 1.05, 540, 1100, 540, 1100), light=L((800, 500), (1, .85, .6), .7, 1100, (.55, .5, .48)), grade='warm', sfx=[(0, 'footsteps', .6), (.3, 'twang', .3)]))
SH.append(dict(t0=8.6, t1=11.6, trans='ink',
    bg=lambda t, u: sky("#f3c48a", "#c9784a") + ground(1150, "#a8854f", False),
    fg=lambda t, u: "".join(EP.elephant(1300 - 520 * k - 300 * u, 1050 - 0 * k, 1.1 - .1 * k, t + k) for k in range(3)),
    cam=(1.0, 1.08, 540, 1000, 540, 980), light=L((700, 500), (1, .8, .55), .8, 1000, (.5, .45, .45)), grade='warm', shake=2.5, sfx=[(0, 'roar', .7), (.5, 'boom_soft', .6), (1.5, 'boom_soft', .6)]))
SH.append(dict(t0=11.6, t1=14.4, trans='ink',
    bg=lambda t, u: sky("#f6d7a6", "#e2a86a") + ground(1120, "#c9a46e", False) + dust(t * 3, 60, "#e8c890", .6),
    fg=lambda t, u: "".join(horse(-300 + 420 * k + 500 * u, 820 + (k % 2) * 200, 2.6, t * 2, k) for k in range(4)),
    cam=(1.0, 1.0, 540, 1000, 540, 1000), light=L((540, 500), (1, .85, .6), .7, 1000, (.55, .5, .48)), grade='warm', sfx=[(0, 'footsteps', .9), (.4, 'footsteps', .7)]))
SH.append(dict(t0=14.4, t1=17.4, trans='ink',
    bg=lambda t, u: sky("#e8b27c", "#c9915a"),
    fg=lambda t, u: "".join(soldiers(700 + r * 110, t + r, 10 + r * 3, "#5a2a1a" if r % 2 else "#3a1a10", .5 + r * .14, 30 + r) for r in range(7)),
    cam=(1.0, 1.12, 540, 1100, 540, 1000), light=L((540, 400), (1, .8, .55), .7, 1000, (.5, .45, .45)), grade='warm', sfx=[(0, 'roar', .5)]))
# ---------- L2 17.4-23.4 signature scale reveal
SH.append(dict(t0=17.4, t1=23.4, trans='ink',
    bg=lambda t, u: sky("#f7c98a", "#e8874a", "#b8653a") + C(540, 300, 90, "url(#sunG)", INK, 5),
    fg=lambda t, u: "".join(soldiers(500 + r * 90, t + r, 14 + r * 4, "#5a1a2a" if r % 2 else "#1a3a6a", .25 + r * .1, 40 + r) for r in range(14)) + soldiers(1500, t, 3, "#3a1a10", 2.6, 99, True, 300, 800),
    cam=(3.2, 1.0, 540, 1500, 540, 1000), camease='smooth', light=L((540, 300), (1, .8, .55), .8, 1200, (.5, .45, .45), rays=.25, nrays=22), grade='dawn', sfx=[(0, 'roar', .7), (0, 'wind', .6), (3.0, 'boom', .6)], mood=.6))
# ---------- L3 23.4-32.2 Bhishma vs Dhrishtadyumna
SH.append(dict(t0=23.4, t1=28.0, trans='ink',
    bg=lambda t, u: sky("#fbe8c0", "#e2b46a", "#b88a4a") + "".join(G(P("M300,-5 L900,0 L300,5 Z", "#fff3c4", op=.35), 540, 600, 1, i * 15 + t * 4) for i in range(24)),
    fg=lambda t, u: EP.chariot(540, 1250, 1.2, t, False, "#e2b13c") + bhishma(540, 560, 1.15, t, 'raise', dict(gaze=(0, .2), smile=.15), seg(u, .2, .6)),
    cam=(1.0, 1.25, 540, 1000, 540, 720), light=L((540, 500), (1, .92, .7), .7, 900, (.5, .46, .42)), grade='divine', bloom=.2, sfx=[(0, 'conch', .6), (2.0, 'shimmer', .4)]))
SH.append(dict(t0=28.0, t1=32.2, trans='flash', tdur=.2,
    bg=lambda t, u: sky("#3a0a0a", "#8a2a14", "#2a0a0a") + embers(t, 50, "#ff8a3a", .8),
    fg=lambda t, u: EP.fire(540, 1250, 3.0, t) + dhrishta(540, 560, 1.2, t, 'raise', dict(angry=.6, gaze=(0, -.2))),
    cam=(1.15, 1.0, 540, 760, 540, 860), light=L((540, 1250), (1, .5, .2), 1.3, 900, (.3, .2, .2)), grade='fire', sfx=[(0, 'fire_bed', .8), (.1, 'boom_soft', .7)]))
# ---------- L4 32.2-40.7 Narayani sena vs Krishna
SH.append(dict(t0=32.2, t1=36.4, trans='ink',
    bg=lambda t, u: sky("#3a2410", "#8a5a1a") + "".join(soldiers(980 + r * 70, t + r, 22, "#e2b13c", .35 + r * .1, 60 + r) for r in range(4)),
    fg=lambda t, u: rim(540, 620, 420, "#ffd36b", .3) + duryo(540, 620, 1.35, t, 'lift', dict(smile=.9, angry=0, gaze=(0, -.2))),
    cam=(1.0, 1.12, 540, 900, 540, 820), dof=4, light=L((540, 400), (1, .82, .5), .9, 900, (.4, .36, .34)), grade='warm', sfx=[(0, 'roar', .5), (.3, 'drum_hit', .6)]))
SH.append(dict(t0=36.4, t1=40.7, trans='ink',
    bg=lambda t, u: sky("#0e1a3a", "#2a3a6a", "#101a30") + C(540, 600, 400, "url(#glow)", op=.25),
    fg=lambda t, u: rim(700, 640, 360, "#9fd0ff", .4) + krishna(700, 600, 1.1, t, 'give', dict(gaze=(-1, .3), smile=.6)) + G(arjuna(0, 0, .95, t, 'down', dict(gaze=(1, -.4), smile=.3)), 300, 760, 1),
    cam=(1.0, 1.1, 520, 900, 540, 820), light=L((700, 500), (.7, .85, 1.0), 1.0, 800, (.4, .4, .5)), grade='night', sfx=[(0, 'flute_rise', .7), (.5, 'shimmer', .5)]))
# ---------- L5 40.7-44.6 conches, earth trembles
SH.append(dict(t0=40.7, t1=42.7, trans='flash', tdur=.15,
    bg=lambda t, u: sky("#f7c98a", "#e8874a") + EP.soundrings(540, 700, t * 2, "#fff3c4"),
    fg=lambda t, u: face_cu(dict(crown=True, feather=True, male=True, mustache=False, open=.2, t=t, skin="url(#skinB)"), 540, 760, 3.0) + G(EP.conch(0, 0, 1, 0), 330, 980, 2.6, -20),
    cam=(1.0, 1.2, 540, 760, 540, 760), light=L((540, 700), (1, .85, .6), .8, 800, (.55, .5, .48)), grade='warm', sfx=[(0, 'conch', 1.0)], mood=.9))
SH.append(dict(t0=42.7, t1=44.6, trans='cut',
    bg=lambda t, u: field(t) + dust(t * 4, 80, "#e8c890", .7),
    fg=lambda t, u: "".join(soldiers(1000 + r * 80, t * 2 + r, 24, "#5a1a2a" if r % 2 else "#1a3a6a", .4 + r * .12, 70 + r) for r in range(5)) + "".join(horse(100 + 340 * k, 880, 2.0, t * 3, k) for k in range(3)),
    cam=(1.0, 1.05, 540, 1100, 540, 1080), light=L((540, 760), (1, .8, .55), .8, 1100, (.5, .45, .45)), grade='dawn', shake=9, sfx=[(0, 'boom', .9), (0, 'roar', .8)], mood=1.0))
# ---------- L6 44.6-50.1 Arjuna lowers bow
SH.append(dict(t0=44.6, t1=47.2, trans='black', tdur=.35,
    bg=lambda t, u: sky("#5a3a3a", "#2a1a1a"),
    fg=lambda t, u: rim(540, 780, 380, "#ffcf9a", .25) + face_cu(dict(crown=True, mustache=True, male=True, sad=1, tears=seg(u, .2, .8), tremble=.6, open=.45, gaze=(0, .7), t=t, skin="url(#skinD)"), 540, 820, 3.1),
    cam=(1.0, 1.1, 540, 840, 540, 820), light=L((820, 520), (1, .8, .6), .8, 700, (.35, .32, .34)), grade='neutral', sfx=[(0, 'silence', 1), (0, 'heartbeat', .5)], mood=0))
SH.append(dict(t0=47.2, t1=50.1, trans='ink',
    bg=lambda t, u: sky("#3a2a2a", "#1a1010") + ground(1250, "#5a3a22"),
    fg=lambda t, u: EP.chariot(540, 1360, 1.6, t, False, "#1f5fa8") + EP.bow(540 + 80 * seg(u, 0, .7), 760 + 420 * seg(u, 0, .7), 1.6, 80 * seg(u, 0, .7)),
    cam=(1.1, 1.0, 540, 1000, 540, 1040), light=L((540, 700), (1, .82, .6), .9, 700, (.3, .28, .3)), grade='neutral', sfx=[(1.9, 'drum_low', 1.0), (1.95, 'twang', .5)], mood=.1))
SH.append(dict(t0=50.1, t1=53.9, trans='black', tdur=.4,
    bg=lambda t, u: sky("#2a1a12", "#120a08") + embers(t, 20, "#ffb050", .5),
    fg=lambda t, u: f'<g opacity=".3">' + EP.chariot(540, 700, 1.0, t) + '</g>',
    cam=(1, 1.05, 540, 960, 540, 960), light=L((540, 600), (1, .7, .5), .6, 900, (.5, .42, .42)), grade='warm', sfx=[(0, 'drum_hit', .6)], mood=.2))
