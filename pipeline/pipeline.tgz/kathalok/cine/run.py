import sys, json, importlib, os, math
import numpy as np
sys.path.insert(0, '/home/claude/kathalok/cine')
import cine
from cine import W, H, FPS, cl
import kgbase as K
from PIL import Image, ImageDraw

mod = importlib.import_module(sys.argv[1])
ID = mod.ID; SH = mod.SH
ROOT = f'/home/claude/kathalok/cine/{ID}'; os.makedirs(ROOT + '/frames', exist_ok=True)
d = json.load(open('/home/claude/kathalok/b1/batch1.json')); d = d if isinstance(d, list) else d['episodes']
LINES = [e for e in d if e['id'] == ID][0]['vo']
TM = json.load(open(f'/home/claude/kathalok/b2/{ID}/times.json'))
DUR = SH[-1]['t1']


def subtitle(img, text, u, y=1300, sz=44):
    dr = ImageDraw.Draw(img); f = K.font(sz); maxw = 800
    words = text.split(" "); ls = []; cur = []
    for w_ in words:
        if dr.textlength(" ".join(cur + [w_]), font=f) <= maxw: cur.append(w_)
        else: ls.append(cur); cur = [w_]
    ls.append(cur); lh = int(sz * 1.45)
    total = sum(len(w_) for w_ in words); cut = u * total * 1.08; acc = 0
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    od.rounded_rectangle([120, y - 16, 960, y - 16 + lh * len(ls) + 26], 24, fill=(14, 8, 4, 150))
    img.alpha_composite(ov); dr = ImageDraw.Draw(img)
    for i, l in enumerate(ls):
        x = (W - dr.textlength(" ".join(l), font=f)) / 2
        for w_ in l:
            col = (255, 213, 74) if acc < cut <= acc + len(w_) + 1 else ((255, 255, 255) if acc < cut else (215, 205, 190))
            dr.text((x, y + i * lh), w_, font=f, fill=col, stroke_width=3, stroke_fill=(0, 0, 0)); x += dr.textlength(w_ + " ", font=f); acc += len(w_) + 1


def frame(n):
    t = n / FPS
    img = cine.render(SH, t).convert('RGBA')
    li = max(k for k in range(len(TM)) if TM[k] <= t)
    if li < len(LINES) and t < TM[-1]:
        u = cl((t - TM[li]) / max(.5, (TM[li + 1] - TM[li]) - .4))
        subtitle(img, LINES[li], u)
        if t > TM[1] - .2: K.ctext(img, mod.TAG, 160, 32, (255, 233, 176), None, (90, 20, 10, 170))
    if t < TM[1] - .3:
        a = cl(t / .3)
        K.ctext(img, mod.HOOK, 210, 66, (255, 213, 74))
    if t >= TM[-1]:
        K.ctext(img, "आगे क्या हुआ?", 860, 86, (255, 213, 74))
        K.ctext(img, "कमेंट में लिखें 'कथा'", 1010, 58, (255, 255, 255), (0, 0, 0))
        K.ctext(img, "पूरी कहानी यूट्यूब पर | लिंक बायो में", 1120, 44, (255, 233, 176), (0, 0, 0))
        K.ctext(img, "फ़ॉलो करें | कथालोक", 1220, 48, (255, 213, 74), (0, 0, 0))
    return img.convert('RGB')


def audio():
    import soundfile as sf, sfx
    vo, sr = sf.read(f'/home/claude/kathalok/b2/{ID}/vo.wav')
    if vo.ndim > 1: vo = vo.mean(1)
    idx = np.arange(0, len(vo), sr / sfx.SR); vo = np.interp(idx, np.arange(len(vo)), vo)
    ev = []; sil = []; moods = []
    for s in SH:
        moods.append((s['t0'], s['t1'], s.get('mood', {'blood': .9, 'fire': .8, 'storm': .9}.get(s.get('grade'), .35))))
        for rel, name, g in s.get('sfx', []):
            if name == 'silence': sil.append((s['t0'] - .2, s['t0'] + 1.3)); continue
            ev.append((s['t0'] + rel, name, g, s['t1'] - s['t0'] - rel + .4))
    mix = sfx.mixdown(DUR, vo, ev, moods, sil)
    mix = mix / (np.abs(mix).max() + 1e-6) * .9
    sf.write(f'{ROOT}/mix.wav', mix.astype(np.float32), sfx.SR)


if __name__ == '__main__':
    if sys.argv[2] == 'sheet':
        mids = [((s['t0'] + s['t1']) / 2) for s in SH]
        ims = [frame(int(m * FPS)).resize((216, 384)) for m in mids]
        cols = 6; rows = math.ceil(len(ims) / cols)
        sh = Image.new('RGB', (216 * cols, 384 * rows))
        for k, im in enumerate(ims): sh.paste(im, ((k % cols) * 216, (k // cols) * 384))
        sh.save(f'{ROOT}/sheet.jpg'); print('frames', int(DUR * FPS))
    elif sys.argv[2] == 'audio':
        audio()
    else:
        a, b = int(sys.argv[2]), int(sys.argv[3])
        for n in range(a, b):
            frame(n).save(f'{ROOT}/frames/f{n:05d}.jpg', quality=92)
