import numpy as np
SR = 48000
rng = np.random.default_rng(11)


def t_(d): return np.arange(int(d * SR)) / SR


def env(n, a=.005, r=4.):
    tt = np.arange(n) / SR
    return np.minimum(1, tt / max(a, 1e-4)) * np.exp(-tt * r)


def lp(x, k=8):
    if k <= 1: return x
    c = np.cumsum(np.insert(x, 0, 0)); y = (c[k:] - c[:-k]) / k
    return np.concatenate([y, np.zeros(k - 1)])


def noise(d): return rng.normal(0, 1, int(d * SR))


def sweep_noise(d, k0, k1):
    n = noise(d); out = np.zeros_like(n); seg = 2400
    for i in range(0, len(n), seg):
        k = int(k0 + (k1 - k0) * i / len(n)); out[i:i + seg] = lp(n[i:i + seg + k], max(1, k))[:len(n[i:i + seg])]
    return out


def S(name, d=None):
    if name == 'boom':
        tt = t_(2.5); return .9 * np.sin(2 * np.pi * (45 + 60 * np.exp(-tt * 6)) * tt) * np.exp(-tt * 1.6) + .3 * lp(noise(2.5), 40) * np.exp(-tt * 3)
    if name == 'boom_soft':
        tt = t_(2.0); return .6 * np.sin(2 * np.pi * (60 + 40 * np.exp(-tt * 5)) * tt) * np.exp(-tt * 2)
    if name == 'thunder':
        tt = t_(3.5); n = lp(noise(3.5), 60); return .8 * n * (np.exp(-tt * 1.2) * (1 + .6 * np.sin(tt * 9) ** 2)) / (np.abs(n).max() + 1e-6) * 2
    if name == 'drum_hit' or name == 'drum_low':
        tt = t_(1.4); f = 70 if name == 'drum_hit' else 52
        return .9 * np.sin(2 * np.pi * (f + 50 * np.exp(-tt * 18)) * tt) * np.exp(-tt * 5) + .15 * lp(noise(1.4), 6) * np.exp(-tt * 25)
    if name == 'gong':
        tt = t_(5); return sum(a * np.sin(2 * np.pi * f * tt + p) for f, a, p in [(110, .5, 0), (163, .3, 1), (231, .25, 2), (347, .15, 1), (522, .08, 0)]) * np.exp(-tt * .7) * np.minimum(1, tt / .01)
    if name in ('chime', 'chime_dark'):
        tt = t_(3); base = 1318 if name == 'chime' else 660
        return sum(.2 * np.sin(2 * np.pi * base * m * tt) * np.exp(-tt * (2 + m)) for m in (1, 1.5, 2.01, 2.76))
    if name == 'shimmer':
        tt = t_(2.5); return sum(.08 * np.sin(2 * np.pi * f * tt) * np.exp(-((tt - .3 - i * .12) ** 2) * 6) for i, f in enumerate([1568, 1760, 2093, 2349, 2637, 3136]))
    if name in ('whoosh', 'whoosh_soft'):
        d = .9; tt = t_(d); n = sweep_noise(d, 40, 4); e = np.sin(np.pi * tt / d) ** 2
        return (1 if name == 'whoosh' else .5) * n * e / (np.abs(n).max() + 1e-6)
    if name == 'chakra':
        tt = t_(2.2); n = lp(noise(2.2), 3); am = .5 + .5 * np.sin(2 * np.pi * 18 * tt)
        return .5 * n * am * np.sin(np.pi * tt / 2.2) / 3 + .3 * np.sin(2 * np.pi * 220 * tt) * am * np.exp(-tt)
    if name == 'sword_ring':
        tt = t_(2.5); return sum(.2 * np.sin(2 * np.pi * f * tt) * np.exp(-tt * r) for f, r in [(2200, 2), (3300, 3), (4700, 4)]) + .3 * lp(noise(2.5), 2) * np.exp(-tt * 40)
    if name == 'heartbeat':
        out = np.zeros(int(4.5 * SR))
        for k in range(5):
            for off, a in ((0, 1), (.22, .7)):
                i = int((k * .85 + off) * SR); tt = t_(.3)
                out[i:i + len(tt)] += a * .8 * np.sin(2 * np.pi * 48 * tt) * np.exp(-tt * 18)
        return out
    if name == 'baby':
        tt = t_(1.2); f = 520 + 80 * np.sin(tt * 9); return .15 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * tt / 1.2) ** 2
    if name == 'cloth':
        d = .5; return .3 * lp(noise(d), 3) * np.sin(np.pi * t_(d) / d) ** 2
    if name == 'crow':
        out = np.zeros(int(2 * SR))
        for k in range(3):
            tt = t_(.25); i = int(k * .45 * SR); out[i:i + len(tt)] += .3 * np.sign(np.sin(2 * np.pi * (700 - 300 * tt) * tt)) * lp(np.ones(len(tt)), 1) * np.sin(np.pi * tt / .25)
        return lp(out, 6)
    if name == 'conch':
        tt = t_(3.5); f = 233 * (1 + .01 * np.sin(tt * 5)); ph = 2 * np.pi * np.cumsum(f) / SR
        e = np.minimum(1, tt / .5) * np.minimum(1, (3.5 - tt) / .6)
        return .35 * e * (np.sin(ph) + .5 * np.sin(2 * ph) + .3 * np.sin(3 * ph) + .2 * np.sin(4 * ph) + .05 * lp(noise(3.5), 4))
    if name == 'twang':
        tt = t_(1.2); return .4 * np.sin(2 * np.pi * (180 - 40 * tt) * tt) * np.exp(-tt * 5) + .2 * lp(noise(1.2), 2) * np.exp(-tt * 60)
    if name == 'splash':
        tt = t_(1.5); return .5 * lp(noise(1.5), 4) * np.exp(-tt * 3) * np.minimum(1, tt / .02)
    if name == 'roar':
        tt = t_(3); return .5 * lp(noise(3), 25) * np.sin(np.pi * tt / 3) * (1 + .4 * np.sin(tt * 30))
    if name == 'flute_rise':
        tt = t_(2.5); f = 520 * 2 ** (tt / 2.5 * .5); ph = 2 * np.pi * np.cumsum(f) / SR
        return .18 * (np.sin(ph) + .2 * np.sin(2 * ph)) * np.sin(np.pi * tt / 2.5)
    return np.zeros(int(.1 * SR))


def bed(name, d):
    tt = t_(d)
    if name == 'fire_bed':
        n = lp(noise(d), 10) * .15; cr = (rng.random(len(tt)) > .9993) * rng.normal(0, 1, len(tt)) * 2
        return n + lp(cr, 2) * .3
    if name == 'wind':
        return lp(noise(d), 60) * (0.4 + .3 * np.sin(tt * .9)) * 1.2
    if name == 'waves':
        return lp(noise(d), 30) * (0.5 + .5 * np.sin(tt * 1.1) ** 2) * 1.5
    if name == 'rain':
        return lp(noise(d), 2) * .12
    if name == 'birds':
        out = np.zeros(len(tt))
        for k in range(int(d * 2)):
            i = int(rng.uniform(0, d - .3) * SR); t2 = t_(.15); out[i:i + len(t2)] += .12 * np.sin(2 * np.pi * (3000 + 1500 * np.sin(t2 * 60)) * t2) * np.sin(np.pi * t2 / .15)
        return out
    if name == 'cave_drip':
        out = lp(noise(d), 80) * .2
        for k in range(int(d)):
            i = int(rng.uniform(0, d - .3) * SR); t2 = t_(.3); out[i:i + len(t2)] += .25 * np.sin(2 * np.pi * (1200 - 600 * t2) * t2) * np.exp(-t2 * 20)
        return out
    if name == 'footsteps':
        out = np.zeros(len(tt))
        for k in range(int(d / .45)):
            i = int(k * .45 * SR); t2 = t_(.12); out[i:i + len(t2)] += .3 * lp(noise(.12), 12) * np.exp(-t2 * 40)
        return out
    if name == 'drone_in':
        return S('boom_soft')[:len(tt)] if False else np.zeros(len(tt))
    return np.zeros(len(tt))


BEDS = {'fire_bed', 'wind', 'waves', 'rain', 'birds', 'cave_drip', 'footsteps', 'drone_in'}


def music(dur, moods, silences, seed=3):
    """tanpura drone + low dhol pulse + bansuri phrases. moods: list of (t0,t1,intensity 0..1). silences: list of (t0,t1)."""
    r = np.random.default_rng(seed); n = int(dur * SR); tt = np.arange(n) / SR; out = np.zeros(n)
    sa = 110.0; seq = [1.5 * sa, 2 * sa, 2 * sa, sa]; i = 0; tp = 0
    while tp < dur:
        f = seq[i % 4]; idx = int(tp * SR); L = min(int(3.2 * SR), n - idx); t2 = np.arange(L) / SR
        out[idx:idx + L] += .12 * (np.sin(2 * np.pi * f * t2) + .6 * np.sin(2 * np.pi * 2.003 * f * t2) + .4 * np.sin(2 * np.pi * 3.01 * f * t2) + .25 * np.sin(2 * np.pi * 4.02 * f * t2)) * np.minimum(1, t2 / .01) * np.exp(-t2 * .9)
        i += 1; tp += .34 * (1 if i % 4 else 2.0)
    inten = np.zeros(n)
    for a, b, v in moods: inten[int(a * SR):int(b * SR)] = v
    inten = lp(inten, 4800)
    beat = .5; k = 0
    while k * beat < dur:
        idx = int(k * beat * SR); L = min(int(.6 * SR), n - idx); t2 = np.arange(L) / SR
        hit = (np.sin(2 * np.pi * (62 + 40 * np.exp(-t2 * 20)) * t2) * np.exp(-t2 * 7)) * (1 if k % 4 == 0 else .55)
        out[idx:idx + L] += .55 * hit * inten[idx:idx + L]
        if k % 2 == 1:
            out[idx:idx + L] += .12 * lp(r.normal(0, 1, L), 3) * np.exp(-t2 * 30) * inten[idx:idx + L]
        k += 1
    gain = np.ones(n)
    for a, b in silences:
        ia, ib = int(a * SR), int(b * SR); gain[ia:ib] = 0.05
    gain = lp(gain, 2400)
    return out * gain


def mixdown(dur, vo, events, moods, silences):
    n = int(dur * SR); sfx = np.zeros(n)
    for t0, name, g, d in events:
        x = bed(name, d) if name in BEDS else S(name)
        if name == 'silence': continue
        i = int(t0 * SR); L = min(len(x), n - i)
        if L > 0: sfx[i:i + L] += g * x[:L] * (np.minimum(1, np.arange(L) / (SR * .3)) * np.minimum(1, (L - np.arange(L)) / (SR * .3)) if name in BEDS else 1)
    mu = music(dur, moods, silences)
    v = np.zeros(n); v[:min(n, len(vo))] = vo[:n]
    env_v = lp(lp(np.abs(v), 9600), 9600); duck = 1 - .6 * np.clip(env_v / (env_v.max() + 1e-6) * 4, 0, 1)
    return v * 1.15 + mu * .38 * duck + sfx * .45 * (1 - .35 * (duck < .7))
