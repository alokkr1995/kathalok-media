from props import *
import math

ID = 'HN-01'
TAG = "हनुमान - जन्म कथा  |  भाग 1"
HOOK = "एक श्राप से जन्मा महावीर!"
L = lambda pos, col=(1, .85, .6), power=.9, radius=900, amb=(.5, .48, .5), **k: dict(pos=pos, col=col, power=power, radius=radius, amb=amb, **k)


def apsara(x, y, s, t, o=None, arms='lift', lift=.6, saree="url(#purp)"):
    f = dict(open=blink(t, 2.4), smile=.7); f.update(o or {})
    return woman(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, saree=saree, border="url(#bord)", face=f, lift=lift))[0]


def anjana(x, y, s, t, arms='down', o=None, pose='stand'):
    f = dict(open=blink(t, 2.7), smile=.3); f.update(o or {})
    body = woman(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, saree="url(#red)", border="url(#bord)", face=f))[0]
    return EP.tail(x + 60 * s, y + (330 if pose == 'stand' else 300) * s, s * 1.4, t) + body


def kesari(x, y, s, t, arms='down', o=None):
    f = dict(crown=True, mustache=True, beard="#8a5a2c", smile=.5, open=blink(t, 3.0), skin="url(#skinD)"); f.update(o or {})
    body = man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#gold)", dhoti="url(#red)", angavastram="#a8322a", armskin="url(#skinD)", face=f))[0]
    return EP.tail(x + 60 * s, y + 300 * s, s * 1.5, t) + body


def sage_(x, y, s, t, arms='rest', o=None, pose='sit'):
    return EP.sage(x, s, t, arms, o or {}, pose, "url(#saff)", y=y)[0]


def petals(t, n=50, seed=5):
    import random
    r = random.Random(seed); s = []
    for k in range(n):
        x = (r.uniform(0, W) + 40 * math.sin(t + k)) % W; y = (r.uniform(0, H) + t * r.uniform(60, 140)) % H
        s.append(G(E(0, 0, 10, 5, "#e0507a" if k % 2 else "#ffd36b", "none", 0, .85), x, y, 1, t * 60 + k * 20))
    return "".join(s)


def kheer(x, y, s, glow=1.):
    return G(C(0, 0, 160, "url(#glow)", op=.7 * glow) + E(0, 10, 70, 26, "url(#gold)", INK, 4) + E(0, 2, 56, 14, "#fbf3e0", "none") + C(-14, 0, 4, "#c0392b") + C(16, 2, 4, "#5a9a5c"), x, y, s)


def wind_swirl(t, x, y, s, op=.8):
    g = ""
    for k in range(5):
        r0 = 60 + k * 40; a0 = t * 3 + k
        g += P(f"M{r0 * math.cos(a0):.0f},{r0 * math.sin(a0):.0f} A{r0},{r0} 0 0 1 {r0 * math.cos(a0 + 2.2):.0f},{r0 * math.sin(a0 + 2.2):.0f}", "none", "#e6f4ff", 8 - k, op)
    return G(g, x, y, s)


SH = []
# L0 0-6.2
SH.append(dict(t0=0, t1=3.0, trans='cut',
    bg=lambda t, u: sky("#f6d7e8", "#c9a0d8", "#8a6ab0") + EP.clouds(t, "#fbf3fa", 1250, .95) + dust(t, 50, "#fff8ff", .7),
    fg=lambda t, u: rim(540, 700, 380, "#fff3ff", .5) + apsara(540, 560 + 14 * math.sin(t * 2), 1.15, t, dict(smile=.8), 'lift', .5 + .3 * math.sin(t * 2.5)),
    cam=(1.0, 1.1, 540, 860, 540, 820), light=L((540, 500), (1, .92, 1), .7, 900, (.55, .5, .58)), grade='divine', bloom=.25, sfx=[(0, 'shimmer', .7), (.1, 'chime', .5)], mood=.3))
SH.append(dict(t0=3.0, t1=6.2, trans='flash', tdur=.2,
    bg=lambda t, u: sky("#ffcf6a", "#f08a3a", "#8a2a1a") + C(540, 760, 340, "url(#sunG)", INK, 6) + C(540, 760, 700, "url(#glow)", op=.5),
    fg=lambda t, u: G(kesari(0, 0, .55, t, 'raise', dict(open=1, smile=.6)) , 120 + 820 * seg(u, .1, .9), 1150 - 700 * math.sin(math.pi * seg(u, .1, .9)), 1, 30).replace("url(#gold)", "#2a1408").replace("url(#red)", "#2a1408").replace("url(#skinD)", "#2a1408"),
    cam=(1.0, 1.05, 540, 860, 540, 860), light=L((540, 760), (1, .75, .4), 1.1, 800, (.45, .35, .3)), grade='fire', sfx=[(0, 'whoosh', .9), (.3, 'boom', .8)], mood=.9))
# L1 6.2-13.9
SH.append(dict(t0=6.2, t1=9.6, trans='ink',
    bg=lambda t, u: sky("#e8e0b8", "#b8b07a") + hills(980, t, "#8a9a52", 120, 2, .9) + EP.tree(950, 1200, 1.2, t),
    fg=lambda t, u: ground(1180, "#a8a06a") + sage_(330, 1180 - 350, 1.0, t, 'rest', dict(open=.1 + .9 * seg(u, .6, .75), angry=seg(u, .6, .8), gaze=(1, 0))) + apsara(780, 1180 - 596 * .8, .8, t, dict(smile=.9, gaze=(-1, 0)), 'lift', .6 + .3 * math.sin(t * 4)),
    cam=(1.0, 1.1, 540, 960, 520, 900), light=L((800, 500), (1, .9, .7), .7, 1000, (.55, .52, .5)), grade='warm', sfx=[(0, 'birds', .4), (.3, 'chime', .4), (2.1, 'drum_low', .7)], mood=.3))
SH.append(dict(t0=9.6, t1=13.9, trans='cut',
    bg=lambda t, u: sky("#3a0a0a", "#8a1a14", "#2a0606") + embers(t, 40, "#ff6a3a", .7),
    fg=lambda t, u: (face_cu(dict(old=True, beard="#e4ddd2", hair="#d8d2c8", jata=True, tilak=True, wrinkles=True, male=True, angry=1, mouthOpen=.5 * abs(math.sin(t * 7)), open=1, t=t, skin="url(#skinD)"), 540, 760, 3.0) if u < .5 else
                     f'<g opacity="{1 - seg(u, .5, .9):.2f}">' + apsara(540, 560, 1.1, t, dict(sad=1, tears=1, smile=0, tremble=.8), 'shield', 0) + f'</g><g opacity="{seg(u, .55, .95):.2f}">' + anjana(540, 560, 1.1, t, 'shield', dict(sad=1, tears=1, tremble=.6)) + '</g>' + C(540, 800, 200 + 700 * seg(u, .5, .8), "url(#glow)", op=max(0, .9 - abs(seg(u, .5, .9) - .4) * 2))),
    cam=(1.0, 1.08, 540, 820, 540, 820), light=L((540, 1300), (1, .45, .25), 1.2, 900, (.35, .25, .28)), grade='blood', flash=lambda t, u: .8 * max(0, 1 - abs(u - .5) * 12), shake=lambda t, u: 7 * (u < .5), sfx=[(0, 'drum_hit', .9), (2.1, 'boom', 1.0), (2.2, 'shimmer', .6)], mood=.9))
# L2 13.9-18.5
SH.append(dict(t0=13.9, t1=18.5, trans='ink',
    bg=lambda t, u: sky("#e6efc4", "#9fb86a") + EP.tree(80, 1250, 1.4, t) + EP.tree(1000, 1250, 1.3, t, "#7f9c56") + P("M220,560 Q540,420 860,560", "none", "#e0507a", 18) + "".join(C(220 + k * 64, 560 - 140 * math.sin(math.pi * k / 10), 14, "#ffd36b" if k % 2 else "#e0507a", INK, 2) for k in range(11)),
    fg=lambda t, u: ground(1230, "#8a9a52") + anjana(360, 1230 - 596 * 1.0, 1.0, t, 'pray', dict(smile=.8, gaze=(1, 0))) + kesari(720, 1230 - 550 * 1.05, 1.05, t, 'bless', dict(smile=.8, gaze=(-1, 0))),
    ov=lambda t, u: petals(t),
    cam=(1.0, 1.12, 540, 960, 540, 880), light=L((540, 500), (1, .9, .7), .7, 1000, (.55, .52, .5)), grade='warm', sfx=[(0, 'chime', .5), (0, 'birds', .5)], mood=.4))
# L3 18.5-23.4
SH.append(dict(t0=18.5, t1=23.4, trans='black', tdur=.4,
    bg=lambda t, u: sky("#0b1428", "#1a2a50") + G("".join(C(x - 540, y - 960, r, "#fff3c4", op=.3 + .5 * abs(math.sin(t + p))) for x, y, p, r in K.STARS[:90]), 540, 960, 1, u * 25) + C(830, 300, 80, "url(#moonG)", INK, 4) + P("M-200,1300 L250,700 L540,940 L860,620 L1300,1300 Z", "#2a3450", INK, 6) + P("M250,700 L320,780 L200,790 Z M860,620 L930,700 L800,710 Z", "#e6eef8", "none"),
    fg=lambda t, u: ground(1250, "#1c2438") + EP.linga(780, 1240, .9) + C(780, 1140, 260, "url(#glow)", op=.3 + .15 * math.sin(t * 2)) + anjana(330, 1250 - 400 * .95, .95, t, 'pray', dict(open=.08, smile=.25), 'kneel'),
    cam=(1.0, 1.1, 540, 1000, 560, 1020), light=L((780, 1100), (.75, .85, 1.0), 1.0, 700, (.3, .32, .42)), grade='night', sfx=[(0, 'wind', .5), (.5, 'gong', .5)], mood=.2))
# L4 23.4-32.2
SH.append(dict(t0=23.4, t1=27.6, trans='ink',
    bg=lambda t, u: sky("#3a1a0a", "#8a4a1a") + "".join(f'<rect x="{x - 40}" y="300" width="80" height="1000" fill="#5a3a1a" stroke="{INK}" stroke-width="5"/>' for x in (120, 960)) + embers(t, 40, "#ffb050", .8),
    fg=lambda t, u: EP.fire(540, 1180, 2.2, t) + man(dict(x=820, y=640, s=1.0, pose='stand', arms='give', t=t, upper="url(#gold)", dhoti="url(#red)", angavastram="#a8322a", face=dict(crown=True, mustache=True, beard="#d8d2c8", old=True, open=blink(t, 3), gaze=(-1, .5), smile=.3)))[0] + kheer(540, 980 - 300 * seg(u, .4, .9), 1.3, seg(u, .3, .7)),
    cam=(1.0, 1.1, 600, 960, 580, 900), light=L((540, 1100), (1, .55, .25), 1.2, 900, (.35, .28, .26)), grade='fire', sfx=[(0, 'fire_bed', .7), (0, 'drone_in', .4), (2.0, 'shimmer', .5)], mood=.5))
SH.append(dict(t0=27.6, t1=32.2, trans='flash', tdur=.15,
    bg=lambda t, u: sky("#f6c98a", "#e8874a") + C(800, 400, 100, "url(#sunG)", INK, 5),
    fg=lambda t, u: (kheer(540, 980, 1.3) if u < .35 else "") + EP.bird(1300 - 800 * seg(u, 0, .35) - 900 * seg(u, .35, 1), 200 + 780 * seg(u, 0, .35) - 700 * seg(u, .35, 1), 1.6, t, u >= .35) + "".join(P(f"M{1100 - 800 * u + k * 40},{300 + k * 60} l160,-60", "none", "#fff", 4, .5 * (u > .3)) for k in range(5)),
    cam=(1.1, 1.0, 540, 900, 540, 860), camease='lin', light=L((800, 400), (1, .82, .55), .7, 1000, (.55, .5, .48)), grade='warm', shake=lambda t, u: 6 * (abs(u - .35) < .05), sfx=[(0, 'whoosh', .9), (1.5, 'crow', .5), (1.6, 'whoosh', .7)], mood=.8))
# L5 32.2-38.1
SH.append(dict(t0=32.2, t1=35.4, trans='ink',
    bg=lambda t, u: sky("#a0c8f0", "#5a86c0") + EP.clouds(t * 2, "#e6f0fa", 500, .9) + P("M-200,1500 L300,1000 L560,1200 L900,900 L1300,1500 Z", "#4a5a7a", INK, 6) + face_cu(dict(male=True, open=.3, smile=.5, t=t, skin="#cfe4ff"), 200, 420, 1.6).replace(INK, "#9fb8de"),
    fg=lambda t, u: wind_swirl(t, 900 - 700 * u, 600 + 300 * u, 1.4) + kheer(900 - 700 * u, 600 + 300 * u, .8),
    cam=(1.0, 1.05, 540, 900, 540, 920), light=L((540, 500), (.9, .95, 1), .7, 1000, (.55, .55, .62)), grade='neutral', sfx=[(0, 'wind', .9), (0, 'whoosh_soft', .6)], mood=.4))
SH.append(dict(t0=35.4, t1=38.1, trans='ink',
    bg=lambda t, u: sky("#0b1428", "#1a2a50") + C(830, 300, 70, "url(#moonG)", INK, 4),
    fg=lambda t, u: G(K.hand(0, 0, -90, 4.2, "open", "url(#skin)"), 540, 1200, 1) + kheer(540, 820 + 240 * seg(u, 0, .6), 1.2, 1) + wind_swirl(t, 540, 900, 1.2, .6 * (1 - u)),
    cam=(1.0, 1.15, 540, 960, 540, 1000), light=L((540, 1000), (1, .9, .65), 1.2, 600, (.3, .32, .42)), grade='night', bloom=.3, sfx=[(0, 'shimmer', .8), (1.7, 'chime', .6)], mood=.3))
# L6 38.1-44.9
SH.append(dict(t0=38.1, t1=41.5, trans='ink',
    bg=lambda t, u: sky("#2a1a3a", "#5a3a5a") + EP.trishul(540, 760, 2.4, .2 + .5 * seg(u, .2, .9)),
    fg=lambda t, u: rim(540, 780, 400, "#ffe08a", .4 * seg(u, .3, 1)) + face_cu(dict(open=.05, smile=.5, pallu="url(#red)", border="url(#bord)", t=t), 540, 800, 2.9),
    cam=(1.0, 1.1, 540, 860, 540, 840), light=lambda t, u: L((540, 800), (1, .9, .6), 1.0, 700, (.4, .36, .42), rays=.3 * seg(u, .3, 1), nrays=18), grade='divine', sfx=[(0, 'drone_in', .4), (1.5, 'gong', .7)], mood=.4))
SH.append(dict(t0=41.5, t1=44.9, trans='flash', tdur=.25,
    bg=lambda t, u: sky("#f6dcae", "#f3a96a") + "".join(G(P("M300,-6 L900,0 L300,6 Z", "#fff3c4", op=.4), 540, 820, 1, i * 15 + t * 8) for i in range(24)) + EP.trishul(540, 620, 1.6, .5),
    fg=lambda t, u: anjana(430, 520, 1.15, t, 'hold', dict(open=.6 * blink(t), gaze=(.7, 1), smile=.8)) + baby(560, 860, 1.25, t, eyes=1) + EP.tail(620, 940, .6, t) + G(kesari(0, 0, .8, t, 'lift', dict(smile=1, gaze=(-1, .3))), 900, 600, 1),
    cam=(1.0, 1.1, 600, 900, 580, 860), light=L((540, 700), (1, .88, .6), .9, 900, (.5, .45, .45)), grade='warm', bloom=.3, sfx=[(0, 'boom_soft', .6), (.3, 'baby', .6), (.4, 'conch', .5)], mood=.6))
# L7 44.9-51.6
SH.append(dict(t0=44.9, t1=48.2, trans='ink',
    bg=lambda t, u: sky("#ffd8a0", "#f49a4a", "#c96a3a") + C(800, 520 - 120 * u, 150, "url(#sunG)", INK, 6) + C(800, 520 - 120 * u, 400, "url(#glow)", op=.5) + hills(1250, t, "#8a4e3a", 90, 3),
    fg=lambda t, u: ground(1260, "#7a4a2a") + G(baby(0, 0, 1.5, t, eyes=1) + EP.tail(70, 70, .8, t), 360, 1080, 1),
    cam=(1.0, 1.12, 540, 1000, 460, 960), light=L((800, 450), (1, .8, .5), 1.1, 900, (.45, .38, .38)), grade='dawn', sfx=[(0, 'birds', .4), (.6, 'baby', .5), (1.5, 'heartbeat', .5)], mood=.3))
SH.append(dict(t0=48.2, t1=51.6, trans='cut',
    bg=lambda t, u: sky("#ffcf6a", "#f08a3a", "#a83a1a") + C(800, 300, 260 + 200 * u, "url(#sunG)", INK, 6) + C(800, 300, 700, "url(#glow)", op=.6),
    fg=lambda t, u: G(baby(0, 0, 1.2, t, eyes=1) + EP.tail(60, 60, .7, t), 300 + 360 * seg(u, 0, .8), 1300 - 800 * seg(u, 0, .8), 1, -25) + "".join(P(f"M{300 + 360 * seg(u, 0, .8) - 60 - k * 30},{1360 - 800 * seg(u, 0, .8) + 60 + k * 50} l-60,90", "none", "#fff3c4", 6, .7) for k in range(5)),
    cam=(1.0, 1.15, 540, 1100, 620, 760), light=L((800, 300), (1, .8, .45), 1.3, 900, (.5, .4, .35), rays=.4, nrays=16), grade='fire', bloom=.3, sfx=[(0, 'whoosh', 1.0), (.2, 'boom', .7)], mood=1.0))
SH.append(dict(t0=51.6, t1=55.4, trans='flash', tdur=.3,
    bg=lambda t, u: sky("#3a1a0a", "#1a0a04") + C(540, 560, 240, "url(#sunG)", INK, 5) + C(540, 560, 600, "url(#glow)", op=.3),
    fg=lambda t, u: "",
    cam=(1, 1.04, 540, 960, 540, 960), light=L((540, 560), (1, .7, .45), .7, 900, (.5, .42, .4)), grade='fire', sfx=[(0, 'drum_hit', .7)], mood=.2))
