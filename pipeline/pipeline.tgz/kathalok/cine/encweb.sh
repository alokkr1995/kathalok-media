#!/bin/bash
ID=$1; cd /home/claude/kathalok/cine
ffmpeg -y -loglevel error -framerate 30 -i $ID/frames/f%05d.jpg -i $ID/mix.wav -filter_complex "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[a];[0:v]noise=alls=4:allf=t[v]" -map "[v]" -map "[a]" -c:v libx264 -preset medium -crf 25 -pix_fmt yuv420p -c:a aac -b:a 192k -shortest -movflags +faststart /mnt/user-data/outputs/${ID}_web.mp4 && ls -l /mnt/user-data/outputs/${ID}_web.mp4
