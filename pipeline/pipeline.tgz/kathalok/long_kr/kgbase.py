import math, random, sys, io, json
import cairosvg
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

W, H, FPS = 1080, 1920, 30
INK = "#1a120d"
FONT = "/root/.fonts/NotoSansDevanagari-Bold.ttf"
TM = json.load(open('/home/claude/kathalok/k2/times.json'))
END = 3.8
TM.append(TM[-1] + END)
LINES = json.load(open('/home/claude/kathalok/b1/batch1.json'))[0]['vo']
XF = 0.5  # crossfade seconds
rng = random.Random(5)
STARS = [(rng.uniform(60, W - 60), rng.uniform(60, 1050), rng.uniform(0, 6.3), rng.uniform(1.5, 3.5)) for _ in range(110)]
MOTES = [(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(0, 6.3), rng.uniform(2, 5)) for _ in range(40)]


def cl(x, a=0., b=1.): return max(a, min(b, x))
def ease(u): u = cl(u); return u * u * (3 - 2 * u)
def seg(u, a, b): return ease((u - a) / (b - a))
def blink(t, period=3.3, off=0.):
    p = (t + off) % period
    return cl(abs(p - .09) / .09) if p < .18 else 1.
def wob(t, f=1., a=1., ph=0.): return a * math.sin(t * f + ph)


DEFS = """<defs>
<radialGradient id="skin" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#f7d4a4"/><stop offset=".7" stop-color="#eebd86"/><stop offset="1" stop-color="#d99a62"/></radialGradient>
<radialGradient id="skinD" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#e8b27c"/><stop offset="1" stop-color="#b9774a"/></radialGradient>
<radialGradient id="sunG" cx="50%" cy="45%" r="60%"><stop offset="0" stop-color="#fff2b0"/><stop offset=".6" stop-color="#f7c948"/><stop offset="1" stop-color="#e8952a"/></radialGradient>
<radialGradient id="glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#fff6cf" stop-opacity=".95"/><stop offset="1" stop-color="#ffd36b" stop-opacity="0"/></radialGradient>
<radialGradient id="moonG" cx="40%" cy="40%" r="60%"><stop offset="0" stop-color="#fffaf0"/><stop offset="1" stop-color="#d9d3c2"/></radialGradient>
<linearGradient id="red" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d4473a"/><stop offset="1" stop-color="#8f2219"/></linearGradient>
<linearGradient id="redN" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#a5352c"/><stop offset="1" stop-color="#5e1611"/></linearGradient>
<linearGradient id="green" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5a9a5c"/><stop offset="1" stop-color="#2d5c35"/></linearGradient>
<linearGradient id="saff" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f09a3c"/><stop offset="1" stop-color="#c25e1c"/></linearGradient>
<linearGradient id="white" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fbf6ea"/><stop offset="1" stop-color="#d9cfb8"/></linearGradient>
<linearGradient id="gold" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe08a"/><stop offset=".5" stop-color="#e2b13c"/><stop offset="1" stop-color="#a87418"/></linearGradient>
<linearGradient id="riverD" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a76ad"/><stop offset="1" stop-color="#1c3560"/></linearGradient>
<linearGradient id="riverN" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a4a7c"/><stop offset="1" stop-color="#0c1a33"/></linearGradient>
<linearGradient id="riverG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e79a5a"/><stop offset=".4" stop-color="#6a5a8a"/><stop offset="1" stop-color="#2b2e5a"/></linearGradient>
<radialGradient id="skinB" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#6f9fd8"/><stop offset="1" stop-color="#2d5c9a"/></radialGradient><radialGradient id="skinG" cx="45%" cy="38%" r="70%"><stop offset="0" stop-color="#6a5a5a"/><stop offset="1" stop-color="#2a1e1e"/></radialGradient><linearGradient id="yel" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f6d24a"/><stop offset="1" stop-color="#c99a18"/></linearGradient><linearGradient id="purp" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7a4a9a"/><stop offset="1" stop-color="#3e1f5a"/></linearGradient><linearGradient id="kunti" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4efe2"/><stop offset="1" stop-color="#cfc4ab"/></linearGradient>
<pattern id="dots" width="22" height="22" patternUnits="userSpaceOnUse"><circle cx="11" cy="11" r="3" fill="#f6d27a" opacity=".85"/></pattern>
<pattern id="buti" width="46" height="46" patternUnits="userSpaceOnUse"><path d="M23,10 Q30,23 23,34 Q16,23 23,10 Z" fill="#f6d27a" opacity=".7"/><circle cx="23" cy="38" r="2.5" fill="#f6d27a" opacity=".7"/></pattern>
<pattern id="bord" width="28" height="22" patternUnits="userSpaceOnUse"><rect width="28" height="22" fill="#e2b13c"/><path d="M0,22 L14,4 L28,22" fill="#a8322a"/><circle cx="14" cy="15" r="3" fill="#fff3c4"/></pattern>
<pattern id="bordG" width="28" height="22" patternUnits="userSpaceOnUse"><rect width="28" height="22" fill="#e2b13c"/><path d="M0,22 L14,4 L28,22" fill="#2d5c35"/><circle cx="14" cy="15" r="3" fill="#fff3c4"/></pattern>
<pattern id="weave" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M0,7 L14,7 M7,0 L7,14" stroke="#7a4e22" stroke-width="2"/></pattern>
</defs>"""


def P(d, fill="none", stroke=INK, sw=5, op=1., extra=""):
    return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw:.1f}" stroke-linejoin="round" stroke-linecap="round" opacity="{op:.2f}" {extra}/>'
def E(cx, cy, rx, ry, fill, stroke=INK, sw=5, op=1.):
    return f'<ellipse cx="{cx:.1f}" cy="{cy:.1f}" rx="{rx:.1f}" ry="{ry:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" opacity="{op:.2f}"/>'
def C(cx, cy, r, fill, stroke="none", sw=0, op=1.):
    return f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" opacity="{op:.2f}"/>'
def G(inner, x=0., y=0., s=1., r=0., sx=None):
    sc = f"{s:.4f}" if sx is None else f"{sx:.4f},{s:.4f}"
    return f'<g transform="translate({x:.1f},{y:.1f}) rotate({r:.2f}) scale({sc})">{inner}</g>'
def brush(d, w=6, col=INK, op=1.):  # Kalighat brush: soft under-stroke + crisp line
    return P(d, "none", col, w * 1.9, op * .25) + P(d, "none", col, w, op)


# ---------------------------------------------------------------- hand / limb
def hand(x, y, ang, sc=1., pose="open", fill="url(#skin)"):
    g = []
    if pose == "fist":
        g.append(E(0, 0, 20, 17, fill, INK, 3.5))
        for k in range(3): g.append(P(f"M{-8 + k * 8},-14 Q{-4 + k * 8},-2 {-8 + k * 8},12", "none", INK, 2))
    else:
        spread = 1.0 if pose == "open" else .35
        g.append(E(0, 0, 18, 22, fill, INK, 3.5))
        for k in range(4):
            a = -24 + k * 16 * spread; ln = 30 - abs(k - 1.5) * 4
            g.append(G(P(f"M-5,0 Q-6,{-ln * .6} 0,{-ln} Q6,{-ln * .6} 5,0 Z", fill, INK, 3), -9 + k * 6, -14, 1, a))
        g.append(G(P("M-5,0 Q-6,-14 0,-22 Q6,-14 5,0 Z", fill, INK, 3), -16, 2, 1, -70 * spread))
        g.append(C(0, -6, 2.5, "#c0392b", op=.8))  # alta/mehendi dot
    return G("".join(g), x, y, sc, ang)


def limb(pts, w1, w2, fill="url(#skin)"):
    (x1, y1), (x2, y2), (x3, y3) = pts
    def side(ax, ay, bx, by, wa, wb, sgn):
        dx, dy = bx - ax, by - ay; L = math.hypot(dx, dy) or 1; nx, ny = -dy / L * sgn, dx / L * sgn
        return (ax + nx * wa, ay + ny * wa), (bx + nx * wb, by + ny * wb)
    wm = (w1 + w2) / 2
    a1, b1 = side(x1, y1, x2, y2, w1, wm, 1); a2, b2 = side(x2, y2, x3, y3, wm, w2, 1)
    c1, d1 = side(x1, y1, x2, y2, w1, wm, -1); c2, d2 = side(x2, y2, x3, y3, wm, w2, -1)
    d = (f"M{a1[0]:.1f},{a1[1]:.1f} Q{b1[0]:.1f},{b1[1]:.1f} {b2[0]:.1f},{b2[1]:.1f} "
         f"L{d2[0]:.1f},{d2[1]:.1f} Q{d1[0]:.1f},{d1[1]:.1f} {c1[0]:.1f},{c1[1]:.1f} Z")
    return P(d, fill, INK, 4.5)


def arm(sx, sy, a1, l1, a2, l2, w=17, fill="url(#skin)", hpose="open", bangles="gold", hang=None):
    ex = sx + l1 * math.cos(math.radians(a1)); ey = sy + l1 * math.sin(math.radians(a1))
    hx = ex + l2 * math.cos(math.radians(a2)); hy = ey + l2 * math.sin(math.radians(a2))
    g = limb([(sx, sy), (ex, ey), (hx, hy)], w, w * .62, fill)
    if bangles:
        for k in range(4):
            bx = hx - (k * 7 + 4) * math.cos(math.radians(a2)); by = hy - (k * 7 + 4) * math.sin(math.radians(a2))
            col = "url(#gold)" if k % 2 == 0 else "#c0392b"
            g += G(E(0, 0, 4, w * .72, col, INK, 2), bx, by, 1, a2)
    g += hand(hx, hy, (a2 + 90) if hang is None else hang, 1., hpose, fill)
    return g, (hx, hy)


# ---------------------------------------------------------------- detailed face
def face(o):
    s = []; t = o.get('t', 0)
    sk = o.get('skin', "url(#skin)"); sad = o.get('sad', 0); ang = o.get('angry', 0); sm = o.get('smile', 0)
    op = o.get('open', 1.); gx, gy = o.get('gaze', (0, 0)); male = o.get('male', False)
    sacc = (wob(t, .7, .25, 1.3), wob(t, .5, .15)) if o.get('saccade', True) else (0, 0)
    gx += sacc[0]; gy += sacc[1]
    # back hair / bun / braid
    if not male:
        sway = wob(t, 1.6, 5)
        s.append(P(f"M-46,-40 Q-80,40 -60,{120} Q{-70 + sway},200 {-52 + sway},260", "none", INK, 26))  # braid
        for k in range(6): s.append(P(f"M{-62 + sway * k / 6 - 10},{140 + k * 20} l20,8", "none", "#3a2a22", 3))
        s.append(C(-50 + sway, 268, 9, "#c0392b", INK, 2))
    # neck
    s.append(P("M-20,48 Q-22,72 -26,100 L26,100 Q22,72 20,48 Z", sk, INK, 4))
    s.append(P("M-14,70 Q0,78 14,70", "none", "#a8724a", 2, .6))
    # ears + jhumka
    for sg in (-1, 1):
        s.append(E(sg * 53, 4, 9, 15, sk, INK, 3.5))
        if not male:
            sw_ = wob(t, 3.1, 8, sg)
            s.append(G(P("M0,0 L0,14", "none", "#a87418", 2) + P("M-11,14 Q0,4 11,14 L8,30 L-8,30 Z", "url(#gold)", INK, 2.5) +
                       "".join(C(-8 + k * 4, 32, 2.2, "#fff3c4", INK, .8) for k in range(5)), sg * 54, 16, 1, sw_))
        elif o.get('kundal'):
            s.append(C(sg * 56, 26, 9, "none", "url(#gold)", 5))
    # face
    s.append(P("M0,-66 C40,-66 56,-34 54,0 C52,36 30,62 0,64 C-30,62 -52,36 -54,0 C-56,-34 -40,-66 0,-66 Z", sk, INK, 5))
    s.append(E(-30, 22, 13, 8, "#e88a6a", "none", 0, .22 + .25 * sm)); s.append(E(30, 22, 13, 8, "#e88a6a", "none", 0, .22 + .25 * sm))
    s.append(P("M-46,10 Q-40,46 0,58", "none", "#b77a4a", 3, .35))
    # front hair
    if male:
        if o.get('turban'):
            tb = o['turban']
            s.append(P("M-62,-12 Q-66,-92 0,-98 Q66,-92 62,-12 Q34,-40 0,-40 Q-34,-40 -62,-12 Z", tb, INK, 5))
            for k in range(4): s.append(P(f"M-58,{-24 - k * 16} Q0,{-58 - k * 14} 58,{-24 - k * 16}", "none", INK, 2.5, .7))
            s.append(C(0, -70, 9, "url(#gold)", INK, 2)); s.append(P(f"M0,-78 Q{14 + wob(t, 2, 4)},-120 {30 + wob(t, 2, 6)},-128", "none", "#d4473a", 5))
        else:
            hc = o.get('hair', INK)
            s.append(P("M-56,-6 Q-62,-72 0,-74 Q62,-72 56,-6 Q44,-48 0,-48 Q-44,-48 -56,-6 Z", hc, INK, 4))
            if o.get('jata'):
                s.append(P("M-34,-60 Q-48,-150 0,-160 Q48,-150 34,-60 Z", hc, INK, 4))
                for k in range(7): s.append(P(f"M{-30 + k * 10},-64 Q{-36 + k * 10 + wob(t, 1, 2, k)},-110 {-24 + k * 8},-150", "none", "#8d8174", 2))
                s.append(P("M-30,-110 Q0,-100 30,-110", "none", INK, 2))
                for k in range(5): s.append(C(-22 + k * 11, -106, 4, "#7a2d1a", INK, 1))
        if o.get('crown'):
            s.append(P("M-58,-30 L-62,-86 L-36,-72 L-20,-118 L0,-84 L20,-118 L36,-72 L62,-86 L58,-30 Q0,-46 -58,-30 Z", "url(#gold)", INK, 4))
            for k in (-36, 0, 36): s.append(C(k, -64, 7, "#c0392b", INK, 1.5))
            s.append(P("M-58,-34 Q0,-50 58,-34", "none", "#fff3c4", 3, .8, 'stroke-dasharray="2 6"'))
        if o.get('feather'):
            fw = wob(t, 1.5, 4)
            s.append(G(P("M0,0 Q-14,-40 0,-90 Q14,-40 0,0 Z", "#2e8b57", INK, 3) + E(0, -62, 9, 14, "#1f5fa8", INK, 2) + C(0, -62, 4, "#f6d27a"), 30, -60, 1, 18 + fw))
        if o.get('tilak'):
            for k in range(3): s.append(P(f"M-24,{-44 + k * 7} Q0,{-48 + k * 7} 24,{-44 + k * 7}", "none", "#f4efe0", 3.5))
            s.append(C(0, -40, 4, "#c0392b"))
        if o.get('wrinkles'):
            for k in range(2): s.append(P(f"M-20,{-54 + k * 6} Q0,{-58 + k * 6} 20,{-54 + k * 6}", "none", "#9a6a46", 1.8))
    else:
        s.append(P("M-55,-4 Q-62,-72 0,-76 Q62,-72 55,-4 Q50,-44 6,-50 Q-36,-52 -55,-4 Z", INK, INK, 3))
        for k in range(6): s.append(P(f"M{-44 + k * 8},-16 Q{-30 + k * 7},-58 {4},-70", "none", "#3a2a22", 1.6))
        for k in range(5): s.append(P(f"M{44 - k * 7},-14 Q{30 - k * 6},-56 {8},-70", "none", "#3a2a22", 1.6))
        s.append(P("M3,-76 L3,-50", "none", "#c0392b", 4))  # sindoor line hidden by hair parting
        s.append(P("M3,-70 L3,-46", "none", "url(#gold)", 2.5) + C(3, -38, 6, "url(#gold)", INK, 2) + C(3, -38, 2.5, "#c0392b"))  # maang tikka
        if o.get('pallu'):
            pw = wob(t, 1.3, 4)
            s.append(P(f"M-74,30 Q-80,-96 0,-102 Q80,-96 74,30 Q{86 + pw},120 {78 + pw},200 L60,200 Q66,60 60,-10 Q50,-66 0,-68 Q-50,-66 -60,-10 Q-66,40 -64,80 Z",
                       o['pallu'], INK, 5))
            s.append(P(f"M-74,30 Q-80,-96 0,-102 Q80,-96 74,30 Q{86 + pw},120 {78 + pw},200", "none", o.get('border', 'url(#bord)'), 11))
            s.append(P("M-60,-10 Q-50,-66 0,-68 Q50,-66 60,-10", "none", INK, 2, .4))
    # brows (tapered filled)
    for sg in (-1, 1):
        ix, iy = sg * 9, -26 - 9 * sad + 7 * ang
        mx_, my_ = sg * 24, -35 - 2 * sad + 3 * ang
        ox, oy = sg * 42, -24 + 5 * sad - 4 * ang
        s.append(P(f"M{ix},{iy:.1f} Q{mx_},{my_:.1f} {ox},{oy:.1f} Q{mx_},{my_ + 5:.1f} {ix},{iy + 3:.1f} Z", INK, INK, 1.5))
    # eyes: Kalighat almond with kajal flick
    for sg in (-1, 1):
        cx, cy = sg * 22, -7
        h = 12 * op + .4
        up = f"M{cx - 17 * sg if False else cx - 17},{cy} Q{cx},{cy - 2 * h} {cx + 17},{cy}"
        eye = f"M{cx - 17},{cy} Q{cx},{cy - 2 * h} {cx + 17},{cy} Q{cx},{cy + 1.25 * h} {cx - 17},{cy} Z"
        s.append(P(eye, "#fffaf0", INK, 2.5))
        if op > .12:
            ix_, iy_ = cx + gx * 6, cy + gy * 3
            s.append(C(ix_, iy_, 8.5 * min(1, op * 1.15), "#4a2c1a")); s.append(C(ix_, iy_, 5 * min(1, op * 1.2), INK))
            s.append(C(ix_ + 2.5, iy_ - 3, 2.4, "#fff")); s.append(C(ix_ - 2, iy_ + 2, 1.2, "#fff", op=.8))
        # upper lid heavy + kajal flick outward
        fx = cx + sg * 17
        s.append(P(f"M{cx - 18},{cy + 1} Q{cx},{cy - 2 * h - 4} {cx + 18},{cy + 1}", "none", INK, 5))
        s.append(P(f"M{fx},{cy} Q{fx + sg * 10},{cy - 4} {fx + sg * 18},{cy - 9}", "none", INK, 3.5))
        s.append(P(f"M{cx - 15},{cy + 2} Q{cx},{cy + 1.25 * h + 2} {cx + 15},{cy + 2}", "none", INK, 1.8))
        for k in range(4):  # lashes
            lx = cx - 12 + k * 8; ly = cy - 1.75 * h + abs(k - 1.5) * 2
            s.append(P(f"M{lx},{ly} l{sg * 2},{-6}", "none", INK, 1.6))
        if o.get('old'): s.append(P(f"M{cx - 14},{cy + 14} Q{cx},{cy + 19} {cx + 14},{cy + 14}", "none", "#8a6a50", 1.8))
    s = [x for x in s if x]
    # nose + nath
    s.append(P("M3,-6 Q-5,16 -6,22 Q0,28 9,23", "none", INK, 3.5))
    s.append(P("M-8,24 Q-3,27 0,25", "none", "#9a6a46", 2))
    if not male:
        s.append(C(14, 22, 7, "none", "url(#gold)", 2.4) + C(14, 29, 2, "#fff3c4"))
        s.append(P(f"M20,22 Q42,{6 + wob(t, 2, 2)} 52,4", "none", "url(#gold)", 1.4))
    # mouth / lips
    tr = math.sin(t * 36) * 2.4 * o.get('tremble', 0)
    mo = o.get('mouthOpen', 0); my = 40
    if o.get('beard'):
        bc = o['beard']
        s.append(P("M-50,6 Q-58,80 -26,118 Q0,150 26,118 Q58,80 50,6 Q34,40 0,44 Q-34,40 -50,6 Z", bc, INK, 4))
        for k in range(9): s.append(P(f"M{-36 + k * 9},{40 + abs(k - 4) * 2} Q{-38 + k * 9 + wob(t, 1.5, 3, k)},{90} {-30 + k * 7.5},{126 - abs(k - 4) * 6}", "none", "#9b9288", 2))
        s.append(P("M-34,30 Q-14,18 0,30 Q14,18 34,30", "none", bc, 11) + P("M-34,30 Q-14,18 0,30 Q14,18 34,30", "none", INK, 2.5))
    elif o.get('mustache'):
        s.append(P("M-34,28 Q-18,16 0,26 Q18,16 34,28 Q42,22 44,14 Q38,34 18,32 Q8,30 0,32 Q-8,30 -18,32 Q-38,34 -44,14 Q-42,22 -34,28 Z", INK, INK, 2))
    if mo > .05:
        s.append(E(0, my + 2, 10, 3 + 8 * mo, "#5a1e1a", INK, 2.5)); s.append(E(0, my + 2 + 5 * mo, 6, 2 * mo, "#c26a6a", "none", 0))
    elif not o.get('beard'):
        c_ = my + 12 * sm - 7 * sad + tr
        s.append(P(f"M-16,{my} Q-8,{my - 5} 0,{my - 2} Q8,{my - 5} 16,{my} Q0,{c_ + 2:.1f} -16,{my} Z", "#b8423a", INK, 2))
        s.append(P(f"M-16,{my} Q0,{(my + c_) / 2:.1f} 16,{my}", "none", "#5a1e1a", 2))
        if sm > .3:
            for sg in (-1, 1): s.append(P(f"M{sg * 16},{my} q{sg * 4},-2 {sg * 5},-6", "none", INK, 2))
    # bindi
    if not male: s.append(C(0, -30, 5.5, "#c0392b") + C(0, -30, 2, "#ffd36b"))
    # tears
    tv = o.get('tears', 0)
    if tv > 0:
        for sg in (-1, 1):
            s.append(P(f"M{sg * 20},2 Q{sg * 28},30 {sg * 30},62", "none", "#bfe3ff", 4, .55 * tv))
            for k in range(2):
                ph = ((t * .5 + k * .5 + (.27 if sg > 0 else 0)) % 1)
                ty = 4 + ph * 74; tx = sg * (22 + ph * 9)
                s.append(P(f"M{tx},{ty - 10} Q{tx + 7},{ty + 3} {tx},{ty + 7} Q{tx - 7},{ty + 3} {tx},{ty - 10} Z", "#cfe9ff", "#4a78a8", 1.6, tv * (1 - ph * .5)))
                s.append(C(tx - 2, ty, 1.6, "#fff", op=tv))
    return "".join(s)


# ---------------------------------------------------------------- figures
def necklace(y=96):
    g = [P("M-40,96 Q0,140 40,96", "none", "url(#gold)", 6), P("M-48,96 Q0,160 48,96", "none", "#fff3c4", 4, extra='stroke-dasharray="1 7"')]
    g.append(P("M-56,98 Q0,182 56,98", "none", "url(#gold)", 5) + C(0, 176, 10, "url(#gold)", INK, 2) + C(0, 176, 4, "#c0392b"))
    return "".join(g)


def woman(o):
    t = o.get('t', 0); sar = o.get('saree', "url(#red)"); bd = o.get('border', "url(#bord)"); pat = o.get('pat', "url(#buti)")
    br = 1 + .012 * math.sin(t * 2.2)  # breathing
    s = []
    if o.get('pose') == 'kneel':
        s.append(P("M-118,186 Q-170,320 -150,388 Q0,410 168,388 Q182,300 118,186 Z", sar, INK, 6))
        s.append(P("M-118,186 Q-170,320 -150,388 Q0,410 168,388 Q182,300 118,186 Z", pat, "none", 0))
        for k in range(5): s.append(P(f"M{-80 + k * 40},210 Q{-90 + k * 42},300 {-100 + k * 50},385", "none", INK, 2, .35))
        s.append(P("M-152,378 Q0,400 166,378", "none", bd, 16))
    else:
        s.append(P("M-96,186 Q-132,420 -122,566 Q0,580 122,566 Q132,420 96,186 Z", sar, INK, 6))
        s.append(P("M-96,186 Q-132,420 -122,566 Q0,580 122,566 Q132,420 96,186 Z", pat, "none", 0))
        for k in range(6): s.append(P(f"M{-60 + k * 26},200 Q{-70 + k * 28},400 {-80 + k * 32},560", "none", INK, 2, .35))
        s.append(P("M-122,552 Q0,566 122,552", "none", bd, 18))
        for fx in (-46, 40):
            s.append(E(fx, 586, 22, 9, "url(#skin)", INK, 3) + P(f"M{fx - 22},586 Q{fx},596 {fx + 22},586", "none", "#c0392b", 4, .8))
    tor = P("M-74,86 Q-108,140 -100,206 Q0,222 100,206 Q108,140 74,86 Z", sar, INK, 6)
    s.append(G(tor + P("M-74,86 Q-108,140 -100,206 Q0,222 100,206 Q108,140 74,86 Z", pat, "none", 0)
               + P("M-64,90 Q10,150 78,206", "none", bd, 20) + P("M-64,90 Q10,150 78,206", "none", INK, 2, .6), 0, 0, 1, 0, br))
    s.append(G(necklace(), 0, 0, 1, 0, br))
    a = o.get('arms', 'hold'); sh = (-66, 112); sh2 = (66, 112); hp1 = hp2 = "open"; hang1 = hang2 = None
    if a == 'hold':
        A1 = (112, 74, 25, 70); A2 = (68, 74, 155, 70); hp1 = hp2 = "curl"
    elif a == 'offer':
        A1 = (62, 64, -8, 72); A2 = (52, 64, -18, 68); hang1 = hang2 = 0
    elif a == 'pray':
        A1 = (82, 62, -42, 64); A2 = (98, 62, -138, 64); hang1, hang2 = 45, -45
    elif a == 'shield':
        A1 = (112, 74, 30, 64); A2 = (-62, 72, -150, 62); hang2 = -60
    elif a == 'reach':
        r = o.get('reach', 0); A1 = (112, 74, 30, 64); A2 = (18 - 22 * r, 78, -8 - 10 * r, 76); hang2 = 80 - 30 * r
    elif a == 'lift':
        r = o.get('lift', 0); A1 = (92 - 72 * r, 74, 22 - 80 * r, 72); A2 = (88 - 72 * r, 74, 158 + 80 * r, 72); hp1 = hp2 = "curl"
    else:
        A1 = (100, 72, 95, 70); A2 = (80, 72, 85, 70)
    l1, h1 = arm(*sh, *A1, hpose=hp1, hang=hang1); l2, h2 = arm(*sh2, *A2, hpose=hp2, hang=hang2)
    s += [l1, l2]
    fo = dict(o.get('face', {})); fo.setdefault('pallu', sar); fo.setdefault('border', bd); fo['t'] = t
    s.append(G(face(fo), 0, wob(t, 2.2, 1.2), 1, o.get('tilt', 0) + wob(t, .9, 1.2)))
    sc_ = o.get('s', 1); gl = lambda h: (o['x'] + sc_ * h[0], o['y'] + sc_ * h[1])
    return G("".join(s), o['x'], o['y'], sc_), gl(h1), gl(h2)


def man(o):
    t = o.get('t', 0); dh = o.get('dhoti', "url(#white)"); up = o.get('upper', "url(#white)"); s = []
    br = 1 + .012 * math.sin(t * 2)
    if o.get('pose') == 'sit':
        s.append(P("M-160,250 Q-174,336 -130,348 Q0,362 130,348 Q174,336 160,250 Q0,214 -160,250 Z", dh, INK, 6))
        for k in range(6): s.append(P(f"M{-120 + k * 48},262 Q{-110 + k * 46},300 {-118 + k * 48},344", "none", INK, 2, .35))
        for fx in (-70, 70): s.append(E(fx, 300, 26, 12, "url(#skinD)", INK, 3))
    else:
        s.append(P("M-74,190 L-96,522 L-12,522 L0,334 L12,522 L96,522 L74,190 Z", dh, INK, 6))
        for k in range(4): s.append(P(f"M{-60 + k * 40},210 L{-70 + k * 46},515", "none", INK, 2, .3))
        for fx in (-54, 54): s.append(E(fx, 540, 26, 10, "url(#skinD)", INK, 3))
    tor = P("M-80,88 Q-108,150 -96,262 Q0,276 96,262 Q108,150 80,88 Z", up, INK, 6)
    if o.get('bare'):
        tor = P("M-80,88 Q-108,150 -96,262 Q0,276 96,262 Q108,150 80,88 Z", o.get("armskin", "url(#skinD)"), INK, 6) + P("M-50,150 Q0,170 50,150", "none", "#8a5a36", 2, .5)
    s.append(G(tor, 0, 0, 1, 0, br))
    if o.get('angavastram'): s.append(G(P("M-80,92 Q0,170 86,250", "none", o['angavastram'], 26) + P("M-80,92 Q0,170 86,250", "none", INK, 2, .5), 0, 0, 1, 0, br))
    if o.get('sacred'): s.append(P("M-52,96 Q10,180 62,254", "none", "#fbf6ea", 4))
    if o.get('mala'):
        for k in range(17):
            a = math.pi * (k / 16); s.append(C(-46 * math.cos(a), 96 + 92 * math.sin(a), 6, "#6b2516", INK, 1.2))
    sh = (-70, 112); sh2 = (70, 112); a = o.get('arms', 'down'); r = o.get('lift', 0); fill = o.get("armskin", "url(#skinD)")
    if a == 'bless':
        A1 = (112, 70, 42, 60); A2 = (-36 - 8 * r, 72, -88 - 14 * r, 66); hp = ("curl", "open"); hg = (None, 0)
    elif a == 'lift':
        A1 = (92 - 76 * r, 74, 30 - 92 * r, 72); A2 = (88 - 76 * r, 74, 150 + 92 * r, 72); hp = ("curl", "curl"); hg = (None, None)
    elif a == 'point':
        A1 = (100, 72, 92, 70); A2 = (-8, 76, -18, 76); hp = ("curl", "open"); hg = (None, 70)
    elif a == 'bow':
        A1 = (170, 70, 180, 64); A2 = (0, 74, 0, 70); hp = ("curl", "curl"); hg = (None, None)
    elif a == 'draw':
        A1 = (180, 76, 180, 72); A2 = (10, 60, 170, 58); hp = ("curl", "curl"); hg = (None, None)
    elif a == 'raise':
        A1 = (100, 72, 95, 70); A2 = (-80 - 10 * r, 72, -100 - 10 * r, 66); hp = ("curl", "fist"); hg = (None, None)
    elif a == 'give':
        A1 = (100, 72, 95, 70); A2 = (10, 72, 0, 70); hp = ("curl", "open"); hg = (None, 0)
    elif a == 'hug':
        A1 = (60, 70, -20, 70); A2 = (120, 70, 200, 70); hp = ("curl", "curl"); hg = (None, None)
    elif a == 'wheel':
        A1 = (80, 66, 60, 60); A2 = (60, 66, 100, 60); hp = ("curl", "curl"); hg = (None, None)
    elif a == 'rest':
        A1 = (120, 70, 60, 64); A2 = (60, 70, 120, 64); hp = ("curl", "curl"); hg = (None, None)
    else:
        A1 = (100, 72, 95, 70); A2 = (80, 72, 85, 70); hp = ("curl", "curl"); hg = (None, None)
    l1, h1 = arm(*sh, *A1, w=19, fill=fill, hpose=hp[0], bangles=None, hang=hg[0]); l2, h2 = arm(*sh2, *A2, w=19, fill=fill, hpose=hp[1], bangles=None, hang=hg[1])
    s += [l1, l2]
    fo = dict(o.get('face', {})); fo['male'] = True; fo['t'] = t; fo.setdefault('skin', "url(#skinD)")
    s.append(G(face(fo), 0, wob(t, 2, 1.2), 1, o.get('tilt', 0) + wob(t, .8, 1.0)))
    sc_ = o.get('s', 1); gl = lambda h: (o['x'] + sc_ * h[0], o['y'] + sc_ * h[1])
    return G("".join(s), o['x'], o['y'], sc_), gl(h1), gl(h2)


def baby(x, y, s, t, armour=False, eyes=0., glow=1.):
    g = [C(0, 10, 110 * (1 + .06 * math.sin(t * 3.5)), "url(#glow)", op=.8 * glow)]
    g.append(P("M-60,10 Q-66,86 0,92 Q66,86 60,10 Q40,-6 0,-4 Q-40,-6 -60,10 Z", "#f7ead0" if not armour else "url(#gold)", INK, 4))
    if armour:
        for k in range(4): g.append(P(f"M-48,{14 + k * 17} Q0,{28 + k * 17} 48,{14 + k * 17}", "none", "#7a5410", 3))
        for k in range(5): g.append(C(-32 + k * 16, 24 + (k % 2) * 17, 4, "#c0392b", INK, 1))
        g.append(C(0, 50, 11, "#fff3c4", INK, 2) + C(0, 50, 5, "#c0392b"))
    else:
        for k in range(3): g.append(P(f"M-44,{24 + k * 18} Q0,{36 + k * 18} 44,{24 + k * 18}", "none", "#c9b58e", 2.5))
    g.append(P("M0,-44 C26,-44 34,-24 33,-8 C32,14 18,26 0,26 C-18,26 -32,14 -33,-8 C-34,-24 -26,-44 0,-44 Z", "url(#skin)", INK, 4))
    for k in range(5): g.append(P(f"M{-20 + k * 10},-40 q{4 + k},-10 {10},-4", "none", INK, 3))
    g.append(E(-18, 6, 7, 4, "#e88a6a", "none", 0, .4)); g.append(E(18, 6, 7, 4, "#e88a6a", "none", 0, .4))
    for sg in (-1, 1):
        if eyes > .5:
            g.append(E(sg * 11, -6, 6, 5, "#fffaf0", INK, 1.5) + C(sg * 11, -5, 3.6, INK) + C(sg * 11 + 1.5, -6.5, 1.2, "#fff"))
        else:
            g.append(P(f"M{sg * 11 - 7},-6 Q{sg * 11},-1 {sg * 11 + 7},-6", "none", INK, 2.6))
        if armour:
            g.append(G(C(0, 0, 18, "url(#glow)", op=.6) + C(0, 0, 8, "none", "url(#gold)", 4), sg * 37, 24 + 3 * math.sin(t * 3 + sg), 1))
    g.append(P("M-6,12 Q0,17 6,12", "none", "#b8423a", 2.6))
    g.append(C(0, -26, 3, "#c0392b"))
    return G("".join(g), x, y, s)


def basket(x, y, s, t, withbaby=True, glow=1.):
    g = []
    if withbaby: g.append(C(0, -24, 90, "url(#glow)", op=.75 * glow))
    g.append(P("M-120,-12 Q0,96 120,-12 Q0,10 -120,-12 Z", "#b07a3a", INK, 5))
    g.append(P("M-120,-12 Q0,96 120,-12 Q0,10 -120,-12 Z", "url(#weave)", "none", 0, .6))
    g.append(P("M-122,-12 Q0,14 122,-12", "none", "#8a5a2c", 9) + P("M-122,-12 Q0,14 122,-12", "none", INK, 2.5))
    if withbaby:
        g.append(P("M-58,-10 Q0,-46 58,-10 Q0,4 -58,-10 Z", "#f7ead0", INK, 3))
        g.append(G(P("M0,-30 C18,-30 24,-16 23,-6 C22,8 12,16 0,16 C-12,16 -22,8 -23,-6 C-24,-16 -18,-30 0,-30 Z", "url(#skin)", INK, 3) +
                   P("M-12,-6 q6,4 10,0 M2,-6 q6,4 10,0", "none", INK, 2), 0, -24, 1))
    return G("".join(g), x, y, s, 3 * math.sin(t * 1.5))


# ---------------------------------------------------------------- environment
def river(y0, t, grad="url(#riverD)", line="#dfeefe", n=10, amp=12, spark=True):
    s = [f'<rect x="0" y="{y0}" width="{W}" height="{H - y0}" fill="{grad}"/>']
    for r in range(n):
        y = y0 + 26 + r * 50; a = amp * (1 + r * .12)
        pts = " ".join(f"{x},{y + a * math.sin(x / (40 + r * 4) + r * 1.3 + t * (1.3 if r % 2 else -1.1)):.1f}" for x in range(-10, W + 20, 14))
        s.append(f'<polyline points="{pts}" fill="none" stroke="{line}" stroke-width="{3 + r * .35:.1f}" opacity="{.7 - r * .04:.2f}"/>')
    if spark:
        for k in range(26):
            x = (k * 97 + t * 30) % W; y = y0 + 40 + (k * 61) % (H - y0 - 60)
            s.append(C(x, y, 2.5 + 1.5 * math.sin(t * 5 + k), "#ffffff", op=.25 + .35 * abs(math.sin(t * 3 + k))))
    return "".join(s)


def lotus(x, y, s, t):
    g = [E(0, 26, 78, 18, "#3f7d4a", INK, 3), P("M-60,26 Q0,10 60,26", "none", "#2d5c35", 2)]
    for k, a in enumerate((-60, -32, 0, 32, 60)):
        g.append(G(P("M0,0 Q-20,-44 0,-78 Q20,-44 0,0 Z", "#f6b6c4", INK, 3) + P("M0,-6 L0,-66", "none", "#e17f97", 2), 0, 12, 1, a + 3 * math.sin(t * 2 + k)))
    g.append(C(0, 4, 8, "#f6d27a", INK, 2))
    return G("".join(g), x, y + 4 * math.sin(t * 1.4 + x), s)


def tree(x, y, s, t, col="#6e8b4a", col2="#4f6e34"):
    g = [P("M-14,0 Q-10,-160 -4,-300 L4,-300 Q12,-160 18,0 Z", "#6b4226", INK, 4)]
    for k, (dx, dy, r) in enumerate([(-90, -320, 120), (80, -340, 130), (0, -430, 140), (-130, -430, 90), (130, -440, 95)]):
        sw = wob(t, 1.1, 4, k)
        g.append(C(dx + sw, dy, r, col if k % 2 else col2, INK, 4))
        for j in range(6): g.append(G(P("M0,0 Q8,-10 16,0 Q8,10 0,0 Z", "#9cbf6a", INK, 1.2), dx + sw + (j - 3) * r * .25, dy + ((j * 37) % 50) - 25, 1.2, j * 50 + t * 20))
    return G("".join(g), x, y, s)


def hills(y, t, col, amp, off, op=1.):
    pts = " ".join(f"{x},{y - amp * (0.5 + .5 * math.sin(x / 160 + off)) :.1f}" for x in range(-20, W + 40, 20))
    return f'<polygon points="-20,{H} {pts} {W + 40},{H}" fill="{col}" stroke="{INK}" stroke-width="3" opacity="{op:.2f}"/>'


def grass(y, t, col="#5f7f3a", n=40, h=60, op=1.):
    s = []
    for k in range(n):
        x = k * (W / n) + 10; hh = h * (.6 + .4 * math.sin(k * 2.7))
        s.append(P(f"M{x:.0f},{y} Q{x + 4 + wob(t, 2, 6, k):.1f},{y - hh * .6:.1f} {x + 10 * math.sin(t * 1.6 + k):.1f},{y - hh:.1f}", "none", col, 5, op))
    return "".join(s)


def sunface(x, y, r, t, op=1., eyes_open=0.1):
    g = [C(0, 0, r * 3.0 * (1 + .03 * math.sin(t * 3)), "url(#glow)", op=.9)]
    for i in range(24):
        a = i * 15 + t * 7; L = 1.75 if i % 2 else 1.45
        g.append(G(P(f"M{r * 1.02},-12 Q{r * L},0 {r * 1.02},12 Z", "#f4a236" if i % 2 else "#ffd36b", INK, 3), 0, 0, 1, a))
    g.append(C(0, 0, r, "url(#sunG)", INK, 6))
    fo = dict(male=True, open=eyes_open, smile=.45, t=t, skin="url(#sunG)", hair="#f7c948", saccade=False, kundal=True)
    fs = face(fo).replace('M-20,48 Q-22,72 -26,100 L26,100 Q22,72 20,48 Z', 'M0,0')
    g.append(G(fs, 0, 6, r / 72))
    g.append(P(f"M{-r * .62},{-r * .76} L{-r * .4},{-r * 1.3} L{-r * .18},{-r * .95} L0,{-r * 1.42} L{r * .18},{-r * .95} L{r * .4},{-r * 1.3} L{r * .62},{-r * .76} Z", "url(#gold)", INK, 5))
    for k in (-1, 0, 1): g.append(C(k * r * .4, -r * .9 - (12 if k == 0 else 0), r * .06, "#c0392b", INK, 2))
    inner = G("".join(g), x, y, 1)
    return inner if op >= .99 else f'<g opacity="{op:.2f}">{inner}</g>'


def horse(x, y, s, t, ph):
    g = math.sin(t * 11 + ph)
    b = [P("M-60,0 Q-70,-36 -40,-46 L40,-46 Q70,-40 66,-6 Q0,12 -60,0 Z", "#fbf6ea", INK, 4),
         P("M50,-40 Q66,-74 80,-96 Q98,-100 104,-86 Q92,-80 84,-60 Q76,-40 66,-26 Z", "#fbf6ea", INK, 4),
         C(92, -88, 3, INK), P(f"M58,-60 Q{40 + 6 * g},-90 {30 + 6 * g},-70", "none", "#e2b13c", 6)]
    for k, lx in enumerate((-46, -30, 30, 48)):
        sw = g * (1 if k % 2 else -1)
        b.append(P(f"M{lx},-4 L{lx + 14 * sw},30 L{lx + 10 * sw},50", "none", INK, 7) + P(f"M{lx},-4 L{lx + 14 * sw},30 L{lx + 10 * sw},50", "none", "#fbf6ea", 4))
    b.append(P(f"M-62,-26 Q{-92 + 8 * g},-10 {-96 + 8 * g},20", "none", "#e2b13c", 8))
    return G("".join(b), x, y, s)


def motes(t, col="#fff3c4", n=40, op=.5):
    s = []
    for x0, y0, ph, sp in MOTES[:n]:
        x = (x0 + t * 12 * sp) % W; y = (y0 - t * 18 * sp) % H
        s.append(C(x, y, 2 + 1.5 * math.sin(t * 2 + ph), col, op=op * (.4 + .6 * abs(math.sin(t * 1.3 + ph)))))
    return "".join(s)


def bgwash(c1, c2):
    return (f'<rect width="{W}" height="{H}" fill="{c1}"/>'
            f'<circle cx="{W * .3}" cy="{H * .25}" r="700" fill="{c2}" opacity=".35"/><circle cx="{W * .8}" cy="{H * .6}" r="600" fill="{c2}" opacity=".25"/>')


def cam(inner, s0, s1, u, cx=540, cy=900, dx=0, dy=0):
    s = s0 + (s1 - s0) * ease(u); ox = dx * ease(u); oy = dy * ease(u)
    return f'<g transform="translate({cx + ox:.1f},{cy + oy:.1f}) scale({s:.4f}) translate({-cx:.1f},{-cy:.1f})">{inner}</g>'


def par(inner, u, amt):  # parallax shift
    return f'<g transform="translate({amt * ease(u):.1f},0)">{inner}</g>'


# ---------------------------------------------------------------- scenes (t global, u local 0..1)
def sc0(t, u):  # dawn riverbank — tender
    s = [bgwash("#f6dcae", "#f3a96a")]
    s.append(par(C(860, 380, 120, "url(#sunG)", INK, 5) + C(860, 380, 300, "url(#glow)", op=.6), u, -20))
    s.append(par(hills(900, t, "#c9a46e", 120, 1, .9) + hills(980, t, "#a8854f", 90, 3), u, -40))
    s.append(par(tree(140, 1010, .75, t) + tree(980, 1000, .6, t, "#7f9c56"), u, -60))
    s.append(river(1060, t))
    s.append(lotus(900, 1300, .9, t) + lotus(170, 1420, .8, t))
    w, h1, h2 = woman(dict(x=480, y=560, s=1.25, pose='kneel', arms='hold', t=t, tilt=9,
                          face=dict(open=.5 * blink(t), gaze=(.7, 1), smile=.6)))
    s.append(w)
    s.append(baby(578, 860, 1.0, t))
    s.append(motes(t))
    s.append(par(grass(1080, t, "#6f8f45", 34, 50), u, -90))
    return cam("".join(s), 1.0, 1.14, u, 540, 820)


def sc1(t, u):  # hermitage
    s = [bgwash("#efe0bf", "#cdb57a")]
    s.append(par(hills(760, t, "#b7b98a", 140, 2, .9) + hills(860, t, "#97a36a", 90, 5), u, -30))
    s.append(par(tree(860, 1030, 1.05, t), u, -50))
    s.append(f'<rect x="0" y="1030" width="{W}" height="900" fill="#d6bd86"/>' + grass(1040, t, "#8a9a52", 40, 40))
    s.append(P("M170,1030 L170,880 L300,800 L430,880 L430,1030 Z", "#c8a26a", INK, 5) + P("M150,890 L300,780 L450,890", "none", "#8a6a3a", 22) + P("M260,1030 L260,930 L340,930 L340,1030", "#5a3a22", INK, 4))
    fx, fy = 600, 1215
    s.append(P(f"M{fx - 70},{fy + 10} L{fx + 70},{fy + 10}", "none", "#6b4226", 14))
    for k in range(6):
        hgt = 60 + 26 * math.sin(t * 9 + k * 1.2)
        s.append(P(f"M{fx - 40 + k * 16},{fy} Q{fx - 52 + k * 16},{fy - hgt * .5} {fx - 38 + k * 16},{fy - hgt} Q{fx - 26 + k * 16},{fy - hgt * .5} {fx - 30 + k * 16},{fy} Z", "#f4a236" if k % 2 else "#e8552a", INK, 2))
    for k in range(5):
        ph = (t * .5 + k / 5) % 1; s.append(C(fx + 20 * math.sin(t * 3 + k), fy - 80 - ph * 300, 8 * (1 - ph), "#a59a8e", op=.5 * (1 - ph)))
    soft = seg(u, .38, .62)
    sage, sh1, sh2 = man(dict(x=790, y=760, s=1.12, pose='sit', arms='bless' if soft > .4 else 'rest', t=t, dhoti="url(#saff)", upper="url(#saff)", bare=True, mala=True, sacred=True,
                             angavastram="#c25e1c", lift=wob(t, 2, .25),
                             face=dict(old=True, beard="#e4ddd2", hair="#d8d2c8", jata=True, tilak=True, wrinkles=True, angry=1 - soft, smile=.4 * soft,
                                       open=blink(t, 3.8) * (.75 + .25 * soft), gaze=(-1, .3))))
    s.append(sage)
    if soft > .4:
        for k in range(10):
            ph = (t * .55 + k / 10) % 1
            s.append(C(sh2[0] + 60 * math.cos(k * 1.7 + t), sh2[1] - 20 - ph * 160, 7 * (1 - ph) + 2, "#ffd36b", op=1 - ph))
    walk = seg(u, 0, .3)
    wx = 110 + 220 * walk; kneel = walk >= .999
    w, h1, h2 = woman(dict(x=wx, y=700 + (40 if kneel else 6 * abs(math.sin(t * 6))), s=.98, pose='kneel' if kneel else 'stand', arms='offer', t=t,
                          saree="url(#saff)", border="url(#bordG)", tilt=-7,
                          face=dict(open=blink(t, 2.6), gaze=(1, -.2), smile=.25 + .3 * soft, sad=.35 * (1 - soft))))
    s.append(w)
    s.append(E(h2[0] + 6, h2[1] - 14, 54, 16, "#8a5a2c", INK, 4) + C(h2[0] - 16, h2[1] - 30, 15, "#d64532", INK, 3) + C(h2[0] + 14, h2[1] - 32, 14, "#f0b33c", INK, 3) + C(h2[0] + 36, h2[1] - 26, 12, "#7fae4a", INK, 3))
    for k in range(7):
        ph = (t * .2 + k * .17) % 1
        s.append(G(P("M0,0 Q10,-12 22,0 Q10,12 0,0 Z", "#9cbf6a" if k % 2 else "#c9a646", INK, 2), 80 + k * 150 + 50 * math.sin(t + k), 160 + ph * 1000, 1.3, t * 70 + k * 40))
    return cam("".join(s), 1.0, 1.1, u, 560, 900)


def sc2(t, u):  # mantra close-up at night
    s = [bgwash("#22163a", "#4b2f63")]
    for x, y, p, r in STARS: s.append(C(x, y, r * .8, "#fff3c4", op=.2 + .7 * abs(math.sin(t * 1.7 + p))))
    s.append(C(860, 260, 70, "url(#moonG)", INK, 4) + C(890, 245, 64, "#22163a"))
    wonder = seg(u, .7, .88)
    talk = 0 if wonder > .3 else .25 + .3 * abs(math.sin(t * 13)) * abs(math.sin(t * 5.3))
    w, h1, h2 = woman(dict(x=540, y=620, s=2.7, pose='stand', arms='pray', t=t, saree="url(#red)",
                          face=dict(open=.04 + .96 * wonder, mouthOpen=talk + .55 * wonder, sad=-.5 * wonder, gaze=(0, -1), saccade=wonder > .5)))
    s.append(f'<g>{C(540, 1000, 260 * (1 + .1 * math.sin(t * 5)), "url(#glow)", op=.35 + .4 * wonder)}</g>')
    s.append(w)
    for k in range(60):
        ph = (t * .38 + k / 60) % 1
        r = 50 + ph * 360; a = k * 2.4 + t * 2.4
        x = 540 + r * math.cos(a) * .75; y = 980 - ph * 860
        col = "#ffd36b" if k % 3 else "#fff3c4"
        s.append(C(x, y, 9 * (1 - ph) + 2.5, col, op=(1 - ph)))
        if k % 6 == 0: s.append(f'<text x="{x:.0f}" y="{y:.0f}" font-size="{34 * (1 - ph) + 10:.0f}" fill="#ffe08a" opacity="{(1 - ph) * .8:.2f}" font-family="serif">ॐ</text>')
    return cam("".join(s), 1.18, 1.0, u, 540, 820)


def sc3(t, u):  # Surya descends with seven horses
    s = [bgwash("#f7d98b", "#f4a236")]
    d = seg(u, 0, .7)
    for k in range(7):
        s.append(horse(150 + k * 130, 330 + 330 * d + (k % 2) * 18, .85, t, k))
    s.append(f'<polygon points="430,{560 + 300 * d} 650,{560 + 300 * d} 960,1700 120,1700" fill="#fff8de" opacity="{.15 + .4 * d:.2f}"/>')
    s.append(sunface(540, 210 + 330 * d, 150, t, eyes_open=.08 + .5 * seg(u, .6, .9)))
    s.append(motes(t, "#fff8de", 40, .8))
    s.append(hills(1500, t, "#d79a52", 60, 2))
    w, h1, h2 = woman(dict(x=540, y=1000, s=1.05, pose='stand', arms='shield', t=t, tilt=-5,
                          face=dict(open=.4 + .15 * math.sin(t * 2), sad=-.6, mouthOpen=.45, gaze=(0, -1))))
    s.append(w)
    return cam("".join(s), 1.0, 1.06, u, 540, 900)


def sc4(t, u):  # baby close-up with kavach & kundal
    s = [bgwash("#f6dcae", "#f3a96a")]
    for i in range(36):
        a = i * 10 + t * 9
        s.append(G(P("M330,-8 L640,0 L330,8 Z", "#f7c948" if i % 2 else "#fff3c4", op=.5), 540, 880, 1, a))
    s.append(C(540, 880, 420, "url(#glow)", op=.9))
    s.append(limb([(120, 1700), (240, 1350), (380, 1120)], 70, 52) + hand(390, 1100, 40, 2.2, "curl"))
    s.append(limb([(960, 1700), (840, 1350), (700, 1120)], 70, 52) + hand(690, 1100, -40, 2.2, "curl"))
    for k in range(4): s.append(E(380 - k * 16, 1130 + k * 24, 12, 50, "url(#gold)" if k % 2 == 0 else "#c0392b", INK, 2) + E(700 + k * 16, 1130 + k * 24, 12, 50, "url(#gold)" if k % 2 == 0 else "#c0392b", INK, 2))
    s.append(baby(540, 860, 4.3, t, armour=True, eyes=1 if (u > .45 and blink(t, 2.3) > .5) else 0))
    sh = (t * .45) % 1.5 - .25
    s.append(f'<polygon points="{240 + 600 * sh},900 {320 + 600 * sh},900 {200 + 600 * sh},1300 {120 + 600 * sh},1300" fill="#fff" opacity=".5"/>')
    s.append(motes(t, "#fff8de", 40, .7))
    return cam("".join(s), 1.0, 1.1, u, 540, 880)


def sc5(t, u):  # night: tears; then the basket drifts away
    s = [bgwash("#101c36", "#1f3560")]
    for x, y, p, r in STARS: s.append(C(x, y, r * .8, "#fff3c4", op=.2 + .55 * abs(math.sin(t * 1.5 + p))))
    s.append(C(850, 250, 92, "url(#moonG)", INK, 4) + C(850, 250, 240, "url(#glow)", op=.25))
    if u < .45:
        v = u / .45
        w, h1, h2 = woman(dict(x=540, y=600, s=2.75, pose='stand', arms='hold', t=t, saree="url(#redN)", tilt=-7 + 2.5 * math.sin(t * 4.5),
                              face=dict(open=.42 * blink(t, 1.7), sad=1, tears=1, tremble=1, gaze=(.3, 1))))
        s.append(w); s.append(baby(570, 1160, 2.3, t, glow=.7))
        return cam("".join(s), 1.0, 1.12, v, 540, 720)
    v = (u - .45) / .55
    s.append(hills(1010, t, "#1b2a4a", 80, 2))
    s.append(river(1060, t, "url(#riverN)", "#9fb8de"))
    bx = 470 + 480 * ease(cl((v - .12) / .88)); by = 1110 + 10 * math.sin(t * 2)
    s.append(basket(bx, by, 1.0 - .45 * ease(v), t))
    w, h1, h2 = woman(dict(x=290, y=600, s=1.08, pose='kneel', arms='reach', reach=ease(v), t=t, saree="url(#redN)", tilt=11,
                          face=dict(open=.38, sad=1, tears=1, tremble=.7, gaze=(1, .5))))
    s.append(w)
    for k in range(18):  # fireflies
        x = (k * 131 + t * 25) % W; y = 700 + (k * 53) % 350 + 20 * math.sin(t + k)
        s.append(C(x, y, 4, "#fff3a0", op=.3 + .7 * abs(math.sin(t * 3 + k))) + C(x, y, 12, "url(#glow)", op=.4))
    return cam("".join(s), 1.06, 1.0, v, 540, 900)


def sc6(t, u):  # Radha finds the baby — joy
    s = [bgwash("#f6e7c6", "#cfe0a8")]
    s.append(par(C(880, 260, 90, "url(#sunG)", INK, 5) + C(880, 260, 220, "url(#glow)", op=.5), u, -10))
    s.append(par(hills(900, t, "#b7b98a", 110, 1) + tree(120, 1000, .6, t), u, -30))
    s.append(f'<rect x="0" y="960" width="{W}" height="260" fill="#cdb27a"/>')
    s.append(river(1200, t, "url(#riverD)", "#e6f2fd", 8))
    s.append(grass(1215, t, "#5f7f3a", 30, 120, .9))
    s.append(G(P("M-130,-60 L130,-60 L110,30 L-110,30 Z", "#b07a3a", INK, 5) + P("M-130,-60 L130,-60 L110,30 L-110,30 Z", "url(#weave)", "none", 0, .4) +
               C(0, 44, 62, "none", INK, 10) + "".join(G(P("M0,-58 L0,58", "none", INK, 5), 0, 44, 1, k * 30 + t * 0) for k in range(6)) + C(0, 44, 10, "url(#gold)", INK, 2), 900, 900, 1))
    lift = seg(u, .2, .55)
    m_, mh1, mh2 = man(dict(x=745, y=590, s=1.0, pose='stand', arms='point', t=t, upper="url(#white)", angavastram="#e07b2a",
                           face=dict(turban="#e07b2a", mustache=True, smile=.45 + .45 * lift, open=blink(t, 3.1, 1), gaze=(-1, .2 - .5 * lift))))
    s.append(m_)
    s.append(basket(440, 1220 + 8 * math.sin(t * 2), .95, t, lift < .05, .8))
    r_, rh1, rh2 = woman(dict(x=430, y=520, s=1.12, pose='stand', arms='lift', lift=lift, t=t, saree="url(#green)", border="url(#bordG)", tilt=7 * math.sin(t * 1.8) * lift,
                             face=dict(open=blink(t, 2.4) * (1 - .55 * lift), smile=.25 + .85 * lift, gaze=(0, -lift))))
    s.append(r_)
    if lift >= .05: s.append(baby(436, 1190 - 380 * lift, 1.05, t, eyes=1 if lift > .7 else 0))
    if lift > .6:
        for k in range(8):
            ph = (t * .6 + k / 8) % 1
            s.append(G(P("M0,6 C-10,-6 -18,6 0,18 C18,6 10,-6 0,6 Z", "#e8556a", INK, 1.5), 436 + 110 * math.cos(k * .8 + t), 760 - ph * 260, .9 * (1 - ph) + .3, 0))
    return cam("".join(s), 1.08, 1.0, u, 520, 900)


def sc7(t, u):  # reveal — the sun is his father
    g = ease(cl(u * 1.15))
    s = [bgwash("#f8d28e", "#f49a4a")]
    s.append(sunface(540, 1040 - 520 * g, 110 + 200 * g, t, eyes_open=.08 + .6 * seg(u, .55, .8)))
    s.append(hills(1240, t, "#8a4e3a", 60, 3, .9))
    s.append(river(1250, t, "url(#riverG)", "#ffd9a8", 9, 10))
    s.append(basket(540, 1300 + 6 * math.sin(t * 2), .55, t))
    s.append(motes(t, "#fff3c4", 40, .8))
    return cam("".join(s), 1.0, 1.05, u, 540, 800)


def sc8(t, u):
    return bgwash("#22163a", "#4b2f63") + sunface(540, 640, 130, t, .95, .5) + motes(t, "#fff3c4", 30, .6)


SCENES = [sc0, sc1, sc2, sc3, sc4, sc5, sc6, sc7, sc8]


# ---------------------------------------------------------------- post (paper, vignette, grade)
def make_paper():
    r = np.random.default_rng(1)
    n = r.normal(0, 1, (H // 4, W // 4)).astype(np.float32)
    img = Image.fromarray(((n - n.min()) / (n.max() - n.min()) * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(1.2))
    fib = Image.new("L", (W, H), 128); d = ImageDraw.Draw(fib)
    for _ in range(1400):
        x, y = r.uniform(0, W), r.uniform(0, H); a = r.uniform(0, 6.28); L = r.uniform(8, 30)
        d.line([(x, y), (x + L * math.cos(a), y + L * math.sin(a))], fill=int(r.uniform(95, 165)), width=1)
    tex = ImageChops.blend(img, fib, .5)
    yy, xx = np.mgrid[0:H, 0:W]; dist = np.sqrt(((xx - W / 2) / (W * .62)) ** 2 + ((yy - H / 2) / (H * .62)) ** 2)
    vig = np.clip(1 - .55 * np.clip(dist - .55, 0, 1) ** 1.4, 0, 1)
    return np.asarray(tex).astype(np.float32) / 255., vig.astype(np.float32)


TEX = VIG = None


def post(img):
    global TEX, VIG
    if TEX is None: TEX, VIG = make_paper()
    a = np.asarray(img).astype(np.float32) / 255.
    a = a * (0.9 + 0.2 * TEX[..., None])
    a = a * VIG[..., None]
    a[..., 0] = a[..., 0] * 1.03; a[..., 2] = a[..., 2] * .97
    return Image.fromarray(np.clip(a * 255, 0, 255).astype(np.uint8))


def font(sz): return ImageFont.truetype(FONT, sz, layout_engine=ImageFont.Layout.RAQM)


def subtitle(img, text, u, y=1250, sz=46):
    d = ImageDraw.Draw(img); f = font(sz); maxw = 780
    words = text.split(" "); ls = []; cur = []
    for w_ in words:
        if d.textlength(" ".join(cur + [w_]), font=f) <= maxw: cur.append(w_)
        else: ls.append(cur); cur = [w_]
    ls.append(cur); lh = int(sz * 1.5)
    total = sum(len(w_) for w_ in words); cut = u * total * 1.08; acc = 0
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); od = ImageDraw.Draw(ov)
    od.rounded_rectangle([110, y - 18, 970, y - 18 + lh * len(ls) + 30], 28, fill=(20, 10, 6, 165), outline=(226, 177, 60, 200), width=3)
    img.alpha_composite(ov); d = ImageDraw.Draw(img)
    for i, l in enumerate(ls):
        line = " ".join(l); x = (W - d.textlength(line, font=f)) / 2
        for w_ in l:
            col = (255, 213, 74) if acc < cut <= acc + len(w_) + 1 else ((255, 255, 255) if acc < cut else (225, 215, 200))
            d.text((x, y + i * lh), w_, font=f, fill=col, stroke_width=3, stroke_fill=(0, 0, 0))
            x += d.textlength(w_ + " ", font=f); acc += len(w_) + 1


def ctext(img, text, y, sz, fill, stroke=(60, 0, 0), box=None):
    d = ImageDraw.Draw(img); f = font(sz); tw = d.textlength(text, font=f)
    if box:
        ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(ov).rounded_rectangle([(W - tw) / 2 - 30, y - 12, (W + tw) / 2 + 30, y + sz * 1.5], 22, fill=box)
        img.alpha_composite(ov); d = ImageDraw.Draw(img)
    d.text(((W - tw) / 2, y), text, font=f, fill=fill, stroke_width=5 if stroke else 0, stroke_fill=stroke)


def render_scene(i, t):
    u = cl((t - TM[i]) / (TM[i + 1] - TM[i]))
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">{DEFS}' + SCENES[i](t, u) + '</svg>'
    return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert("RGB")


def frame(n):
    t = n / FPS
    i = max(k for k in range(len(TM) - 1) if TM[k] <= t) if t < TM[-1] else len(TM) - 2
    img = render_scene(i, t)
    if i + 1 < len(SCENES) and TM[i + 1] - t < XF:  # crossfade into next scene
        a = 1 - (TM[i + 1] - t) / XF
        img = Image.blend(img, render_scene(i + 1, t), ease(a))
    img = post(img).convert("RGBA")
    u = cl((t - TM[i]) / (TM[i + 1] - TM[i]))
    if i < 8:
        subtitle(img, LINES[i], u)
        if t > TM[1]: ctext(img, "कर्ण - शापित योद्धा  |  भाग 1", 170, 34, (255, 233, 176), None, (110, 20, 10, 200))
    if i == 0:
        ctext(img, "किसका बेटा था ये बच्चा?", 230, 74, (255, 213, 74))
    if i == 8:
        ctext(img, "आगे क्या हुआ?", 1020, 84, (255, 213, 74))
        ctext(img, "पूरी कहानी यूट्यूब पर | लिंक बायो में", 1170, 44, (255, 255, 255), (0, 0, 0))
        ctext(img, "फ़ॉलो करें | कथालोक", 1280, 48, (255, 233, 176), (0, 0, 0))
    return img.convert("RGB")


if __name__ == "__main__":
    a, b = int(sys.argv[1]), int(sys.argv[2])
    for n in range(a, b):
        frame(n).save(f"/home/claude/kathalok/k3/frames/f{n:05d}.jpg", quality=92)
