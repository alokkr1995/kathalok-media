import math, random, sys, io, json
import numpy as np
import cairosvg
from PIL import Image, ImageDraw, ImageFont
import kgbase as K

W, H, FPS = 1920, 1080, 24
K.W, K.H = W, H
rng = random.Random(9)
K.STARS[:] = [(rng.uniform(40, W - 40), rng.uniform(30, 620), rng.uniform(0, 6.3), rng.uniform(1.2, 3)) for _ in range(160)]
K.MOTES[:] = [(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(0, 6.3), rng.uniform(2, 5)) for _ in range(50)]
from kgbase import P, E, C, G, INK, face, woman, man, baby, basket, river, lotus, tree, hills, grass, sunface, horse, motes, bgwash, cl, ease, seg, blink, wob, hand

META = json.load(open('/home/claude/kathalok/long_kr/meta.json'))
TOTAL = META[-1]['end'] + 2.5
FONT = K.FONT
CH_TITLES = {m['ch']: m['text'] for m in META if m['kind'] == 'title'}


# ---------------------------------------------------------------- props
def bow(x, y, s=1., ang=0., draw=0.):
    g = P("M0,-170 Q-60,0 0,170", "none", "#6b4226", 12) + P("M0,-170 Q-60,0 0,170", "none", INK, 3)
    g += P(f"M0,-170 L{-40 * draw},0 L0,170", "none", "#f4efe0", 2.5)
    if draw > .1: g += P(f"M{-40 * draw},0 L{150 - 40 * draw},0", "none", "#5a3a22", 5) + P(f"M{150 - 40 * draw},0 l-14,-8 l0,16 Z", "#c0c0c0", INK, 2)
    return G(g, x, y, s, ang)


def mace(x, y, s=1., ang=0.):
    return G(P("M0,0 L0,220", "none", "#6b4226", 12) + C(0, -30, 46, "url(#gold)", INK, 4) + "".join(C(46 * math.cos(k), -30 + 46 * math.sin(k), 8, "url(#gold)", INK, 2) for k in np.linspace(0, 6.28, 9)), x, y, s, ang)


def axe(x, y, s=1., ang=0.):
    return G(P("M0,40 L0,-200", "none", "#6b4226", 12) + P("M0,-200 Q80,-230 90,-150 Q70,-120 0,-140 Z", "#c9ced6", INK, 4) + P("M8,-190 Q60,-200 72,-160", "none", "#fff", 3), x, y, s, ang)


def chariot(x, y, s=1., t=0., wheel_sink=0., spin=True, flip=False):
    rot = (t * 120) % 360 if spin else 0
    g = P("M-170,-120 L170,-120 L150,0 L-150,0 Z", "#b07a3a", INK, 5) + P("M-170,-120 L170,-120 L150,0 L-150,0 Z", "url(#weave)", "none", 0, .4)
    g += P("M-160,-120 L-160,-240 M160,-120 L160,-240 M-170,-240 L170,-240", "none", INK, 6) + P("M-150,-250 Q0,-300 150,-250", "none", "#c0392b", 14)
    g += G(C(0, 0, 90, "none", INK, 12) + "".join(G(P("M0,-86 L0,86", "none", INK, 6), 0, 0, 1, k * 30 + rot) for k in range(6)) + C(0, 0, 14, "url(#gold)", INK, 3), -40, 30 + wheel_sink, 1)
    g += P("M170,-60 L340,-40", "none", "#6b4226", 10)
    return G(g, x, y, s, 0, -s if flip else None)


def cow(x, y, s=1., dead=False, flip=False):
    g = E(0, 0, 130, 62, "#f4efe2", INK, 5) + E(-40, -10, 30, 20, "#a37a54", "none", 0, .7) + E(50, 14, 24, 16, "#a37a54", "none", 0, .7)
    if dead:
        g += P("M110,10 Q170,30 190,60", "none", INK, 0) + E(170, 40, 40, 30, "#f4efe2", INK, 5) + P("M150,20 Q140,0 130,-10 M190,20 Q200,0 214,-6", "none", INK, 4) + P("M160,36 l8,6 m-8,0 l8,-6", "none", INK, 2.5)
        for lx in (-80, -30, 40, 90): g += P(f"M{lx},50 L{lx + 40},70", "none", INK, 10) + P(f"M{lx},50 L{lx + 40},70", "none", "#f4efe2", 6)
        g += P("M60,30 L80,40", "none", "#6b4226", 4)  # arrow
    else:
        g += E(150, -40, 42, 32, "#f4efe2", INK, 5) + P("M130,-70 Q120,-100 110,-104 M170,-70 Q180,-100 196,-104", "none", INK, 5) + C(160, -44, 4, INK)
        for lx in (-90, -50, 50, 90): g += P(f"M{lx},50 L{lx},130", "none", INK, 10) + P(f"M{lx},50 L{lx},130", "none", "#f4efe2", 6)
    return G(g, x, y, s, 0, -s if flip else None)


def crowd(y, t, n=22, col="#3a2a22", op=.85):
    s = []
    for k in range(n):
        x = k * (W / n) + 30; bob = 4 * math.sin(t * 3 + k)
        s.append(C(x, y - 70 + bob, 28, col, op=op) + P(f"M{x - 40},{y + 40} Q{x},{y - 70 + bob} {x + 40},{y + 40} Z", col, "none", 0, op))
        if k % 3 == 0: s.append(P(f"M{x + 20},{y - 40} L{x + 46},{y - 110 - 10 * abs(math.sin(t * 4 + k))}", "none", col, 10, op))
    return "".join(s)


def palace(t, dark=False):
    c1, c2 = ("#3a2440", "#5a3a5a") if dark else ("#f1dfb6", "#e2c78a")
    s = [bgwash(c1, c2)]
    for x in range(120, W, 340):
        s.append(f'<rect x="{x - 40}" y="160" width="80" height="760" fill="{"#6b4a6a" if dark else "#d9b878"}" stroke="{INK}" stroke-width="5"/>')
        s.append(P(f"M{x - 60},160 L{x + 60},160 L{x + 40},120 L{x - 40},120 Z", "url(#gold)", INK, 4))
    for x in range(-50, W, 340):
        s.append(P(f"M{x + 80},160 Q{x + 250},40 {x + 420},160", "none", "#a8322a", 14))
    s.append(f'<rect x="0" y="900" width="{W}" height="180" fill="{"#2a1a2a" if dark else "#c9a46e"}"/>')
    for x in range(0, W, 80): s.append(P(f"M{x},900 L{x + 40},1080", "none", INK, 2, .3))
    return "".join(s)


def env(kind, t, u):
    if kind == 'dusk':
        return (bgwash("#e8774a", "#8a2a3a") + C(W * .78, 300, 140, "url(#sunG)", INK, 5) + C(W * .78, 300, 360, "url(#glow)", op=.55)
                + K.hills(760, t, "#7a3a3a", 120, 2, .9) + f'<rect x="0" y="820" width="{W}" height="260" fill="#6a3a2a"/>' + motes(t, "#ffb070", 50, .6))
    if kind == 'night':
        return (bgwash("#0f1830", "#22325a") + "".join(C(x, y, r, "#fff3c4", op=.2 + .55 * abs(math.sin(t * 1.4 + p))) for x, y, p, r in K.STARS)
                + C(W * .82, 200, 80, "url(#moonG)", INK, 4) + K.hills(820, t, "#17223e", 90, 3))
    if kind == 'nightbattle':
        return (bgwash("#160c18", "#3a1420") + "".join(C(x, y, r, "#ffd0a0", op=.15 + .4 * abs(math.sin(t * 1.4 + p))) for x, y, p, r in K.STARS[:60])
                + f'<rect x="0" y="840" width="{W}" height="240" fill="#2a1414"/>' + "".join(C(200 + k * 220, 860, 40 + 10 * math.sin(t * 6 + k), "#ff7a2a", op=.35) for k in range(8)))
    if kind == 'hermitage':
        return (bgwash("#efe0bf", "#cdb57a") + K.hills(560, t, "#b7b98a", 140, 2, .9) + K.hills(680, t, "#97a36a", 90, 5) + tree(1700, 900, .9, t) + tree(160, 900, .7, t, "#7f9c56")
                + f'<rect x="0" y="880" width="{W}" height="200" fill="#d6bd86"/>' + grass(890, t, "#8a9a52", 60, 36))
    if kind == 'riverday':
        return (bgwash("#f6e7c6", "#cfe0a8") + C(W * .85, 200, 80, "url(#sunG)", INK, 5) + K.hills(640, t, "#b7b98a", 110, 1) + tree(200, 760, .6, t)
                + f'<rect x="0" y="720" width="{W}" height="120" fill="#cdb27a"/>' + river(820, t, "url(#riverD)", "#e6f2fd", 6))
    if kind == 'arena':
        return (bgwash("#f3d9a6", "#e2a86a") + f'<rect x="0" y="420" width="{W}" height="200" fill="#a8322a"/>' + "".join(P(f"M{x},420 l40,-60 l40,60 Z", "url(#gold)", INK, 3) for x in range(0, W, 80))
                + crowd(560, t, 26, "#5a2a1a") + f'<rect x="0" y="640" width="{W}" height="440" fill="#d9bc84"/>' + "".join(P(f"M{x},640 L{x - 200},1080", "none", INK, 2, .2) for x in range(0, W + 400, 160)))
    if kind == 'field':
        return (bgwash("#f6e2bd", "#f0b77a") + K.hills(700, t, "#c9a46e", 120, 1, .9) + tree(1650, 860, .8, t) + f'<rect x="0" y="860" width="{W}" height="220" fill="#d6bd86"/>' + grass(870, t, "#8a9a52", 60, 40))
    if kind == 'palace':
        return palace(t)
    if kind == 'hall':
        return palace(t, True)
    if kind == 'dawn':
        return bgwash("#f8d28e", "#f49a4a") + K.hills(780, t, "#8a4e3a", 60, 3, .9) + river(800, t, "url(#riverG)", "#ffd9a8", 6, 10)
    if kind == 'card':
        return bgwash("#2b1a12", "#5a2a1a")
    return bgwash("#f3e6cc", "#e9cfa2")


def cam(inner, s0, s1, u, cx=W / 2, cy=H / 2, dx=0., dy=0.):
    s = s0 + (s1 - s0) * ease(u)
    return f'<g transform="translate({cx + dx * ease(u):.1f},{cy + dy * ease(u):.1f}) scale({s:.4f}) translate({-cx:.1f},{-cy:.1f})">{inner}</g>'


# ---------------------------------------------------------------- characters (presets)
def karna(x, y, s, t, arms='down', face_=None, pose='stand', armour=True, flip=False, tilt=0, lift=0):
    fo = dict(crown=True, kundal=armour, mustache=True, open=blink(t, 3.4), smile=.1)
    if face_: fo.update(face_)
    g, h1, h2 = man(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, upper="url(#gold)" if armour else "url(#red)", dhoti="url(#saff)", angavastram="#a8322a", face=fo, tilt=tilt, lift=lift))
    return (G(g, x, 0, 1, 0, -1) if False else g), h1, h2


def arjuna(x, y, s, t, arms='down', face_=None):
    fo = dict(crown=True, open=blink(t, 2.9, 1), smile=.1, mustache=True)
    if face_: fo.update(face_)
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#white)", dhoti="url(#yel)", angavastram="#1f5fa8", face=fo))


def krishna(x, y, s, t, arms='down', face_=None):
    fo = dict(crown=True, feather=True, open=blink(t, 3.6, 2), smile=.45, skin="url(#skinB)")
    if face_: fo.update(face_)
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#yel)", dhoti="url(#yel)", angavastram="#2e8b57", armskin="url(#skinB)", face=fo))


def duryo(x, y, s, t, arms='down', face_=None, lift=0):
    fo = dict(crown=True, mustache=True, open=blink(t, 3.1, 1.5), smile=.2, angry=.3)
    if face_: fo.update(face_)
    return man(dict(x=x, y=y, s=s, pose='stand', arms=arms, t=t, upper="url(#purp)", dhoti="url(#gold)", angavastram="#3e1f5a", face=fo, lift=lift))


def sage(x, y, s, t, arms='rest', face_=None, pose='sit', col="url(#saff)", jata=True):
    fo = dict(old=True, beard="#e4ddd2", hair="#d8d2c8", jata=jata, tilak=True, wrinkles=True, open=blink(t, 3.8))
    if face_: fo.update(face_)
    return man(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, dhoti=col, upper=col, bare=True, mala=True, sacred=True, face=fo))


def kunti(x, y, s, t, arms='down', face_=None, pose='stand', young=False):
    fo = dict(open=blink(t, 2.7), smile=.1)
    if face_: fo.update(face_)
    return woman(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, saree="url(#red)" if young else "url(#kunti)", border="url(#bord)", face=fo))


# ---------------------------------------------------------------- beats
def B(env_, actors, cam_=(1.0, 1.08, 0, 0), fx=None):
    return dict(env=env_, actors=actors, cam=cam_, fx=fx)


def beat_scene(key, t, u):
    S = []
    if key == 'cold_battle':
        S.append(env('dusk', t, u))
        S.append(chariot(1460, 760, 1.0, t, spin=False))
        a, _, _ = krishna(1560, 300, .62, t, 'give', dict(gaze=(-1, 0)))
        r_, _, _ = arjuna(1330, 260, .7, t, 'draw', dict(angry=.4, gaze=(-1, 0)))
        S += [a, r_, bow(1255, 360, .75, 0, .8 + .2 * math.sin(t * 2))]
        S.append(chariot(500, 860, 1.0, t, 140 * ease(u), spin=False, flip=True))
        k_, h1, h2 = karna(560, 450, .75, t, 'wheel', dict(sad=.6, angry=.3, gaze=(1, 0), tremble=.2), pose='stand', armour=False)
        S.append(k_)
        S.append(motes(t, "#ffcc88", 50, .7))
        return cam("".join(S), 1.0, 1.1, u, 900, 600)
    if key == 'cold_close':
        S.append(env('dusk', t, u))
        k_, _, _ = karna(960, 420, 1.35, t, 'down', dict(sad=.9, open=.55, gaze=(0, .6), tremble=.4), armour=False)
        S.append(k_)
        return cam("".join(S), 1.0, 1.12, u, 960, 420)
    if key == 'title':
        return env('card', t, u) + sunface(W / 2, 430, 120, t, .9, .4) + motes(t, "#fff3c4", 40, .6)
    # ---- ch1
    if key == 'c1_serve':
        S.append(env('hermitage', t, u))
        soft = seg(u, .4, .7)
        sg, sh1, sh2 = sage(1180, 520, 1.0, t, 'bless' if soft > .4 else 'rest', dict(angry=1 - soft, smile=.4 * soft, gaze=(-1, .3)))
        S.append(sg)
        w, h1, h2 = kunti(700, 520, .9, t, 'offer', dict(gaze=(1, -.2), smile=.3), 'kneel', young=True)
        S.append(w + E(h2[0] + 6, h2[1] - 14, 50, 15, "#8a5a2c", INK, 4) + C(h2[0] - 14, h2[1] - 28, 14, "#d64532", INK, 3) + C(h2[0] + 14, h2[1] - 30, 13, "#f0b33c", INK, 3))
        if soft > .4:
            for k in range(10):
                ph = (t * .55 + k / 10) % 1; S.append(C(sh2[0] + 60 * math.cos(k * 1.7 + t), sh2[1] - 20 - ph * 160, 7 * (1 - ph) + 2, "#ffd36b", op=1 - ph))
        return cam("".join(S), 1.0, 1.08, u, 950, 600)
    if key == 'c1_surya':
        S.append(bgwash("#f7d98b", "#f4a236"))
        d = seg(u, 0, .6)
        S.append(f'<polygon points="880,{300 + 160 * d} 1040,{300 + 160 * d} 1300,1080 620,1080" fill="#fff8de" opacity="{.15 + .4 * d:.2f}"/>')
        S.append(sunface(960, 140 + 160 * d, 120, t, eyes_open=.1 + .5 * seg(u, .5, .8)))
        for k in range(7): S.append(horse(330 + k * 210, 180 + 160 * d + (k % 2) * 16, .6, t, k))
        w, _, _ = kunti(960, 470, .9, t, 'shield', dict(open=.45, sad=-.6, mouthOpen=.4, gaze=(0, -1)), young=True)
        S.append(w + motes(t, "#fff8de", 50, .8))
        return cam("".join(S), 1.0, 1.06, u)
    if key == 'c1_baby':
        S.append(bgwash("#f6dcae", "#f3a96a"))
        for i in range(30): S.append(G(P("M300,-8 L900,0 L300,8 Z", "#f7c948" if i % 2 else "#fff3c4", op=.45), 960, 520, 1, i * 12 + t * 8))
        w, _, _ = kunti(760, 260, 1.15, t, 'hold', dict(open=.5 * blink(t), gaze=(.7, 1), smile=.6), 'kneel', young=True)
        S.append(w + baby(860, 590, 1.1, t, armour=True, eyes=1 if u > .5 else 0))
        return cam("".join(S), 1.0, 1.1, u, 860, 560)
    if key == 'c1_cry':
        S.append(env('night', t, u)); S.append(river(820, t, "url(#riverN)", "#9fb8de", 6))
        bx = 760 + 700 * ease(cl((u - .3) / .7))
        S.append(basket(bx, 860 + 8 * math.sin(t * 2), 1.0 - .4 * ease(u), t))
        w, _, _ = kunti(560, 440, .95, t, 'reach' if u > .3 else 'hold', dict(open=.4, sad=1, tears=1, tremble=.7, gaze=(1, .5)), 'kneel', young=True)
        S.append(w)
        return cam("".join(S), 1.08, 1.0, u, 800, 600)
    if key == 'c1_radha':
        S.append(env('riverday', t, u))
        lift = seg(u, .2, .55)
        m_, _, _ = man(dict(x=1180, y=330, s=.85, pose='stand', arms='point', t=t, upper="url(#white)", angavastram="#e07b2a", face=dict(turban="#e07b2a", mustache=True, smile=.5 + .4 * lift, open=blink(t, 3.1), gaze=(-1, 0))))
        S.append(chariot(1550, 760, .7, t, spin=False) + m_)
        S.append(basket(860, 860, .85, t, lift < .05))
        r_, _, _ = woman(dict(x=860, y=270, s=.9, pose='stand', arms='lift', lift=lift, t=t, saree="url(#green)", border="url(#bordG)", face=dict(open=blink(t, 2.4) * (1 - .5 * lift), smile=.3 + .8 * lift, gaze=(0, -lift))))
        S.append(r_)
        if lift >= .05: S.append(baby(866, 830 - 300 * lift, .9, t, eyes=1 if lift > .7 else 0))
        return cam("".join(S), 1.06, 1.0, u, 960, 560)
    # ---- ch2
    if key == 'c2_reject':
        S.append(env('hermitage', t, u))
        sg, _, _ = sage(1260, 340, .85, t, 'point', dict(angry=.8, gaze=(-1, 0)), pose='stand', col="url(#white)", jata=False)
        k_, _, _ = karna(700, 360, .8, t, 'bow', dict(sad=.6, gaze=(1, .4)), armour=True)
        S += [sg, k_, bow(560, 460, .6)]
        return cam("".join(S), 1.0, 1.06, u, 960, 560)
    if key == 'c2_arena':
        S.append(env('arena', t, u))
        r_, _, _ = arjuna(700, 460, .8, t, 'draw', dict(gaze=(1, 0)))
        S += [r_, bow(615, 560, .62, 0, .9)]
        S.append(G(C(0, 0, 50, "#fff3c4", INK, 4) + C(0, 0, 30, "#c0392b", INK, 3) + C(0, 0, 10, "#fff3c4"), 1650, 520, 1))
        if u > .45:
            k_, _, _ = karna(1300, 460, .8, t, 'bow', dict(gaze=(-1, 0), smile=.2))
            S.append(k_)
        ax = 700 + (1650 - 700) * cl((u * 3) % 1); S.append(P(f"M{ax - 80},520 L{ax},520", "none", "#5a3a22", 5))
        return cam("".join(S), 1.0, 1.06, u, 960, 560)
    if key == 'c2_kripa':
        S.append(env('arena', t, u))
        kr, _, _ = sage(560, 440, .8, t, 'point', dict(angry=.6, gaze=(1, 0)), pose='stand', col="url(#white)", jata=False)
        lift = seg(u, .45, .8)
        k_, _, _ = karna(1000, 460, .8, t, 'down', dict(sad=1 - lift, smile=lift * .6, gaze=(0, 1 - 1.4 * lift)), tilt=10 * (1 - lift))
        d_, _, _ = duryo(1400, 440, .82, t, 'raise' if lift > .2 else 'down', dict(smile=.5, angry=0, gaze=(-1, 0)), lift=lift)
        S += [kr, k_, d_]
        if lift > .6: S.append(G(P("M-58,-30 L-62,-86 L-36,-72 L-20,-118 L0,-84 L20,-118 L36,-72 L62,-86 L58,-30 Q0,-46 -58,-30 Z", "url(#gold)", INK, 4), 1000, 380 - 60 * (1 - lift), .8))
        return cam("".join(S), 1.0, 1.08, u, 1000, 520)
    if key == 'c2_friend':
        S.append(env('palace', t, u))
        k_, _, _ = karna(820, 330, .95, t, 'hug', dict(smile=.7, gaze=(1, 0)))
        d_, _, _ = duryo(1120, 320, .95, t, 'hug', dict(smile=.8, angry=0, gaze=(-1, 0)))
        S += [k_, d_, motes(t, "#fff3c4", 40, .5)]
        return cam("".join(S), 1.0, 1.1, u, 970, 520)
    # ---- ch3
    if key == 'c3_learn':
        S.append(env('hermitage', t, u))
        pr, _, _ = sage(1200, 360, .85, t, 'point', dict(gaze=(-1, 0)), pose='stand', col="url(#saff)")
        S.append(pr + axe(1340, 640, .9, 10))
        k_, _, _ = karna(720, 380, .8, t, 'draw', dict(gaze=(-1, 0), angry=.2), armour=True)
        S += [k_, bow(640, 480, .6, 180, .8)]
        return cam("".join(S), 1.0, 1.06, u)
    if key == 'c3_bite':
        S.append(env('hermitage', t, u))
        k_, _, _ = karna(900, 520, 1.15, t, 'rest', dict(sad=.5, tremble=.8, open=.7, gaze=(0, 1)), pose='sit')
        S.append(k_)
        pr, _, _ = sage(0, 0, 1, t)
        S.append(G(face(dict(old=True, beard="#e4ddd2", hair="#d8d2c8", jata=True, tilak=True, wrinkles=True, open=0.05, t=t, male=True, skin="url(#skinD)")), 1060, 800, .9, 80))
        bx, by = 760, 860
        S.append(G(E(0, 0, 18, 10, "#2a1a10", INK, 2) + "".join(P(f"M{-10 + k * 10},0 l{-4 + k * 2},{14 if k % 2 else -14}", "none", INK, 2) for k in range(3)), bx + 10 * math.sin(t * 6), by, 1.2))
        for k in range(3):
            ph = (t * .5 + k / 3) % 1; S.append(P(f"M{bx},{by + 10 + ph * 60} q6,10 0,16 q-6,-6 0,-16 Z", "#b0201a", INK, 1.5, 1 - ph))
        for k in range(2):
            ph = (t * .4 + k / 2) % 1; S.append(C(860 + 30 * k, 440 + ph * 40, 5, "#bfe3ff", op=1 - ph))
        return cam("".join(S), 1.0, 1.14, u, 900, 640)
    if key == 'c3_curse':
        S.append(env('hermitage', t, u) + f'<rect width="{W}" height="{H}" fill="#a8322a" opacity="{.15 + .1 * math.sin(t * 6):.2f}"/>')
        pr, _, _ = sage(1150, 320, .95, t, 'raise', dict(angry=1, mouthOpen=.5 + .3 * abs(math.sin(t * 8)), gaze=(-1, .3)), pose='stand', col="url(#saff)")
        S.append(pr + axe(1260, 380, .9, -20 + 5 * math.sin(t * 3)))
        k_, _, _ = karna(700, 560, .85, t, 'rest', dict(sad=1, gaze=(1, -.3)), pose='sit')
        S.append(k_)
        return cam("".join(S), 1.0, 1.08, u, 960, 560)
    if key == 'c3_cow':
        S.append(env('field', t, u))
        S.append(cow(700, 830, .9, dead=True))
        br, _, _ = sage(1250, 340, .85, t, 'raise', dict(angry=1, mouthOpen=.4 + .3 * abs(math.sin(t * 7)), gaze=(-1, 0)), pose='stand', col="url(#white)", jata=False)
        k_, _, _ = karna(300, 360, .8, t, 'bow', dict(sad=.8, gaze=(1, .5)))
        S += [br, k_, bow(160, 460, .6)]
        return cam("".join(S), 1.0, 1.06, u)
    # ---- ch4
    if key == 'c4_swayamvar':
        S.append(env('palace', t, u))
        dr, _, _ = woman(dict(x=1300, y=290, s=.95, pose='stand', arms='shield', t=t, saree="url(#purp)", border="url(#bord)", face=dict(angry=.5, gaze=(-1, 0), open=blink(t, 2.5))))
        k_, _, _ = karna(700, 330, .9, t, 'bow', dict(sad=.7 * seg(u, .3, .6), angry=.3, gaze=(1, 0)))
        S += [dr, k_, bow(560, 430 + 60 * seg(u, .4, .7), .65, 40 * seg(u, .4, .7))]
        return cam("".join(S), 1.0, 1.06, u)
    if key == 'c4_dice':
        S.append(env('hall', t, u))
        S.append(f'<rect x="760" y="760" width="400" height="80" fill="#5a3a22" stroke="{INK}" stroke-width="4"/>' + "".join(G(f'<rect x="-14" y="-14" width="28" height="28" fill="#f4efe2" stroke="{INK}" stroke-width="2"/>', 900 + k * 60, 740, 1, t * 40 + k * 20) for k in range(3)))
        k_, _, _ = karna(600, 340, .85, t, 'point', dict(angry=.8, smile=.2, gaze=(1, 0)))
        d_, _, _ = duryo(1350, 330, .85, t, 'down', dict(smile=.6, angry=.4, gaze=(-1, 0)))
        S += [k_, d_, f'<rect width="{W}" height="{H}" fill="#000" opacity=".2"/>']
        return cam("".join(S), 1.0, 1.06, u)
    # ---- ch5
    if key == 'c5_dream':
        S.append(env('night', t, u))
        S.append(f'<rect x="500" y="760" width="900" height="70" fill="#8a5a2c" stroke="{INK}" stroke-width="4"/>')
        S.append(G(face(dict(crown=True, kundal=True, mustache=True, open=0.05, t=t, male=True, skin="url(#skinD)")), 760, 720, .9, -80))
        S.append(f'<g opacity="{seg(u, .1, .4):.2f}">' + sunface(1250, 380, 120, t, 1, .5) + '</g>')
        return cam("".join(S), 1.0, 1.08, u)
    if key == 'c5_door':
        S.append(env('palace', t, u))
        ib, _, _ = sage(1300, 340, .85, t, 'give', dict(smile=.3, gaze=(-1, 0)), pose='stand', col="url(#white)", jata=False)
        k_, _, _ = karna(700, 340, .9, t, 'down', dict(smile=.4, gaze=(1, 0)))
        S += [ib, k_]
        return cam("".join(S), 1.0, 1.06, u)
    if key == 'c5_give':
        S.append(env('palace', t, u))
        g_ = seg(u, .2, .6)
        k_, kh1, kh2 = karna(760, 330, .95, t, 'give' if g_ > .2 else 'down', dict(sad=.3, smile=.3, gaze=(1, 0), tremble=.3), armour=g_ < .5)
        ib, ih1, ih2 = sage(1300, 340, .85, t, 'give', dict(sad=.4, gaze=(-1, 0)), pose='stand', col="url(#white)", jata=False)
        S += [k_, ib]
        if g_ > .3:
            px = kh2[0] + (ih2[0] - kh2[0]) * seg(u, .4, .7)
            S.append(G(P("M-50,-40 L50,-40 L40,40 L-40,40 Z", "url(#gold)", INK, 4) + C(0, 0, 70, "url(#glow)", op=.7), px, kh2[1] - 20, .9))
        if u > .75:
            S.append(G(P("M0,0 L0,-240", "none", "#fff3c4", 8) + C(0, -250, 30, "url(#glow)") + P("M-14,-240 L0,-290 L14,-240 Z", "#ffe08a", INK, 2), ih1[0], ih1[1] + 40, 1))
        return cam("".join(S), 1.0, 1.08, u)
    # ---- ch6
    if key == 'c6_krishna':
        S.append(env('riverday', t, u))
        kr, _, _ = krishna(1180, 280, .9, t, 'give', dict(gaze=(-1, 0)))
        k_, _, _ = karna(720, 280, .9, t, 'down', dict(sad=.5 + .3 * u, gaze=(1, 0)))
        S += [kr, k_]
        return cam("".join(S), 1.0, 1.08, u)
    if key == 'c6_refuse':
        S.append(env('riverday', t, u))
        kr, _, _ = krishna(1240, 280, .85, t, 'down', dict(gaze=(-1, 0), smile=.1, sad=.3))
        k_, _, _ = karna(760, 260, 1.0, t, 'raise', dict(angry=.3, sad=.4, gaze=(1, -.2)))
        S += [kr, k_]
        return cam("".join(S), 1.04, 1.1, u, 800, 500)
    if key == 'c6_kunti':
        S.append(env('riverday', t, u))
        kn, _, _ = kunti(1180, 300, .95, t, 'reach', dict(sad=1, tears=1, tremble=.6, gaze=(-1, 0)))
        k_, _, _ = karna(720, 300, .95, t, 'give', dict(sad=.8, tears=.6 * seg(u, .3, .7), gaze=(1, 0)))
        S += [kn, k_]
        return cam("".join(S), 1.0, 1.12, u, 950, 480)
    # ---- ch7
    if key == 'c7_ghat':
        S.append(env('nightbattle', t, u))
        S.append(man(dict(x=1400, y=60, s=1.6, pose='stand', arms='raise', t=t, upper="url(#skinG)", dhoti="#3a1414", armskin="url(#skinG)", face=dict(angry=1, mouthOpen=.6, skin="url(#skinG)", hair=INK, gaze=(-1, .3))))[0])
        k_, h1, h2 = karna(560, 400, .8, t, 'raise', dict(angry=.6, sad=.4, gaze=(1, -.4)), armour=False, lift=1)
        S.append(k_)
        if u > .5:
            v = seg(u, .5, .75); S.append(P(f"M{h2[0]},{h2[1]} L{h2[0] + (1400 - h2[0]) * v},{h2[1] + (300 - h2[1]) * v}", "none", "#fff3a0", 14) + C(h2[0] + (1400 - h2[0]) * v, h2[1] + (300 - h2[1]) * v, 50, "url(#glow)"))
        return cam("".join(S), 1.0, 1.06, u)
    if key == 'c7_wheel':
        return beat_scene('cold_battle', t, u)
    if key == 'c7_krishna':
        S.append(env('dusk', t, u))
        kr, _, _ = krishna(1280, 300, .95, t, 'point', dict(angry=.5, mouthOpen=.3 * abs(math.sin(t * 8)), gaze=(-1, 0)))
        k_, _, _ = karna(640, 330, .9, t, 'down', dict(sad=1, gaze=(1, .6)), armour=False)
        S += [kr, k_]
        if u > .7:
            v = seg(u, .7, .85); S.append(P(f"M{1700 - 900 * v},420 l120,0", "none", "#c9ced6", 6) + f'<rect width="{W}" height="{H}" fill="#fff" opacity="{.5 * max(0, 1 - abs(v - 1) * 6):.2f}"/>')
        return cam("".join(S), 1.0, 1.1, u, 900, 500)
    if key == 'c7_grief':
        S.append(env('night', t, u))
        kn, _, _ = kunti(700, 300, .95, t, 'pray', dict(sad=1, tears=1, gaze=(1, .5)))
        yu, _, _ = man(dict(x=1200, y=360, s=.9, pose='stand', arms='down', t=t, upper="url(#white)", dhoti="url(#kunti)", face=dict(crown=True, mustache=True, sad=1, tears=1, tremble=.6, open=.5, gaze=(-1, .5))))
        S += [kn, yu]
        return cam("".join(S), 1.0, 1.1, u)
    if key == 'outro':
        S.append(env('dawn', t, u))
        S.append(sunface(1300, 420, 210, t, .95, .4))
        k_, _, _ = karna(650, 280, 1.0, t, 'bow', dict(smile=.3, gaze=(1, -.3)))
        S += [k_, bow(500, 380, .7)]
        return cam("".join(S), 1.0, 1.06, u)
    return env('card', t, u)


# line index -> beat key
PLAN = {
 0: ['cold_battle', 'cold_battle'], 1: ['cold_close', 'cold_close'],
}
def beat_for(m):
    ch, p = m['ch'], m.get('para', 0)
    if m['kind'] == 'title': return 'title'
    table = {
        0: ['cold_battle', 'cold_close'], 1: ['title'],
        2: ['c1_serve', 'c1_surya', 'c1_cry'],
        3: ['c2_reject', 'c2_arena', 'c2_kripa', 'c2_friend'],
        4: ['c3_learn', 'c3_bite', 'c3_curse', 'c3_cow'],
        5: ['c4_swayamvar', 'c4_dice'],
        6: ['c5_door', 'c5_dream', 'c5_give'],
        7: ['c6_krishna', 'c6_refuse', 'c6_kunti'],
        8: ['c7_ghat', 'c7_wheel', 'c7_krishna', 'c7_grief'],
        9: ['outro'],
    }
    return table[ch][min(p, len(table[ch]) - 1)]


# refine ch1 para 2 (crying para has 3 sentences: first 'cry', last radha) and ch1 para1 sentence2 baby
SEGMENTS = []
for i, m in enumerate(META):
    key = beat_for(m)
    if m['ch'] == 2 and m.get('para') == 1 and 'पुत्र मिला' in m['text']: key = 'c1_baby'
    if m['ch'] == 2 and m.get('para') == 2 and ('अधिरथ' in m['text'] or 'राधेय' in m['text']): key = 'c1_radha'
    if m['ch'] == 6 and m.get('para') == 1: key = 'c5_dream'
    if m['ch'] == 6 and m.get('para') == 0: key = 'c5_door'
    SEGMENTS.append(dict(key=key, start=m['start'], end=META[i + 1]['start'] if i + 1 < len(META) else TOTAL, text=m['text'] if m['kind'] == 'line' else '', kind=m['kind'], title=m['text'] if m['kind'] == 'title' else '', ch=m['ch']))
# merge consecutive same-key segments into shots
SHOTS = []
for sgm in SEGMENTS:
    if SHOTS and SHOTS[-1]['key'] == sgm['key'] and sgm['kind'] == 'line' and SHOTS[-1]['kind'] == 'line':
        SHOTS[-1]['end'] = sgm['end']
    else:
        SHOTS.append(dict(sgm))
SHOTS[-1]['end'] = TOTAL
XF = .5


def font(sz): return ImageFont.truetype(FONT, sz, layout_engine=ImageFont.Layout.RAQM)


def subtitle(img, text, u):
    if not text: return
    d = ImageDraw.Draw(img); f = font(40); maxw = 1500
    words = text.split(" "); ls = []; cur = []
    for w_ in words:
        if d.textlength(" ".join(cur + [w_]), font=f) <= maxw: cur.append(w_)
        else: ls.append(cur); cur = [w_]
    ls.append(cur); lh = 58; y = H - 70 - lh * len(ls)
    total = sum(len(w_) for w_ in words); cut = u * total * 1.06; acc = 0
    ov = Image.new("RGBA", img.size, (0, 0, 0, 0)); ImageDraw.Draw(ov).rounded_rectangle([170, y - 14, W - 170, y + lh * len(ls) + 8], 22, fill=(20, 10, 6, 160))
    img.alpha_composite(ov); d = ImageDraw.Draw(img)
    for i, l in enumerate(ls):
        x = (W - d.textlength(" ".join(l), font=f)) / 2
        for w_ in l:
            col = (255, 213, 74) if acc < cut <= acc + len(w_) + 1 else ((255, 255, 255) if acc < cut else (225, 215, 200))
            d.text((x, y + i * lh), w_, font=f, fill=col, stroke_width=3, stroke_fill=(0, 0, 0)); x += d.textlength(w_ + " ", font=f); acc += len(w_) + 1


def ctext(img, text, y, sz, fill, stroke=(60, 0, 0)):
    d = ImageDraw.Draw(img); f = font(sz); tw = d.textlength(text, font=f)
    d.text(((W - tw) / 2, y), text, font=f, fill=fill, stroke_width=5 if stroke else 0, stroke_fill=stroke)


def render(shot, t):
    u = cl((t - shot['start']) / (shot['end'] - shot['start']))
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">{K.DEFS}' + beat_scene(shot['key'], t, u) + '</svg>'
    return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert("RGB")


def frame(n):
    t = n / FPS
    i = max(k for k in range(len(SHOTS)) if SHOTS[k]['start'] <= t)
    sh = SHOTS[i]
    img = render(sh, t)
    if i + 1 < len(SHOTS) and SHOTS[i + 1]['start'] - t < XF:
        img = Image.blend(img, render(SHOTS[i + 1], t), ease(1 - (SHOTS[i + 1]['start'] - t) / XF))
    img = K.post(img).convert("RGBA")
    # find current sentence for subtitle
    cur = [s for s in SEGMENTS if s['start'] <= t < s['end'] and s['kind'] == 'line']
    if cur:
        c = cur[0]; subtitle(img, c['text'], cl((t - c['start']) / max(.5, (c['end'] - c['start']) - .35)))
    if sh['key'] == 'title':
        ttl = sh['title'] or "कर्ण: शापित योद्धा"
        if sh['ch'] == 1: ctext(img, "कथालोक", 600, 110, (255, 213, 74)); ctext(img, "कर्ण: शापित योद्धा | पूरी कहानी", 760, 56, (255, 240, 210))
        else: ctext(img, ttl, 640, 84, (255, 213, 74))
    if t < 1.5 or t > TOTAL - 3:
        pass
    return img.convert("RGB")


if __name__ == "__main__":
    a, b = int(sys.argv[1]), int(sys.argv[2])
    for n in range(a, b):
        frame(n).save(f"/home/claude/kathalok/long_kr/frames/f{n:05d}.jpg", quality=90)
