import sys, io, json
sys.path.insert(0, '/home/claude/kathalok/long_kr'); sys.path.insert(0, '/home/claude/kathalok/b2')
import kgbase as K, eps
from PIL import Image
import cairosvg
EP = sys.argv[1]
d = json.load(open('/home/claude/kathalok/b1/batch1.json')); d = d if isinstance(d, list) else d['episodes']
E_ = [e for e in d if e['id'] == EP][0]
TM = json.load(open(f'/home/claude/kathalok/b2/{EP}/times.json')); TM.append(TM[-1] + 3.8)
SC = eps.EPS[EP]['scenes']; LINES = E_['vo']; NL = len(LINES)
assert len(SC) == NL + 1, (len(SC), NL)
FPS = 30; W, H = 1080, 1920


def rs(i, t):
    u = K.cl((t - TM[i]) / (TM[i + 1] - TM[i]))
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}">{K.DEFS}' + SC[i](t, u) + '</svg>'
    return Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode()))).convert("RGB")


def frame(n):
    t = n / FPS
    i = max(k for k in range(len(TM) - 1) if TM[k] <= t) if t < TM[-1] else len(TM) - 2
    img = rs(i, t)
    if i + 1 < len(SC) and TM[i + 1] - t < .5:
        img = Image.blend(img, rs(i + 1, t), K.ease(1 - (TM[i + 1] - t) / .5))
    img = K.post(img).convert("RGBA"); u = K.cl((t - TM[i]) / (TM[i + 1] - TM[i]))
    if i < NL:
        K.subtitle(img, LINES[i], u)
        if t > TM[1]: K.ctext(img, eps.EPS[EP]['tag'], 170, 34, (255, 233, 176), None, (110, 20, 10, 200))
    if i == 0: K.ctext(img, eps.EPS[EP]['hook'], 230, 70, (255, 213, 74))
    if i == NL:
        K.ctext(img, "आगे क्या हुआ?", 1020, 84, (255, 213, 74))
        K.ctext(img, "पूरी कहानी यूट्यूब पर | लिंक बायो में", 1170, 44, (255, 255, 255), (0, 0, 0))
        K.ctext(img, "फ़ॉलो करें | कथालोक", 1280, 48, (255, 233, 176), (0, 0, 0))
    return img.convert("RGB")


if __name__ == "__main__":
    if sys.argv[2] == 'sheet':
        ims = [frame(int(((TM[k] + TM[k + 1]) / 2) * FPS)).resize((270, 480)) for k in range(len(SC))]
        sh = Image.new('RGB', (270 * len(ims), 480)); [sh.paste(im, (k * 270, 0)) for k, im in enumerate(ims)]
        sh.save(f'/home/claude/kathalok/b2/{EP}/sheet.jpg'); print('ok', int(TM[-1] * FPS))
    else:
        a, b = int(sys.argv[2]), int(sys.argv[3])
        for n in range(a, b): frame(n).save(f'/home/claude/kathalok/b2/{EP}/frames/f{n:05d}.jpg', quality=92)
