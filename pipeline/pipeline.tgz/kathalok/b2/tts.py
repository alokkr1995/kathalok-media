import json, sys, numpy as np, soundfile as sf, os
from kokoro_onnx import Kokoro
k = Kokoro(os.path.expanduser('~/tts/kokoro-v1.0.onnx'), os.path.expanduser('~/tts/voices-v1.0.bin'))
d = json.load(open('../b1/batch1.json')); d = d if isinstance(d, list) else d['episodes']
for e in d[1:]:
    os.makedirs(e['id'], exist_ok=True); out = []; times = [0.0]; sr = 24000
    for i, line in enumerate(e['vo']):
        s, sr = k.create(line, voice='hm_omega', speed=1.0, lang='hi')
        out.append(s); gap = 0.55 if i == 0 else 0.4
        out.append(np.zeros(int(sr * gap))); times.append(times[-1] + len(s) / sr + gap)
    a = np.concatenate(out); a = a / np.abs(a).max() * .9
    sf.write(f"{e['id']}/vo.wav", a, sr); json.dump(times, open(f"{e['id']}/times.json", 'w'))
    print(e['id'], round(times[-1], 1), [round(x, 1) for x in times])
