import math, random
import sys
sys.path.insert(0, '/home/claude/kathalok/long_kr')
import kgbase as K
from kgbase import P, E, C, G, INK, face, woman, man, baby, river, lotus, tree, hills, grass, sunface, horse, motes, bgwash, cl, ease, seg, blink, cam, par

W, H = 1080, 1920
GY = 1180  # ground line


def ystand_w(s): return GY - 596 * s
def ystand_m(s): return GY - 550 * s


def sage(x, s, t, arms='rest', fo=None, pose='sit', col="url(#saff)", y=None, beard="#e4ddd2", hair="#d8d2c8", jata=True):
    f = dict(old=True, beard=beard, hair=hair, jata=jata, tilak=True, wrinkles=True, open=blink(t, 3.8))
    if fo: f.update(fo)
    if y is None: y = GY - (350 if pose == 'sit' else 550) * s
    return man(dict(x=x, y=y, s=s, pose=pose, arms=arms, t=t, dhoti=col, upper=col, bare=True, mala=True, sacred=True, face=f))


def king(x, s, t, arms='down', fo=None, upper="url(#purp)", dhoti="url(#gold)", ang="#3e1f5a", y=None, skin=None, pose='stand', lift=0):
    f = dict(crown=True, mustache=True, open=blink(t, 3.1, x / 300))
    if skin: f['skin'] = skin
    if fo: f.update(fo)
    o = dict(x=x, y=ystand_m(s) if y is None else y, s=s, pose=pose, arms=arms, t=t, upper=upper, dhoti=dhoti, angavastram=ang, face=f, lift=lift)
    if skin: o['armskin'] = skin
    return man(o)


def lady(x, s, t, arms='down', fo=None, saree="url(#red)", border="url(#bord)", y=None, pose='stand', lift=0):
    f = dict(open=blink(t, 2.7, x / 400), smile=.2)
    if fo: f.update(fo)
    return woman(dict(x=x, y=ystand_w(s) if y is None else y, s=s, pose=pose, arms=arms, t=t, saree=saree, border=border, face=f, lift=lift))


def tail(x, y, s, t, col="#8a5a2c"):
    return P(f"M{x},{y} q{60 * s},{40 * s} {80 * s},{-60 * s} q{20 * s},{-80 * s + 10 * math.sin(t * 2)} {70 * s},{-110 * s}", "none", INK, 22 * s) + P(f"M{x},{y} q{60 * s},{40 * s} {80 * s},{-60 * s} q{20 * s},{-80 * s + 10 * math.sin(t * 2)} {70 * s},{-110 * s}", "none", col, 14 * s)


def fire(x, y, s, t):
    g = f'<rect x="-90" y="0" width="180" height="70" fill="#8a5a2c" stroke="{INK}" stroke-width="5"/>'
    for k in range(5):
        h = 120 + 30 * math.sin(t * 9 + k * 1.7)
        g += P(f"M{-70 + k * 35},0 Q{-90 + k * 35},{-h * .5} {-70 + k * 35 + 6 * math.sin(t * 7 + k)},{-h} Q{-50 + k * 35},{-h * .5} {-40 + k * 35},0 Z", "#f39a2a" if k % 2 else "#e2462a", INK, 3)
    g += C(0, -60, 160, "url(#glow)", op=.5)
    return G(g, x, y, s)


def fish(x, y, s, t, glow=0., crown=False, ang=0.):
    sw = 10 * math.sin(t * 6)
    g = ""
    if glow: g += C(0, 0, 220, "url(#glow)", op=glow)
    g += P(f"M110,0 L180,{-50 + sw} L170,0 L180,{50 + sw} Z", "url(#gold)", INK, 5)
    g += E(0, 0, 130, 62, "url(#gold)", INK, 6)
    for k in range(5):
        g += P(f"M{-40 + k * 30},-50 q15,50 0,100", "none", "#a87418", 3, .7)
    g += C(-80, -12, 14, "#fff", INK, 3) + C(-84, -12, 7, INK) + P("M-128,10 q12,8 22,0", "none", INK, 4)
    g += P("M-20,-60 Q10,-110 50,-58", "#e2462a", INK, 4)
    if crown: g += P("M-110,-50 L-118,-110 L-96,-90 L-84,-130 L-70,-90 L-50,-112 L-56,-50 Z", "url(#gold)", INK, 4) + C(-84, -86, 6, "#c0392b")
    return G(g, x, y, s, ang)


def kamandal(x, y, s, col="#8a5a2c"):
    return G(E(0, 0, 70, 60, col, INK, 5) + P("M-30,-56 L-26,-90 L26,-90 L30,-56", col, INK, 5) + P("M60,-10 Q120,-20 130,-70", "none", INK, 8) + P("M-40,-90 Q0,-170 40,-90", "none", INK, 6), x, y, s)


def boat(x, y, s, t, rock=0.):
    g = P("M-260,0 Q0,90 260,0 L230,-40 L-230,-40 Z", "#8a5a2c", INK, 6) + P("M-230,-40 L230,-40", "none", "#c08a52", 6)
    g += P("M0,-40 L0,-330", "none", INK, 8) + P("M6,-320 Q140,-200 6,-80 Z", "#f4efe2", INK, 4)
    return G(g, x, y, s, rock * math.sin(t * 1.6))


def waves(y, t, col="#2b5c8f", line="#cfe4f7", amp=26, n=8, speed=1.):
    s = []
    for r in range(4):
        yy = y + r * 70
        d = f"M-40,{yy} " + " ".join(f"Q{x + 60},{yy - amp - 10 * math.sin(t * speed * 2 + x / 90 + r)} {x + 120},{yy}" for x in range(-40, W + 120, 120)) + f" L{W + 80},{H} L-40,{H} Z"
        s.append(P(d, col, INK, 4, .9 - r * .1))
        s.append(P(f"M-40,{yy + 14} " + " ".join(f"Q{x + 60},{yy - amp + 6} {x + 120},{yy + 14}" for x in range(-40, W + 120, 120)), "none", line, 3, .7))
    return "".join(s)


def rain(t, n=70, op=.5):
    r = random.Random(3); s = []
    for k in range(n):
        x = r.uniform(0, W); ph = (t * 1.6 + r.random()) % 1
        y = ph * H
        s.append(P(f"M{x},{y} l-18,60", "none", "#cfe4f7", 3, op))
    return "".join(s)


def lightning(t, x=700):
    on = (t * 1.3) % 2.2 < .12
    if not on: return ""
    return f'<rect width="{W}" height="{H}" fill="#fff" opacity=".35"/>' + P(f"M{x},0 L{x - 60},300 L{x + 20},300 L{x - 80},700", "none", "#fffbe0", 12)


def chakra(x, y, r, t, op=1.):
    g = C(0, 0, r, "url(#gold)", INK, 5) + C(0, 0, r * .35, "#c0392b", INK, 4)
    for k in range(12):
        g += G(P(f"M0,{-r * .35} L{r * .1},{-r * .8} L0,{-r * 1.25} L{-r * .1},{-r * .8} Z", "url(#gold)", INK, 3), 0, 0, 1, k * 30)
    return f'<g opacity="{op:.2f}">' + G(g, x, y, 1, t * 120) + '</g>'


def linga(x, y, s):
    return G(E(0, 40, 170, 40, "#6b6b73", INK, 5) + P("M-60,40 Q-70,-150 0,-170 Q70,-150 60,40 Z", "#3a3a44", INK, 5) + P("M-50,-80 L50,-80 M-50,-60 L50,-60 M-50,-40 L50,-40", "none", "#f4efe2", 6) + C(0, -60, 8, "#c0392b") + P("M170,40 L260,40", "none", INK, 10), x, y, s)


def trishul(x, y, s, op=1.):
    return f'<g opacity="{op:.2f}">' + G(P("M0,300 L0,-160", "none", "url(#gold)", 14) + P("M-90,-120 Q-90,-40 0,-40 Q90,-40 90,-120 M0,-40 L0,-230", "none", "#e8d27a", 14) + P("M-90,-120 l-18,30 m18,-30 l18,30 M90,-120 l-18,30 m18,-30 l18,30 M0,-230 l-18,30 m18,-30 l18,30", "none", "#e8d27a", 10), x, y, s) + '</g>'


def bird(x, y, s, t, carry=True):
    fl = 40 * math.sin(t * 12)
    g = P(f"M0,0 Q-80,{-60 - fl} -170,{-20 - fl} Q-90,-6 0,10 Q90,-6 170,{-20 - fl} Q80,{-60 - fl} 0,0 Z", "#6b4226", INK, 4) + E(0, 6, 34, 18, "#8a5a36", INK, 4) + P("M-34,0 l-24,8 l24,6", "#e2b13c", INK, 3) + C(-22, -2, 4, INK)
    if carry: g += E(10, 50, 40, 14, "url(#gold)", INK, 4) + E(10, 44, 30, 8, "#f6efe0", "none")
    return G(g, x, y, s)


def ravana(x, y, s, t, op=1.):
    g = ""
    for k in range(-4, 6):
        if k == 0: continue
        g += G(face(dict(crown=True, mustache=True, male=True, angry=.8, open=blink(t, 3, k), t=t, skin="url(#skinD)")), k * 95 + (40 if k < 0 else -40) * 0, -abs(k) * 8, .55)
    g += G(face(dict(crown=True, mustache=True, male=True, angry=1, open=blink(t, 3), smile=.3, t=t, skin="url(#skinD)")), 0, 0, .7)
    return f'<g opacity="{op:.2f}">' + G(g, x, y, s) + '</g>'


def towers(t, col="#2a1a2a", gold=True):
    s = []
    for i, (x, h) in enumerate([(120, 520), (300, 760), (500, 900), (700, 700), (900, 600)]):
        s.append(f'<rect x="{x - 60}" y="{GY - h}" width="120" height="{h}" fill="{col}" stroke="{INK}" stroke-width="5"/>')
        s.append(P(f"M{x - 70},{GY - h} L{x},{GY - h - 140} L{x + 70},{GY - h} Z", "url(#gold)" if gold else col, INK, 5))
        for k in range(3): s.append(f'<rect x="{x - 20}" y="{GY - h + 60 + k * 150}" width="40" height="70" fill="#ffcf5a" opacity="{.5 + .4 * abs(math.sin(t * 2 + i + k)):.2f}"/>')
    return "".join(s)


def clouds(t, col="#3a3348", y=200, op=.9):
    s = []
    for k in range(6):
        x = (k * 230 + t * 20) % (W + 400) - 200
        s.append(E(x, y + 40 * (k % 2), 200, 70, col, INK, 4, op) + E(x + 90, y - 30 + 40 * (k % 2), 120, 60, col, INK, 4, op))
    return "".join(s)


def chariot(x, y, s, t, flip=False, banner="#c0392b"):
    g = P("M-150,-110 L150,-110 L130,0 L-130,0 Z", "#b07a3a", INK, 5) + P("M-140,-110 L-140,-230 M140,-110 L140,-230 M-150,-230 L150,-230", "none", INK, 6)
    g += P("M0,-230 L0,-380", "none", INK, 5) + P(f"M0,-380 L{90 + 10 * math.sin(t * 5)},-355 L0,-330 Z", banner, INK, 3)
    g += G(C(0, 0, 80, "none", INK, 11) + "".join(G(P("M0,-76 L0,76", "none", INK, 5), 0, 0, 1, k * 30) for k in range(6)) + C(0, 0, 12, "url(#gold)", INK, 3), -30, 20, 1)
    return G(g, x, y, s, 0, -s if flip else None)


def army(y, t, n, col, s=1., flip=False):
    out = []
    r = random.Random(int(y))
    for k in range(n):
        x = r.uniform(-20, W + 20); yy = y + r.uniform(-20, 20); bob = 3 * math.sin(t * 4 + k)
        out.append(C(x, yy - 60 * s + bob, 16 * s, col) + P(f"M{x - 22 * s},{yy + 30 * s} Q{x},{yy - 60 * s + bob} {x + 22 * s},{yy + 30 * s} Z", col) + P(f"M{x + 14 * s},{yy - 30 * s} L{x + 20 * s},{yy - 120 * s}", "none", col, 4 * s))
    return "".join(out)


def elephant(x, y, s, t, col="#8a8a94"):
    g = E(0, 0, 150, 90, col, INK, 5) + E(-140, -30, 70, 66, col, INK, 5) + P(f"M-190,0 Q-210,{80 + 10 * math.sin(t * 2)} -170,120", "none", INK, 24) + P(f"M-190,0 Q-210,{80 + 10 * math.sin(t * 2)} -170,120", "none", col, 16) + E(-110, -30, 40, 50, col, INK, 4) + C(-160, -40, 6, INK)
    g += P("M-80,-90 L80,-90 L60,-130 L-60,-130 Z", "url(#red)", INK, 4)
    for lx in (-100, -40, 60, 110): g += f'<rect x="{lx - 18}" y="60" width="36" height="80" fill="{col}" stroke="{INK}" stroke-width="4"/>'
    return G(g, x, y, s)


def conch(x, y, s, ang=0.):
    return G(P("M0,0 Q60,-60 120,-20 Q160,20 120,50 Q60,70 0,0 Z", "#fbf6ea", INK, 5) + P("M30,0 Q70,-30 110,0 M50,20 Q80,0 110,25", "none", "#c9a46e", 3), x, y, s, ang)


def soundrings(x, y, t, col="#fff3c4"):
    s = ""
    for k in range(4):
        ph = (t * .8 + k / 4) % 1
        s += C(x, y, 60 + ph * 420, "none", col, 6 * (1 - ph), 1 - ph)
    return s


def bow(x, y, s=1., ang=0., draw=0.):
    g = P("M0,-170 Q-60,0 0,170", "none", "#6b4226", 12) + P("M0,-170 Q-60,0 0,170", "none", INK, 3) + P(f"M0,-170 L{-40 * draw},0 L0,170", "none", "#f4efe2", 2.5)
    return G(g, x, y, s, ang)


def apsara(x, y, s, t, transform=0.):
    sw = 12 * math.sin(t * 2)
    g, h1, h2 = lady(x, s, t, 'lift', dict(smile=.7 * (1 - transform), sad=transform, open=blink(t, 2.4)), saree="url(#purp)", border="url(#bord)", y=y + sw, lift=.6)
    return g


# ===================================================================== RV-01
def rv0(t, u):
    s = [bgwash("#2b1018", "#6a1a2a"), C(540, 600, 520, "url(#glow)", op=.25)]
    s.append(ravana(540, 520 + 20 * math.sin(t), 1.9, t, .3 + .7 * seg(u, 0, .4)))
    sg, _, _ = sage(540, .95, t, 'pray', dict(sad=.5, gaze=(0, -1)), col="url(#white)")
    s.append(sg + motes(t, "#ff9a6a", 40, .6))
    return cam("".join(s), 1.08, 1.0, u, 540, 800)


def rv1(t, u):
    s = [bgwash("#f6e2bd", "#e9c48a"), C(540, 420, 260, "url(#glow)", op=.7), lotus(540, 520, 2.2, t)]
    s.append(G(face(dict(crown=False, old=True, beard="#f4efe2", hair="#f4efe2", t=t, male=True, open=.2, smile=.4)), 540, 330, .7))
    a, _, _ = sage(300, .8, t, 'pray', dict(open=.15, smile=.3))
    b, _, _ = sage(790, .8, t, 'bless', dict(open=blink(t), smile=.4, gaze=(-1, 0)), col="url(#white)")
    s += [a, b, grass(GY + 10, t, "#8a9a52", 40, 30), motes(t)]
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


def rv2(t, u):
    s = [bgwash("#2a1428", "#5a2a3a"), towers(t, "#3a1a2a")]
    sm, _, _ = king(720, .9, t, 'point', dict(angry=.6, smile=.3, gaze=(-1, 0), beard=INK), upper="url(#redN)", dhoti="#2a1414", ang="#1a0a0a", skin="url(#skinD)")
    kk, _, _ = lady(330, .88, t, 'down', dict(sad=.3, gaze=(1, 0)), saree="url(#green)", border="url(#bordG)")
    s += [sm, kk, motes(t, "#ff9a6a", 30, .5)]
    return cam("".join(s), 1.0, 1.08, u, 540, 820)


def rv3(t, u):
    s = [bgwash("#0e0a14", "#2a1a2a"), P(f"M0,0 L{W},0 L{W},360 Q540,520 0,360 Z", "#3a2a3a", INK, 6), chakra(540, 220, 110, t, .5 + .5 * seg(u, 0, .4)), C(540, 220, 300, "url(#glow)", op=.4)]
    s.append(army(1050, t, 26, "#120a12", 1.2) + army(1150, t, 22, "#1a0e1a", 1.4))
    sm, _, _ = king(540, .7, t, 'raise', dict(angry=1, gaze=(0, -1), beard=INK), upper="url(#redN)", dhoti="#2a1414", skin="url(#skinD)", y=GY - 550 * .7 - 120)
    s.append(sm)
    return cam("".join(s), 1.0, 1.08, u, 540, 700)


def rv4(t, u):
    s = [bgwash("#f0a060", "#7a2a3a"), C(820, 520, 110, "url(#sunG)", INK, 5), hills(900, t, "#6a3a3a", 100, 2, .9)]
    for x in (120, 340, 860, 1000): s.append(tree(x, 1150, .9, t, "#4f6e34", "#2d4a24"))
    walk = seg(u, 0, 1)
    kk, _, _ = lady(260 + 380 * walk, .85, t, 'down', dict(sad=.2, gaze=(1, 0)), saree="url(#green)", border="url(#bordG)", y=ystand_w(.85) + 6 * abs(math.sin(t * 5)))
    s.append(kk + P("M780,1180 L820,1000 L1000,1000 L1040,1180 Z", "#8a5a2c", INK, 5) + P("M760,1000 L910,880 L1060,1000 Z", "#c9a46e", INK, 5))
    s.append(grass(GY + 10, t, "#4f6e34", 50, 40))
    return cam("".join(s), 1.0, 1.06, u, 540, 820)


def rv5(t, u):
    s = [bgwash("#2b1a12", "#5a2a1a")]
    m = seg(u, .1, .7)
    s.append(G(P("M-300,0 Q0,-60 300,0", "none", "#f4efe2", 14) + P("M-300,0 Q0,-60 300,0", "none", "#e2b13c", 4), 540 - 200 * (1 - m), 700, 1, -20))
    s.append(G(P("M0,-260 L0,200", "none", "#c9ced6", 26) + P("M-70,200 L70,200", "none", "url(#gold)", 20) + P("M0,200 L0,280", "none", "#6b4226", 22), 540 + 200 * (1 - m), 760, 1, 20))
    s.append(C(540, 740, 120 + 220 * m, "url(#glow)", op=m) + motes(t, "#ffd36b", 50, .7))
    return "".join(s)


def rv6(t, u):
    s = [bgwash("#e2462a", "#4a0a14"), C(540, 760, 160, "#b0201a", INK, 5), C(540, 760, 420, "url(#glow)", op=.35)]
    s.append(hills(860, t, "#2a0a0a", 90, 2) + f'<rect y="900" width="{W}" height="{H}" fill="#1a0808"/>')
    s.append(P("M380,1180 L420,1000 L660,1000 L700,1180 Z", "#2a1414", INK, 5) + P("M360,1000 L540,860 L720,1000 Z", "#3a1a1a", INK, 5))
    for k in range(6): s.append(bird(150 + k * 160 + 40 * math.sin(t + k), 380 + 50 * (k % 2), .35, t + k, False))
    return cam("".join(s), 1.0, 1.1, u, 540, 800)


def rv7(t, u):
    s = [bgwash("#0e0a1a", "#2a1a3a"), clouds(t, "#2a2238", 240), lightning(t, 760)]
    s.append(waves(1220, t, "#1c2a48", "#7a8ab0", 20))
    s.append(G(towers(t, "#1a0e1a"), 0, 40 - 40 * seg(u, 0, .6)))
    s.append(f'<g opacity="{seg(u, .5, .9) * .5:.2f}">' + ravana(540, 420, 1.0, t, 1) + '</g>')
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


def end_card(t, u):
    return bgwash("#22163a", "#4b2f63") + sunface(540, 640, 130, t, .95, .5) + motes(t, "#fff3c4", 30, .6)


# ===================================================================== KU-01 (Kurukshetra)
def ku0(t, u):
    s = [bgwash("#f6c98a", "#e8774a"), C(540, 620, 100, "url(#sunG)", INK, 5), hills(820, t, "#a8604a", 80, 2, .9), f'<rect y="900" width="{W}" height="{H}" fill="#c9915a"/>']
    s.append(army(980, t, 30, "#5a1a3a", .9) + army(1120, t, 26, "#1a3a6a", 1.1))
    for k, x in enumerate([180, 900]): s.append(P(f"M{x},1000 L{x},780", "none", INK, 6) + P(f"M{x},780 L{x + 90 + 10 * math.sin(t * 5 + k)},805 L{x},830 Z", "#c0392b" if k == 0 else "#1f5fa8", INK, 3))
    return cam("".join(s), 1.12, 1.0, u, 540, 900)


def ku1(t, u):
    s = [bgwash("#f3d9a6", "#e2a86a"), f'<rect y="1000" width="{W}" height="{H}" fill="#c9a46e"/>']
    sh = -200 * ease(u)
    s.append(G(chariot(200, 1000, .6, t) + chariot(560, 1000, .6, t) + chariot(920, 1000, .6, t) + chariot(1280, 1000, .6, t), sh, 0))
    s.append(G(elephant(150, 1180, .6, t) + elephant(560, 1200, .6, t) + elephant(970, 1180, .6, t), -sh * .6, 0))
    s.append(army(1340, t, 24, "#5a2a1a", 1.0))
    for k in range(4): s.append(horse(100 + k * 260 + sh * .3, 820, .5, t, k))
    return "".join(s)


def ku2(t, u):
    s = [bgwash("#e8b27c", "#c9915a")]
    for r in range(9):
        s.append(army(500 + r * 90, t + r, 24 + r * 2, "#5a2a1a" if r % 2 else "#2a3a5a", .4 + r * .1))
    s.append(f'<rect width="{W}" height="{H}" fill="#f3d9a6" opacity="{.25 * (1 - u):.2f}"/>')
    return cam("".join(s), 1.25, 1.0, u, 540, 900)


def ku3(t, u):
    s = [bgwash("#f3d9a6", "#e2a86a"), f'<rect y="1050" width="{W}" height="{H}" fill="#c9a46e"/>']
    s.append(chariot(270, 1100, .55, t) + chariot(810, 1100, .55, t, True, "#1f5fa8"))
    bh, _, _ = king(260, .62, t, 'raise', dict(old=True, beard="#f4efe2", hair="#f4efe2", wrinkles=True, smile=.2, gaze=(1, 0)), upper="url(#white)", dhoti="url(#white)", ang="#e2b13c", y=1000 - 550 * .62)
    dh, _, _ = king(810, .6, t, 'point', dict(angry=.5, gaze=(-1, 0)), upper="url(#yel)", dhoti="url(#saff)", ang="#1f5fa8", y=1000 - 550 * .6)
    s += [bh, dh]
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


def ku4(t, u):
    s = [bgwash("#f6e2bd", "#f0b77a"), C(800, 420, 90, "url(#sunG)", INK, 5), f'<rect y="1050" width="{W}" height="{H}" fill="#c9a46e"/>', chariot(560, 1120, .9, t)]
    kr, _, _ = king(380, .62, t, 'give', dict(feather=True, smile=.5, gaze=(1, 0), mustache=False), upper="url(#yel)", dhoti="url(#yel)", ang="#2e8b57", skin="url(#skinB)", y=1000 - 550 * .62)
    ar, _, _ = king(700, .66, t, 'down', dict(gaze=(-1, 0), smile=.2), upper="url(#white)", dhoti="url(#yel)", ang="#1f5fa8", y=1000 - 550 * .66)
    s += [kr, ar, bow(820, 860, .55)]
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


def ku5(t, u):
    shake = 6 * math.sin(t * 40) * seg(u, .3, .5)
    s = [bgwash("#f3c48a", "#c9784a"), soundrings(540, 700, t), f'<rect y="1050" width="{W}" height="{H}" fill="#b98a5a"/>']
    a, _, _ = king(320, .75, t, 'raise', dict(open=.2, mouthOpen=.0, gaze=(1, -.3)), upper="url(#white)", dhoti="url(#yel)", ang="#1f5fa8", lift=1)
    b, _, _ = king(780, .75, t, 'raise', dict(open=.2, gaze=(-1, -.3)), upper="url(#purp)", dhoti="url(#gold)", lift=1)
    s += [a, b, conch(330, 330, .9, -40), conch(760, 330, .9, -140)]
    s.append(motes(t, "#e8d0a0", 60, .6))
    return G(cam("".join(s), 1.0, 1.06, u, 540, 800), shake, 0)


def ku6(t, u):
    s = [bgwash("#e8b27c", "#8a4e3a"), f'<rect y="1050" width="{W}" height="{H}" fill="#a8854f"/>', army(1000, t, 18, "#5a2a1a", .7), chariot(560, 1140, .95, t)]
    d = seg(u, .2, .7)
    ar, _, _ = king(640, .72, t, 'down', dict(sad=1, tears=seg(u, .5, 1), gaze=(0, 1), tremble=.4), upper="url(#white)", dhoti="url(#yel)", ang="#1f5fa8", y=1030 - 550 * .72 + 30 * d)
    kr, _, _ = king(380, .62, t, 'down', dict(feather=True, smile=.1, gaze=(1, .2), mustache=False), upper="url(#yel)", dhoti="url(#yel)", ang="#2e8b57", skin="url(#skinB)", y=1030 - 550 * .62)
    s += [kr, ar, bow(760, 860 + 220 * d, .55, 70 * d)]
    return cam("".join(s), 1.0, 1.14, u, 600, 800)


# ===================================================================== DA-01 (Matsya)
def da0(t, u):
    s = [bgwash("#f6e2bd", "#cfe0a8"), C(820, 360, 90, "url(#sunG)", INK, 5), river(1000, t)]
    kg, h1, h2 = king(540, 1.05, t, 'offer', dict(gaze=(0, 1), smile=.2, open=.6), upper="url(#white)", dhoti="url(#saff)", ang="#e2b13c", y=1100 - 550 * 1.05)
    s.append(kg + fish(h2[0] - 30, h2[1] - 40, .18, t, .8))
    return cam("".join(s), 1.0, 1.1, u, 540, 700)


def da1(t, u):
    s = [bgwash("#f6dcae", "#f3a96a")]
    s.append(G(K.hand(-60, 0, 160, 2.2, "open") + K.hand(60, 0, 20, 2.2, "open"), 540, 1000, 1.5))
    s.append(fish(540, 880, .5, t, .9) + motes(t))
    return cam("".join(s), 1.0, 1.15, u, 540, 900)




def da2(t, u):
    g = seg(u, .2, .8)
    s = [bgwash("#efe0bf", "#cdb57a"), f'<rect y="1100" width="{W}" height="{H}" fill="#c9a46e"/>', kamandal(540, 1000, 1.6)]
    s.append(fish(540, 820 - 120 * g, .25 + .5 * g, t, .5))
    kg, _, _ = king(880, .7, t, 'down', dict(open=1, mouthOpen=.4, gaze=(-1, 0), smile=0), upper="url(#white)", dhoti="url(#saff)", ang="#e2b13c")
    s.append(kg)
    return cam("".join(s), 1.0, 1.06, u)


def da3(t, u):
    p = u * 3; st = int(min(2, p)); g = p - st
    bgs = [("#cfe0a8", "#7fb0c8"), ("#bfe0e8", "#4a86b0"), ("#9ec8e8", "#1c3560")]
    s = [bgwash(*bgs[st])]
    if st == 0: s.append(f'<rect y="1000" width="{W}" height="{H}" fill="#8a9a52"/>' + E(540, 1150, 420, 160, "url(#riverD)", INK, 5))
    else: s.append(waves(1000 if st == 1 else 900, t, "#2b5c8f" if st == 1 else "#1c3560"))
    sz = [.6, 1.1, 2.2][st] * (0.85 + .25 * g)
    s.append(fish(540, 1100 - st * 60, sz, t, .3))
    return "".join(s)


def da4(t, u):
    s = [bgwash("#1c3560", "#0e1a30"), C(540, 760, 520, "url(#glow)", op=.55), chakra(860, 420, 70, t), waves(1150, t, "#1c3560", "#9fc4ea")]
    s.append(fish(500, 820, 1.8, t, .9, True))
    kg, _, _ = king(260, .55, t, 'pray', dict(gaze=(1, -.3), smile=.3, open=.8), upper="url(#white)", dhoti="url(#saff)", ang="#e2b13c", y=1150 - 550 * .55)
    s.append(kg + motes(t, "#fff3c4", 50, .8))
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


def da5(t, u):
    s = [bgwash("#f3d9a6", "#9fb8a0"), waves(1180, t, "#2b5c8f"), boat(540, 1130, 1.3, t, 2)]
    for k in range(3):
        sg, _, _ = sage(330 + k * 170, .42, t, 'pray', dict(), pose='sit', y=1060 - 350 * .42)
        s.append(sg)
    for k in range(3): s.append(G(E(0, 0, 40, 26, "#a37a54", INK, 3) + C(-40, -14, 16, "#a37a54", INK, 3), 150 + seg(u, .2, .8) * 160 + k * 60, 1070, .8))
    kg, _, _ = king(860, .6, t, 'point', dict(gaze=(-1, 0)), upper="url(#white)", dhoti="url(#saff)", ang="#e2b13c", y=1080 - 550 * .6)
    s.append(kg)
    return cam("".join(s), 1.0, 1.06, u)


def da6(t, u):
    rise = seg(u, 0, .8)
    s = [bgwash("#141c2c", "#2a3a5a"), clouds(t, "#2a3040", 220), lightning(t, 640), rain(t, 90, .55)]
    s.append(hills(1000 + 300 * rise, t, "#2a3a2a", 120, 2))
    s.append(G(waves(900, t, "#1c3560", "#9fc4ea", 40, speed=2), 0, 300 * (1 - rise)))
    return "".join(s)


def da7(t, u):
    s = [bgwash("#0e1424", "#22325a"), clouds(t, "#232a3a", 200), lightning(t, 300), rain(t, 80, .5), waves(1050, t, "#1c3560", "#9fc4ea", 40, speed=2)]
    s.append(fish(800, 760, 1.2, t, .6, True, -10) + P("M690,690 L780,560", "none", INK, 8) + P("M790,590 l20,-60 l20,60 Z", "url(#gold)", INK, 4))
    s.append(P(f"M780,580 Q560,{760 + 30 * math.sin(t * 2)} 360,{960 + 10 * math.sin(t * 1.6)}", "none", "#7fe0a0", 10) + P(f"M780,580 Q560,{760 + 30 * math.sin(t * 2)} 360,{960 + 10 * math.sin(t * 1.6)}", "none", "url(#glow)", 30, .6))
    s.append(boat(330, 1040, .9, t, 6))
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


# ===================================================================== HN-01 (Hanuman)
def hn0(t, u):
    s = [bgwash("#f6d7e8", "#c9a0d8"), clouds(t, "#fbf3fa", 1050, .9), clouds(t + 5, "#f4e6f4", 300, .7)]
    s.append(apsara(540, ystand_w(1.0) - 120, 1.0, t))
    s.append(motes(t, "#fff3c4", 60, .8))
    return cam("".join(s), 1.0, 1.08, u, 540, 800)


def hn1(t, u):
    tr = seg(u, .4, .8)
    s = [bgwash("#efe0bf", "#cdb57a"), f'<rect width="{W}" height="{H}" fill="#a8322a" opacity="{.15 * tr:.2f}"/>']
    sg, _, _ = sage(260, .7, t, 'point', dict(angry=1, mouthOpen=.4 * abs(math.sin(t * 7)), gaze=(1, 0)), pose='stand', col="url(#saff)")
    s.append(sg)
    s.append(f'<g opacity="{1 - tr:.2f}">' + G(apsara(0, ystand_w(.75), .75, t, tr), 280, 0) + '</g>')
    s.append(f'<g opacity="{tr:.2f}">' + G(lady(0, .75, t, 'shield', dict(sad=1, tears=1, tremble=.5), saree="url(#purp)") [0] + tail(40, ystand_w(.75) + 330, 1, t), 780, 0) + '</g>')
    s.append(C(780, 800, 120 + 300 * tr, "url(#glow)", op=max(0, .8 - abs(tr - .5) * 1.6)))
    return cam("".join(s), 1.0, 1.06, u)


def hn2(t, u):
    s = [bgwash("#e6efc4", "#9fb86a"), tree(140, 1150, 1.1, t), tree(960, 1150, 1.0, t, "#7f9c56")]
    an, _, _ = lady(380, .85, t, 'down', dict(smile=.6, gaze=(1, 0)), saree="url(#red)")
    ke, _, _ = king(720, .9, t, 'down', dict(smile=.6, gaze=(-1, 0), beard="#8a5a2c"), upper="url(#gold)", dhoti="url(#red)", ang="#a8322a", skin="url(#skinD)")
    s += [tail(400, GY - 120, 1, t), tail(740, GY - 140, 1.1, t), an, ke, grass(GY + 10, t, "#6f8f45", 50, 40)]
    return cam("".join(s), 1.0, 1.08, u)


def hn3(t, u):
    s = [bgwash("#0f1830", "#22325a"), "".join(C(x, y, r, "#fff3c4", op=.2 + .55 * abs(math.sin(t * 1.4 + p))) for x, y, p, r in K.STARS[:80]), C(820, 300, 80, "url(#moonG)", INK, 4)]
    s.append(P(f"M-40,1100 L300,700 L540,900 L820,640 L1120,1100 Z", "#2a3450", INK, 5) + f'<rect y="1100" width="{W}" height="{H}" fill="#1c2438"/>')
    s.append(linga(760, 1110, .8) + C(760, 1000, 200, "url(#glow)", op=.25 + .1 * math.sin(t * 2)))
    an, _, _ = lady(360, .82, t, 'pray', dict(open=.1, smile=.2), saree="url(#red)", pose='kneel', y=GY - 400 * .82)
    s.append(tail(380, GY - 60, .9, t) + an + motes(t, "#cfe4ff", 30, .5))
    return cam("".join(s), 1.0, 1.08, u)


def hn4(t, u):
    fly = seg(u, .45, 1)
    s = [bgwash("#f3d9a6", "#e2a86a"), "".join(f'<rect x="{x - 30}" y="300" width="60" height="760" fill="#d9b878" stroke="{INK}" stroke-width="5"/>' for x in (120, 960))]
    s.append(fire(540, 1060, 1.0, t))
    ds, _, h2 = king(800, .85, t, 'give', dict(gaze=(-1, .4), smile=.3, beard="#d8d2c8"), upper="url(#gold)", dhoti="url(#red)", ang="#a8322a")
    s.append(ds)
    bx = 640 + (1100 - 640) * fly; by = 900 - 700 * fly
    s.append(bird(bx, by - 20, .55, t) if fly > 0 else E(660, 900, 40, 14, "url(#gold)", INK, 4) + E(660, 894, 30, 8, "#f6efe0", "none") + bird(400 + 260 * seg(u, 0, .45), 200 + 680 * seg(u, 0, .45), .55, t, False))
    return cam("".join(s), 1.0, 1.06, u)


def hn5(t, u):
    s = [bgwash("#0f1830", "#2a3a6a"), C(820, 300, 80, "url(#moonG)", INK, 4), P(f"M-40,1100 L300,760 L540,900 L820,700 L1120,1100 Z", "#2a3450", INK, 5)]
    p = seg(u, 0, .75)
    for k in range(5):
        ph = (t * .5 + k / 5) % 1
        s.append(P(f"M{900 - 600 * p + 80 * math.sin(k)},{300 + 500 * p + k * 30} q60,-40 120,0 q60,40 120,0", "none", "#cfe4ff", 6, .8 - ph * .5))
    s.append(G(E(0, 0, 40, 14, "url(#gold)", INK, 4) + C(0, -10, 80, "url(#glow)", op=.8), 900 - 520 * p, 300 + 560 * p, 1))
    an, _, h2 = lady(340, .82, t, 'offer', dict(open=.2 + .7 * seg(u, .6, .9), smile=.5, gaze=(1, -.5)), saree="url(#red)", pose='kneel', y=GY - 400 * .82)
    s.append(tail(360, GY - 60, .9, t) + an)
    return cam("".join(s), 1.0, 1.08, u)


def hn6(t, u):
    s = [bgwash("#f6dcae", "#f3a96a"), trishul(540, 620, 1.3, .25 + .25 * math.sin(t * 2) + .3)]
    for i in range(24): s.append(G(P("M260,-6 L800,0 L260,6 Z", "#f7c948" if i % 2 else "#fff3c4", op=.4), 540, 900, 1, i * 15 + t * 8))
    an, _, _ = lady(470, 1.1, t, 'hold', dict(open=.5 * blink(t), gaze=(.7, 1), smile=.7), saree="url(#red)", pose='kneel', y=GY - 400 * 1.1 - 120)
    s.append(an + baby(580, 980, 1.05, t, eyes=1) + motes(t))
    return cam("".join(s), 1.0, 1.1, u, 560, 900)


def hn7(t, u):
    j = seg(u, .2, 1)
    s = [bgwash("#f8d28e", "#f49a4a"), sunface(780, 420 + 60 * (1 - j), 160 + 60 * j, t, .95, .5), hills(1100, t, "#8a4e3a", 80, 3)]
    s.append(G(baby(0, 0, 1, t, eyes=1), 260 + 380 * j, 1100 - 650 * j, .9 - .3 * j, -30 * j))
    for k in range(6):
        s.append(P(f"M{240 + 380 * j - k * 30},{1130 - 650 * j + k * 30} l-60,40", "none", "#fff3c4", 6, .6 * j))
    return cam("".join(s), 1.0, 1.1, u, 540, 800)


EPS = {
    'RV-01': dict(scenes=[rv0, rv1, rv2, rv3, rv4, rv5, rv6, rv7, end_card], tag="रावण - लंकापति  |  भाग 1", hook="ऋषि का बेटा राक्षस कैसे बना?"),
    'KU-01': dict(scenes=[ku0, ku1, ku2, ku3, ku4, ku5, ku6, end_card], tag="कुरुक्षेत्र  |  भाग 1", hook="40 लाख योद्धा आमने-सामने!"),
    'DA-01': dict(scenes=[da0, da1, da2, da3, da4, da5, da6, da7, end_card], tag="दशावतार - मत्स्य  |  भाग 1", hook="एक मछली ने दुनिया बचाई?"),
    'HN-01': dict(scenes=[hn0, hn1, hn2, hn3, hn4, hn5, hn6, hn7, end_card], tag="हनुमान - जन्म कथा  |  भाग 1", hook="एक श्राप से जन्मा महावीर!"),
}
