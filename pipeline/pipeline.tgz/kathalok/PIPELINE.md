# The Katha Lok — daily studio pipeline

Channel: The Katha Lok (कथालोक) — Indian mythology stories as detailed **Kalighat-style** code animation, Hindi voice.
Owner: Alok. Instagram @the_kathalok, YouTube @the_kathalok (UCBddLQKZRyENLTDNj4N6Taw), Facebook page "The Katha Lok" (Metricool brand 8171492).

## Setup in a fresh session (workspace)
```
mkdir -p /home/claude && cd /home/claude
curl -sSL -o p.tgz https://raw.githubusercontent.com/alokkr1995/kathalok-media/main/pipeline/pipeline.tgz && tar xzf p.tgz   # -> /home/claude/kathalok/...
pip install --break-system-packages kokoro-onnx soundfile cairosvg
mkdir -p ~/tts ~/.fonts
curl -sSL -o ~/tts/kokoro-v1.0.onnx https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx
curl -sSL -o ~/tts/voices-v1.0.bin https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin
curl -sSL -o ~/.fonts/NotoSansDevanagari-Bold.ttf https://raw.githubusercontent.com/notofonts/notofonts.github.io/main/fonts/NotoSansDevanagari/hinted/ttf/NotoSansDevanagari-Bold.ttf
```
Kokoro: `Kokoro(model, voices).create(text, voice='hm_omega', speed=1.0, lang='hi')`.

## Files
- `kathalok/series_en.json` — 5 series (DA, KR, RV, KU, HN), 10 episodes each: [title, hook, cliffhanger], slot time, long-video title.
- `kathalok/b1/batch1.json` — episode 1 scripts (Hindi VO lines).
- `kathalok/cine/` — **cinematic engine v4** (use this): `cine.py` (camera, light, rays, bloom, DOF, grade, ink/flash/black transitions, paper texture), `props.py` (set pieces), `sfx.py` (procedural foley + tanpura/dhol/bansuri score, ducking), `run.py <module> sheet|audio|a b` (frames/subtitles/hook/tag/CTA), episode modules `rv01.py ku01.py da01.py hn01.py` = examples of a shot list. `queue.sh` = render+encode (loudnorm -14 LUFS, grain).
- `kathalok/long_kr/kgbase.py` — Kalighat rigs: face(), woman(), man() (arms: bless lift point bow draw raise give hug wheel rest down; face: crown feather kundal beard jata tilak wrinkles angry sad smile tears tremble mouthOpen gaze skin), baby(), lotus(), tree(), hills(), river(), sunface(), horse(), motes().
- `kathalok/long_kr/kl.py` — 16:9 long-video builder (Karna long). `kathalok/b2/eps.py` — extra props (fish, boat, chariot, elephant, conch, chakra, linga, trishul, towers, waves, rain, lightning, fire, bird, tail, ravana).

## Rules (from Alok)
- 9:16 1080x1920 shorts, 30 fps, ~50-60 s: 3-second hook text, cliffhanger, end card CTA ("आगे क्या हुआ?", "कमेंट में लिखें 'कथा'", "पूरी कहानी यूट्यूब पर | लिंक बायो में"). NEVER write next-part date/time anywhere.
- Hindi script + VO; English in sheet. Only Indian art styles (Kalighat is the approved look). Cinematic storytelling: 2-3 shots per VO line, one clear action per shot, subject >= 1/3 frame, close-ups for emotion, motivated lighting, sound for every action, one silence before the climax, a signature shot.
- On-screen Devanagari only (font has no Latin glyphs).
- Captions: no next-part time. Reel cover = episode cover (name + "भाग N" + hook).
- Post on IG Reel + YT Short (vidIQ, accounts IG 28487176580957144, YT UCBddLQKZRyENLTDNj4N6Taw, public, categoryId 1) + FB Reel (Metricool createScheduledPost blogId 8171492, facebookData REEL) + IG Story (Metricool instagramData STORY: the reel video, and for long videos a story card).
- Media hosting: public GitHub repo alokkr1995/kathalok-media via the device helper `~/mnt/The_KathaLok_Brand_Kit/.kathalok/ghput.sh <local file> <repo path>` (runs on Alok's PC through device_bash; files must be < ~25 MB -> encode shorts crf 23-24). Raw URL: https://raw.githubusercontent.com/alokkr1995/kathalok-media/main/<path>. Then vidiq_video_upload(url) -> uploadId.
- Bio link page: `index.html` in the repo root; keep its schedule list updated (JS picks the latest released YouTube video).
- Tracker sheet: Claude Sheets artifact slug 7c64dd4e-f5d2-422c-845a-81c65d7e914e (tabs Episodes, Series & Long Videos, Approvals, ...).
- Notify Alok on phone (scheduled-task push) with preview links + post times; he does not want to come back to ask. Ask him only for things only he can do.

## Voice (approved v2, 18 Nov) — natural warm storyteller, NOT heavy bass, no echo
After Kokoro (hm_omega, lang hi, speed 1.0) process every vo.wav -> vo_deep.wav (run.py prefers vo_deep.wav):
`ffmpeg -i vo.wav -af "aresample=48000,asetrate=48000*0.94,aresample=48000,atempo=1.06383,highpass=f=75,equalizer=f=130:t=q:w=1.2:g=2.5,equalizer=f=300:t=q:w=1.4:g=-2.5,equalizer=f=3500:t=q:w=1.6:g=2,treble=g=1.5:f=10000,deesser=i=0.3,acompressor=threshold=-18dB:ratio=2.5:attack=10:release=200:makeup=2.5,alimiter=limit=0.95" vo_deep.wav`

## Organic Growth Optimization (Alok's master prompt, 18 Nov) — apply to every UNPUBLISHED video, never edit published ones
- Hook: write 3 candidate hooks, pick the strongest truthful one (curiosity / mystery / dramatic / character / consequence / emotional).
- Titles: 3 options (search / curiosity / emotional), pick best; Hindi first, <=100 chars, no clickbait. 
- Captions per platform (IG: hook + 1-2 lines + question + "कमेंट में लिखें 'कथा'" + bio link line + 5-7 hashtags; FB: different wording, discussion question, 3 hashtags; YT: description with summary, source, related playlist, subscribe line).
- Source line in every caption/description: "📖 स्रोत: <text/parva/purana>"; if versions differ say which one is adapted; never invent quotes.
- Vary the CTA wording every time (no identical CTA twice in a row).
- Playlist per series (Karna / Ravana / Kurukshetra / Dashavatar / Hanuman). vidIQ has no playlist tool -> log "Manual: add to playlist <name>" in the report until Alok creates them.
- Shorts -> long video "Related video" link: not available via tools -> log as manual action.
- Status fields per video in state.json: lifecycle (Script Ready/Rendered/Scheduled/Published/Failed) + growth_optimization (Optimized/Partially Optimized/Manual Action Required).
- Daily report: published, scheduled, failed, manual actions, verified metrics only (never invent numbers), 1-2 recommendations.
- Bio link: GitHub Pages did NOT work -> bio = https://www.youtube.com/@the_kathalok (no updates needed).
